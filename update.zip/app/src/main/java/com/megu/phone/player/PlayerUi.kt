package com.megu.phone.player

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.os.SystemClock
import android.view.Gravity
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import com.megu.phone.R
import com.megu.phone.data.Progress
import com.megu.phone.ui.EpisodeDownloadButton
import com.megu.phone.data.AppSettings
import com.megu.phone.ui.EpisodeRow
import com.megu.phone.ui.MeguDims
import com.megu.phone.ui.OnImage
import com.megu.phone.ui.SegmentedSelector
import com.megu.phone.ui.megu
import com.megu.phone.ui.rememberNotificationAsker
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

// ===================================================================== video

/** Video surface + subtitle layer, drawn without the stock PlayerView controls. */
@OptIn(UnstableApi::class)
class VideoHostView(context: Context) : FrameLayout(context) {
    val aspect = AspectRatioFrameLayout(context)
    val surface = SurfaceView(context)
    val subtitles = SubtitleView(context)

    init {
        setBackgroundColor(AndroidColor.BLACK)
        aspect.setAspectRatio(16f / 9f)
        aspect.addView(
            surface,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        addView(
            aspect,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )
        subtitles.setStyle(
            CaptionStyleCompat(
                AndroidColor.WHITE,
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                AndroidColor.BLACK,
                null
            )
        )
        subtitles.setApplyEmbeddedStyles(false)
        subtitles.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * 1.1f)
        addView(
            subtitles,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoSurface(c: PlayerController) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            VideoHostView(ctx).also { c.exo.setVideoSurfaceView(it.surface) }
        },
        update = { v ->
            v.aspect.setAspectRatio(c.videoAspect)
            v.subtitles.setCues(c.cues)
        },
        onRelease = { v ->
            if (!c.released) c.exo.clearVideoSurfaceView(v.surface)
        }
    )
}

// ==================================================================== screen

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(c: PlayerController) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(landscape) { c.setImmersive(landscape) }
    BackHandler(enabled = landscape) { c.exitFullscreen() }
    BackHandler(enabled = c.menu != null) { c.menu = null }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (landscape) OnImage.videoBackdrop else MaterialTheme.colorScheme.background)
    ) {
        Column(Modifier.fillMaxSize()) {
            if (!landscape && !c.inPip) {
                Spacer(
                    Modifier
                        .fillMaxWidth()
                        .windowInsetsTopHeight(WindowInsets.statusBars)
                        .background(OnImage.videoBackdrop)
                )
            }
            val videoModifier =
                if (landscape || c.inPip) Modifier.fillMaxSize()
                else Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            Box(videoModifier.background(OnImage.videoBackdrop)) {
                VideoSurface(c)
                if (!c.inPip) PlayerOverlay(c, landscape)
            }
            if (!landscape && !c.inPip) {
                EpisodePanel(c, Modifier.weight(1f))
            }
        }

        if (c.menu != null && !c.inPip) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { c.menu = null }
            )
            SettingsMenu(
                c = c,
                modifier = if (landscape) {
                    Modifier
                        .align(Alignment.CenterEnd)
                        .padding(16.dp)
                        .width(300.dp)
                        .heightIn(max = 300.dp)
                } else {
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(12.dp)
                        .heightIn(max = 380.dp)
                }
            )
        }
    }
}

// =================================================================== overlay

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0L)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
private fun PlayerOverlay(c: PlayerController, landscape: Boolean) {
    var visible by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf<Float?>(null) }
    var flashSide by remember { mutableIntStateOf(0) }
    var flashTick by remember { mutableIntStateOf(0) }
    // Lock: ignores every touch until you tap the little unlock button.
    var locked by remember { mutableStateOf(false) }
    var lockHint by remember { mutableStateOf(false) }
    var lockTick by remember { mutableIntStateOf(0) }
    // When the last press-and-hold (2x speed) ended, so the finger lift is not taken as a tap.
    var holdEndedAt by remember { mutableLongStateOf(0L) }

    // Hide the controls 3.5 s after the last touch while playing.
    LaunchedEffect(visible, c.playing, c.menu, dragging != null, tick) {
        if (visible && c.playing && c.menu == null && dragging == null) {
            delay(3500)
            visible = false
        }
    }
    LaunchedEffect(flashTick) {
        if (flashSide != 0) {
            delay(650)
            flashSide = 0
        }
    }
    // While locked, the unlock button shows after a tap and hides again after 2.5 s.
    LaunchedEffect(lockHint, lockTick) {
        if (lockHint) {
            delay(2500)
            lockHint = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Touch layer: tap = show/hide controls, double-tap left/right = seek 10 s,
        // press and hold = 2x speed until you let go.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            if (AppSettings.holdFor2x && !locked && c.playing && c.menu == null) {
                                // Still pressed after 450 ms? Then it is a hold, not a tap.
                                val letGo = withTimeoutOrNull(450L) { tryAwaitRelease() }
                                if (letGo == null) {
                                    c.startBoost()
                                    try {
                                        tryAwaitRelease()
                                    } finally {
                                        c.endBoost()
                                        holdEndedAt = SystemClock.uptimeMillis()
                                    }
                                }
                            }
                        },
                        onTap = {
                            if (SystemClock.uptimeMillis() - holdEndedAt > 700L) {
                                if (locked) {
                                    lockHint = true
                                    lockTick++
                                } else {
                                    visible = !visible
                                    tick++
                                }
                            }
                        },
                        onDoubleTap = { offset ->
                            if (!locked && SystemClock.uptimeMillis() - holdEndedAt > 700L) {
                                val left = offset.x < size.width / 2f
                                c.seekBy(if (left) -10_000L else 10_000L)
                                flashSide = if (left) -1 else 1
                                flashTick++
                            }
                        }
                    )
                }
        )

        AnimatedVisibility(
            visible = visible && c.error == null && !locked,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(OnImage.scrim)
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .then(if (landscape) Modifier.displayCutoutPadding() else Modifier)
                ) {
                    TopBar(
                        c = c,
                        onTouch = { tick++ },
                        onLock = {
                            locked = true
                            visible = false
                            lockHint = true
                            lockTick++
                        }
                    )
                    CenterControls(c, onTouch = { tick++ })
                    BottomBar(
                        c = c,
                        landscape = landscape,
                        dragging = dragging,
                        onDrag = { dragging = it; tick++ },
                        onDragEnd = {
                            dragging?.let { c.seekTo(it.toLong()) }
                            dragging = null
                        },
                        onTouch = { tick++ }
                    )
                }
            }
        }

        // Shown while you hold the screen for 2x speed.
        if (c.boosting) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = if (visible) 56.dp else 16.dp)
                    .background(OnImage.scrimStrong, CircleShape)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text("2× speed", color = OnImage.content, fontWeight = FontWeight.Bold)
            }
        }

        // The only touchable thing while locked.
        AnimatedVisibility(
            visible = locked && lockHint,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        ) {
            IconButton(
                onClick = {
                    locked = false
                    lockHint = false
                    visible = true
                    tick++
                },
                modifier = Modifier
                    .size(56.dp)
                    .background(OnImage.scrimStrong, CircleShape)
            ) {
                Icon(
                    painterResource(R.drawable.ic_lock_open),
                    contentDescription = "Unlock controls",
                    tint = OnImage.content
                )
            }
        }

        // Spinner while the controls are hidden.
        if ((c.loading || c.buffering) && !(visible && c.error == null) && c.error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = OnImage.content)
        }

        // "Skip intro" / "Skip ending"
        val skip = c.skipInfo()
        if (skip != null && c.error == null && !locked) {
            Button(
                onClick = { c.seekTo(skip.toMs) },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = if (visible) 60.dp else 16.dp)
            ) {
                Text(skip.label)
            }
        }

        // Double-tap flash
        if (flashSide != 0) {
            Box(
                Modifier
                    .align(if (flashSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 40.dp)
                    .background(OnImage.scrim, CircleShape)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    if (flashSide < 0) "−10 s" else "+10 s",
                    color = OnImage.content,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Error
        val err = c.error
        if (err != null) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(err, color = OnImage.content, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { c.retry() }) { Text("Try again") }
                    OutlinedButton(onClick = { c.activity.finish() }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.TopBar(
    c: PlayerController,
    onTouch: () -> Unit,
    onLock: () -> Unit
) {
    val epTitle = c.epMeta[c.episode]?.title
    val line = "Episode ${c.episode}" +
        (if (epTitle != null) " · $epTitle" else "") +
        (if (c.dub) " · Dub" else "") +
        (if (c.offline) " · Downloaded" else "")
    Row(
        Modifier
            .align(Alignment.TopStart)
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { c.activity.onBackPressedDispatcher.onBackPressed() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = OnImage.content)
        }
        Column(Modifier.weight(1f)) {
            Text(
                c.anime?.title ?: "",
                color = OnImage.content,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                line,
                color = OnImage.contentMuted,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onLock) {
            Icon(painterResource(R.drawable.ic_lock), contentDescription = "Lock controls", tint = OnImage.content)
        }
        if (c.pipSupported) {
            IconButton(onClick = { c.enterPip(force = true) }) {
                Icon(painterResource(R.drawable.ic_pip), contentDescription = "Picture in picture", tint = OnImage.content)
            }
        }
        IconButton(onClick = {
            c.menu = MenuPage.Main
            onTouch()
        }) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = OnImage.content)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.CenterControls(c: PlayerController, onTouch: () -> Unit) {
    val hasPrev = c.prevEpisode() != null
    val hasNext = c.nextEpisode() != null
    Row(
        Modifier.align(Alignment.Center),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { c.playPrevious(); onTouch() },
            enabled = hasPrev,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painterResource(R.drawable.ic_skip_prev),
                contentDescription = "Previous episode",
                tint = if (hasPrev) OnImage.content else OnImage.contentDisabled,
                modifier = Modifier.size(32.dp)
            )
        }
        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            if (c.loading || c.buffering) {
                CircularProgressIndicator(color = OnImage.content)
            } else {
                IconButton(
                    onClick = { c.togglePlay(); onTouch() },
                    modifier = Modifier
                        .size(64.dp)
                        .background(OnImage.scrim, CircleShape)
                ) {
                    Icon(
                        painterResource(if (c.playing) R.drawable.ic_pause else R.drawable.ic_play),
                        contentDescription = if (c.playing) "Pause" else "Play",
                        tint = OnImage.content,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }
        }
        IconButton(
            onClick = { c.playNext(); onTouch() },
            enabled = hasNext,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painterResource(R.drawable.ic_skip_next),
                contentDescription = "Next episode",
                tint = if (hasNext) OnImage.content else OnImage.contentDisabled,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.BottomBar(
    c: PlayerController,
    landscape: Boolean,
    dragging: Float?,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onTouch: () -> Unit
) {
    val duration = maxOf(c.durationMs, 1L).toFloat()
    val shown = (dragging ?: c.positionMs.toFloat()).coerceIn(0f, duration)
    Row(
        Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(formatTime(shown.toLong()), color = OnImage.content, style = MaterialTheme.typography.labelMedium)
        Slider(
            value = shown,
            onValueChange = onDrag,
            onValueChangeFinished = onDragEnd,
            valueRange = 0f..duration,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = OnImage.track
            ),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        Text(formatTime(c.durationMs), color = OnImage.content, style = MaterialTheme.typography.labelMedium)
        IconButton(onClick = {
            if (landscape) c.exitFullscreen() else c.enterFullscreen()
            onTouch()
        }) {
            Icon(
                painterResource(if (landscape) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen),
                contentDescription = "Fullscreen",
                tint = OnImage.content
            )
        }
    }
}

// ===================================================================== menu

@Composable
private fun SettingsMenu(c: PlayerController, modifier: Modifier) {
    val page = c.menu ?: return
    Surface(
        modifier = modifier,
        color = MaterialTheme.megu.elevated.copy(alpha = 0.97f),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier
                .padding(vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (page != MenuPage.Main) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { c.menu = MenuPage.Main }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.megu.textPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        when (page) {
                            MenuPage.Quality -> "Quality"
                            MenuPage.Speed -> "Speed"
                            MenuPage.Subtitles -> "Subtitles"
                            MenuPage.Audio -> "Audio"
                            MenuPage.Server -> "Server"
                            MenuPage.Main -> ""
                        },
                        color = MaterialTheme.megu.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            when (page) {
                MenuPage.Main -> {
                    MenuRow("Quality", c.qualityLabel()) { c.menu = MenuPage.Quality }
                    MenuRow("Speed", speedLabel(c.speed)) { c.menu = MenuPage.Speed }
                    MenuRow("Subtitles", c.subtitleLabel()) { c.menu = MenuPage.Subtitles }
                    MenuRow("Audio", c.audioLabel()) { c.menu = MenuPage.Audio }
                    if (c.servers.size > 1) {
                        val s = c.servers.getOrNull(c.serverIndex)
                        MenuRow("Server", s?.label ?: "") { c.menu = MenuPage.Server }
                    }
                }
                MenuPage.Quality -> {
                    if (c.videoOptions.size <= 1) {
                        InfoText("This stream only offers automatic quality.")
                    }
                    c.videoOptions.forEach { o ->
                        OptionRow(o.label, o.selected) {
                            c.selectVideo(o)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Speed -> {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v ->
                        OptionRow(speedLabel(v), c.speed == v) {
                            c.changeSpeed(v)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Subtitles -> {
                    val server = c.servers.getOrNull(c.serverIndex)
                    if (c.textOptions.size <= 1) {
                        InfoText(
                            if (server != null && server.hardsub)
                                "This server has subtitles built into the video."
                            else
                                "No subtitle tracks for this stream."
                        )
                    }
                    c.textOptions.forEach { o ->
                        OptionRow(o.label, o.selected) {
                            c.selectText(o)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Audio -> {
                    val canDub = c.dubAvailable()
                    OptionRow("Japanese (Sub)", !c.dub) {
                        c.switchLanguage(false)
                        c.menu = null
                    }
                    if (canDub || c.dub) {
                        OptionRow("English (Dub)", c.dub) {
                            c.switchLanguage(true)
                            c.menu = null
                        }
                    } else {
                        InfoText("No English dub for this episode.")
                    }
                    if (c.audioOptions.size > 1) {
                        InfoText("Audio tracks in this stream")
                        c.audioOptions.forEach { o ->
                            OptionRow(o.label, o.selected) {
                                c.selectAudio(o)
                                c.menu = null
                            }
                        }
                    }
                }
                MenuPage.Server -> {
                    c.servers.forEachIndexed { i, s ->
                        OptionRow(
                            s.label + (if (s.hardsub) " (hardsub)" else ""),
                            i == c.serverIndex
                        ) {
                            c.switchServer(i)
                            c.menu = null
                        }
                    }
                }
            }
        }
    }
}

private fun speedLabel(v: Float): String =
    if (v == 1f) "Normal" else v.toString().removeSuffix(".0") + "x"

@Composable
private fun MenuRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = MaterialTheme.megu.textPrimary, modifier = Modifier.weight(1f))
        Text(value, color = MaterialTheme.megu.textSecondary, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(24.dp)) {
            if (selected) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            color = if (selected) MaterialTheme.megu.accentText else MaterialTheme.megu.textPrimary
        )
    }
}

@Composable
private fun InfoText(text: String) {
    Text(
        text,
        color = MaterialTheme.megu.textSecondary,
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

// ============================================================ episode panel

@Composable
private fun EpisodePanel(c: PlayerController, modifier: Modifier) {
    val palette = MaterialTheme.megu
    val listState = rememberLazyListState()
    val index = c.episodes.indexOf(c.episode)
    // Two items (details, "Episodes" header) sit above the first episode.
    LaunchedEffect(c.episode, c.episodes.size) {
        if (index >= 0) listState.animateScrollToItem(index + 2)
    }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val askNotifications = rememberNotificationAsker()

    val progressByEpisode = remember(c.animeId, c.episode, c.dub, c.episodes) {
        c.episodes.associateWith { Progress.fraction(c.animeId, it, c.dub) }
    }
    val watched = remember(c.animeId, c.episode, c.episodes) {
        c.episodes.filter { Progress.isWatched(c.animeId, it) }.toSet()
    }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        state = listState,
        contentPadding = PaddingValues(bottom = navBottom + 16.dp)
    ) {
        item(key = "info") {
            val meta = c.epMeta[c.episode]
            val details = listOfNotNull(
                "Episode ${c.episode}",
                meta?.runtime?.let { "$it min" },
                if (c.dub) "Dub" else "Sub",
                if (c.offline) "Downloaded" else null
            ).joinToString(" • ")
            Column(Modifier.padding(horizontal = MeguDims.ScreenPadding, vertical = 12.dp)) {
                Text(
                    c.anime?.title ?: "",
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    details,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.textPrimary
                )
                if (!meta?.title.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        meta?.title ?: "",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                val overview = meta?.overview
                if (overview != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        overview,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (c.lang?.hasDub == true) {
                    Spacer(Modifier.height(12.dp))
                    SegmentedSelector(
                        options = listOf("Sub", "Dub"),
                        selected = if (c.dub) 1 else 0,
                        onSelect = { c.switchLanguage(it == 1) },
                        isEnabled = { it == 0 || c.dubAvailable() || c.dub }
                    )
                }
            }
        }
        item(key = "episodes-header") {
            Column {
                HorizontalDivider(
                    Modifier.padding(horizontal = MeguDims.ScreenPadding),
                    color = palette.elevated
                )
                Text(
                    "Episodes",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(
                        horizontal = MeguDims.ScreenPadding,
                        vertical = 12.dp
                    )
                )
            }
        }
        items(c.episodes, key = { it }) { n ->
            val meta = c.epMeta[n]
            val show = c.anime
            val download: (@Composable () -> Unit)? = if (show != null) {
                {
                    EpisodeDownloadButton(
                        anime = show,
                        episode = n,
                        dub = c.dub,
                        info = meta,
                        onBeforeStart = askNotifications
                    )
                }
            } else {
                null
            }
            EpisodeRow(
                number = n,
                title = meta?.title,
                subtitle = listOfNotNull(
                    meta?.runtime?.let { "$it min" },
                    if (c.dub) "Dub" else "Sub"
                ).joinToString(" • "),
                image = meta?.image,
                progress = progressByEpisode[n] ?: 0f,
                watched = n in watched,
                current = n == c.episode,
                currentLabel = "Now Playing",
                playing = n == c.episode,
                onClick = { if (n != c.episode) c.load(n, c.dub) },
                trailing = download
            )
        }
    }
}
