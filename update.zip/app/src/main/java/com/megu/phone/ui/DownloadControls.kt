package com.megu.phone.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.DlState
import com.megu.phone.data.DownloadItem
import com.megu.phone.data.Downloads
import com.megu.phone.data.EpisodeMeta
import java.util.Locale

/** "1.4 GB", "230 MB", "800 KB". */
fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = -1
    do {
        value /= 1024.0
        unit++
    } while (value >= 1024.0 && unit < units.size - 1)
    val digits = if (value >= 100.0 || unit == 0) 0 else 1
    return String.format(Locale.getDefault(), "%.${digits}f %s", value, units[unit])
}

/** One line saying where a download stands. */
fun downloadStatus(item: DownloadItem): String {
    val percent = (item.progress * 100f).toInt()
    return when (item.state) {
        DlState.Preparing -> "Getting ready…"
        DlState.Queued -> if (item.waitingForNetwork) "Waiting for network…" else "Waiting to start…"
        DlState.Downloading ->
            if (item.bytes > 0L) "Downloading · $percent% · ${formatBytes(item.bytes)}" else "Downloading · $percent%"
        DlState.Paused -> "Paused · $percent%"
        DlState.Completed -> if (item.bytes > 0L) "Downloaded · ${formatBytes(item.bytes)}" else "Downloaded"
        DlState.Failed -> item.error ?: "Download failed"
        DlState.Removing -> "Removing…"
    }
}

/**
 * Android 13+ only shows notifications after the user allows it. Returns a function to call
 * just before a download starts; it asks once and never again. Downloads work either way.
 */
@Composable
fun rememberNotificationAsker(): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    return remember {
        val ask: () -> Unit = {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                val prefs = context.getSharedPreferences("megu_downloads_ui", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("asked_notifications", false)) {
                    prefs.edit().putBoolean("asked_notifications", true).apply()
                    try {
                        launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } catch (e: Exception) {
                        // no permission dialog available; downloads still work
                    }
                }
            }
        }
        ask
    }
}

/**
 * The download button at the end of an episode row. Tap to download; once it is downloading
 * or saved, tap for pause / resume / cancel / delete.
 */
@Composable
fun EpisodeDownloadButton(
    anime: Anime,
    episode: Int,
    dub: Boolean,
    info: EpisodeMeta?,
    onBeforeStart: () -> Unit
) {
    // Reading the version redraws this button as the download moves along.
    val version = Downloads.version
    val item = remember(version, anime.id, episode, dub) { Downloads.item(anime.id, episode, dub) }
    var menu by remember { mutableStateOf(false) }

    Box {
        IconButton(onClick = {
            if (item == null) {
                onBeforeStart()
                Downloads.start(anime, episode, dub, info)
            } else {
                menu = true
            }
        }) {
            if (item == null) {
                Icon(
                    painterResource(R.drawable.ic_download),
                    contentDescription = "Download episode $episode"
                )
            } else {
                when (item.state) {
                    DlState.Completed -> Icon(
                        painterResource(R.drawable.ic_download_done),
                        contentDescription = "Downloaded",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    DlState.Failed -> Icon(
                        Icons.Filled.Warning,
                        contentDescription = "Download failed",
                        tint = MaterialTheme.colorScheme.error
                    )
                    DlState.Downloading -> CircularProgressIndicator(
                        progress = { item.progress },
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                    DlState.Paused -> Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { item.progress },
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Icon(
                            painterResource(R.drawable.ic_pause),
                            contentDescription = "Paused",
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    else -> CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            if (item != null) {
                when (item.state) {
                    DlState.Completed -> {
                        DropdownMenuItem(
                            text = { Text("Delete download", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menu = false
                                Downloads.remove(item.key)
                            }
                        )
                    }
                    DlState.Failed -> {
                        DropdownMenuItem(
                            text = { Text(item.error ?: "Download failed") },
                            onClick = {},
                            enabled = false
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Retry") },
                            onClick = {
                                menu = false
                                onBeforeStart()
                                Downloads.retry(item.key)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Remove", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menu = false
                                Downloads.remove(item.key)
                            }
                        )
                    }
                    DlState.Paused -> {
                        DropdownMenuItem(
                            text = { Text("Resume") },
                            onClick = {
                                menu = false
                                Downloads.resume(item.key)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Cancel download", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menu = false
                                Downloads.remove(item.key)
                            }
                        )
                    }
                    DlState.Downloading, DlState.Queued -> {
                        DropdownMenuItem(
                            text = { Text("Pause") },
                            onClick = {
                                menu = false
                                Downloads.pause(item.key)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Cancel download", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menu = false
                                Downloads.remove(item.key)
                            }
                        )
                    }
                    else -> {
                        DropdownMenuItem(
                            text = { Text("Cancel download", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                menu = false
                                Downloads.remove(item.key)
                            }
                        )
                    }
                }
            }
        }
    }
}
