package com.megu.phone.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.megu.phone.R
import com.megu.phone.data.LoadProblem

// The amber of the Amber accent preset, so these screens look the same whatever accent is picked.
private val Amber = Color(0xFFFFC56B)
private val OnAmber = Color(0xFF3A2600)
private val Lavender = Color(0xFFBDB8D6)
private val CardBackground = Color(0xFF25213A)
private val PillBackground = Color(0xFF1D1C24)
private val PillText = Color(0xFFCFCBE6)
private val OutlineGrey = Color(0xFF8E8E93)
private val FrameGrey = Color(0xFF8A8794)

/** Which two buttons a problem screen offers. */
private enum class Primary { TryAgain, Downloads, Profile }

/**
 * Full-screen state for Home when it has nothing to show.
 *
 *  - Offline: no internet. Only "Go to Downloads"; no Try Again (it would have nothing to try).
 *  - Temporary / RateLimited: internet is fine but the request failed. Try Again is the main
 *    button and Go to Downloads sits below it.
 *  - Everything else: its own message, and only the buttons that make sense for it.
 */
@Composable
fun HomeProblemScreen(
    problem: LoadProblem,
    retrying: Boolean,
    waitSeconds: Int,
    onTryAgain: () -> Unit,
    onGoToDownloads: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val offline = problem == LoadProblem.Offline

    val pill: String
    val title: String
    val body: String
    val primary: Primary
    val showDownloadsCard: Boolean

    when (problem) {
        LoadProblem.Offline -> {
            pill = "YOU'RE OFFLINE"
            title = "No internet connection"
            body = "You can still watch videos you've downloaded. Head to Downloads to start watching."
            primary = Primary.Downloads
            showDownloadsCard = false
        }
        LoadProblem.Temporary -> {
            pill = "CONNECTION PROBLEM"
            title = "Couldn't connect right now"
            body = "Please try again. You can still watch videos you've downloaded."
            primary = Primary.TryAgain
            showDownloadsCard = true
        }
        is LoadProblem.RateLimited -> {
            pill = "PLEASE WAIT"
            title = "Too many requests"
            body = "The server asked us to slow down. You can still watch videos you've downloaded."
            primary = Primary.TryAgain
            showDownloadsCard = true
        }
        LoadProblem.Unauthorized -> {
            pill = "SIGN IN REQUIRED"
            title = "Please sign in"
            body = "You're signed out or your session expired. Open Profile to sign in again."
            primary = Primary.Profile
            showDownloadsCard = true
        }
        LoadProblem.Forbidden -> {
            pill = "ACCESS RESTRICTED"
            title = "Access restricted"
            body = "This content isn't available for your account or region. You can still watch videos you've downloaded."
            primary = Primary.Downloads
            showDownloadsCard = false
        }
        LoadProblem.NotFound -> {
            pill = "NOT FOUND"
            title = "Content not found"
            body = "What Home needs couldn't be found. It may have moved, so the app might need an update."
            primary = Primary.Downloads
            showDownloadsCard = false
        }
        LoadProblem.InvalidRequest, LoadProblem.Unexpected -> {
            pill = "SOMETHING WENT WRONG"
            title = "Something went wrong"
            body = "Home couldn't be loaded. You can still watch videos you've downloaded."
            primary = Primary.Downloads
            showDownloadsCard = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (offline) {
            OfflineIllustration(Modifier.size(width = 200.dp, height = 140.dp))
        } else {
            ProblemIllustration(Modifier.size(width = 200.dp, height = 128.dp))
        }
        Spacer(Modifier.height(20.dp))

        if (offline) {
            Text(
                pill,
                color = PillText,
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 2.sp
            )
        } else {
            Text(
                pill,
                color = PillText,
                style = MaterialTheme.typography.labelLarge,
                letterSpacing = 2.sp,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(PillBackground)
                    .padding(horizontal = 24.dp, vertical = 8.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyLarge,
            color = Lavender,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Spacer(Modifier.height(28.dp))

        when (primary) {
            Primary.TryAgain -> {
                val waiting = waitSeconds > 0
                AmberButton(
                    label = if (waiting) "Try again in ${waitSeconds}s" else "Try Again",
                    onClick = onTryAgain,
                    clickable = !retrying && !waiting,
                    dimmed = waiting && !retrying,
                    loading = retrying
                ) {
                    Icon(
                        Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = OnAmber,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Primary.Downloads -> {
                AmberButton(label = "Go to Downloads", onClick = onGoToDownloads) {
                    Icon(
                        painterResource(R.drawable.ic_download),
                        contentDescription = null,
                        tint = OnAmber,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Primary.Profile -> {
                AmberButton(label = "Go to Profile", onClick = onOpenProfile) {}
            }
        }

        if (showDownloadsCard) {
            Spacer(Modifier.height(24.dp))
            OrDivider()
            Spacer(Modifier.height(24.dp))
            DownloadsCard(onGoToDownloads)
        }
    }
}

@Composable
private fun AmberButton(
    label: String,
    onClick: () -> Unit,
    clickable: Boolean = true,
    dimmed: Boolean = false,
    loading: Boolean = false,
    icon: @Composable () -> Unit
) {
    Row(
        Modifier
            .heightIn(min = 54.dp)
            .clip(CircleShape)
            .background(if (dimmed) Amber.copy(alpha = 0.5f) else Amber)
            .clickable(enabled = clickable, role = Role.Button, onClick = onClick)
            .padding(horizontal = 36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (loading) {
            CircularProgressIndicator(
                color = OnAmber,
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(12.dp))
        } else {
            icon()
            Spacer(Modifier.width(10.dp))
        }
        Text(
            label,
            color = OnAmber,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun OrDivider() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .weight(1f)
                .height(1.dp)
                .background(Color(0x33FFFFFF))
        )
        Text(
            "OR",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Box(
            Modifier
                .weight(1f)
                .height(1.dp)
                .background(Color(0x33FFFFFF))
        )
    }
}

@Composable
private fun DownloadsCard(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(CardBackground)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painterResource(R.drawable.ic_download),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Go to Downloads",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "Watch your downloaded videos",
                style = MaterialTheme.typography.bodyMedium,
                color = Lavender
            )
        }
        Icon(
            Icons.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}

// ------------------------------------------------------------------ illustrations
// Both are drawn on a 200-unit-wide board and scaled to fit, so the shapes stay sharp at any size.

private fun circlePath(cx: Float, cy: Float, r: Float): Path =
    Path().apply { addOval(Rect(Offset(cx - r, cy - r), Size(r * 2f, r * 2f))) }

/** The cloud outline: a rounded base with three round lobes merged into one shape. */
private fun cloudPath(): Path {
    var p = Path().apply {
        addRoundRect(RoundRect(Rect(3f, 62f, 168f, 103f), CornerRadius(21f, 21f)))
    }
    for (lobe in listOf(circlePath(34f, 70f, 24f), circlePath(92f, 42f, 42f), circlePath(138f, 60f, 30f))) {
        p = Path.combine(PathOperation.Union, p, lobe)
    }
    return p
}

private fun DrawScope.sparks(a: Offset, b: Offset, c: Offset, d: Offset) {
    drawLine(Amber, a, b, strokeWidth = 4f, cap = StrokeCap.Round)
    drawLine(Amber, c, d, strokeWidth = 4f, cap = StrokeCap.Round)
}

private fun DrawScope.playTriangle(cx: Float, cy: Float, size: Float, color: Color) {
    val half = size / 2f
    val path = Path().apply {
        moveTo(cx - half * 0.7f, cy - half)
        lineTo(cx + half, cy)
        lineTo(cx - half * 0.7f, cy + half)
        close()
    }
    drawPath(path, color, style = Fill)
    drawPath(path, color, style = Stroke(width = 3f, join = StrokeJoin.Round))
}

/** Dark cloud, crossed-out Wi-Fi, video frame with an amber "!" badge. */
@Composable
private fun ProblemIllustration(modifier: Modifier = Modifier) {
    val cloud = remember { cloudPath() }
    Canvas(modifier) {
        scale(scale = size.width / 200f, pivot = Offset.Zero) {
            // cloud body
            drawPath(
                cloud,
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF34313F), Color(0xFF1C1B23)),
                    startY = 0f,
                    endY = 103f
                ),
                style = Fill
            )
            drawPath(cloud, Color(0xFF55515F), style = Stroke(width = 3f, join = StrokeJoin.Round))

            // Wi-Fi: dot and three arcs
            val cx = 84f
            val cy = 84f
            drawCircle(Color.White, radius = 7f, center = Offset(cx, cy))
            for (r in listOf(15f, 26f, 37f)) {
                drawArc(
                    color = Color.White,
                    startAngle = 225f,
                    sweepAngle = 90f,
                    useCenter = false,
                    topLeft = Offset(cx - r, cy - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(width = 5.5f, cap = StrokeCap.Round)
                )
            }
            // the slash, with a dark gap either side so it reads clearly
            drawLine(Color(0xFF26232E), Offset(68f, 28f), Offset(112f, 69f), strokeWidth = 12f, cap = StrokeCap.Round)
            drawLine(Color.White, Offset(68f, 28f), Offset(112f, 69f), strokeWidth = 5.5f, cap = StrokeCap.Round)

            // video frame
            drawRoundRect(
                Color(0xFF0B0B0D),
                topLeft = Offset(110f, 77f),
                size = Size(73f, 46f),
                cornerRadius = CornerRadius(8f, 8f)
            )
            drawRoundRect(
                FrameGrey,
                topLeft = Offset(110f, 77f),
                size = Size(73f, 46f),
                cornerRadius = CornerRadius(8f, 8f),
                style = Stroke(width = 4f)
            )
            playTriangle(146f, 100f, 18f, Color.White)

            // amber "!" badge
            drawCircle(Amber, radius = 18f, center = Offset(180f, 110f))
            drawLine(OnAmber, Offset(180f, 101f), Offset(180f, 111f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawCircle(OnAmber, radius = 2.4f, center = Offset(180f, 119f))

            sparks(Offset(157f, 8f), Offset(165f, 24f), Offset(168f, 27f), Offset(183f, 17f))
        }
    }
}

/** Outline cloud with a slash, video frame and an amber download badge. */
@Composable
private fun OfflineIllustration(modifier: Modifier = Modifier) {
    val cloud = remember { cloudPath() }
    val gap = MaterialTheme.colorScheme.background
    Canvas(modifier) {
        scale(scale = size.width / 200f, pivot = Offset.Zero) {
            // soft shadow under everything
            drawOval(
                Color(0xFF1A1A1E),
                topLeft = Offset(8f, 130f),
                size = Size(182f, 8f)
            )

            // cloud outline only
            drawPath(cloud, OutlineGrey, style = Stroke(width = 5f, join = StrokeJoin.Round))
            // the slash across the cloud, with a gap where it crosses the outline
            drawLine(gap, Offset(22f, 6f), Offset(102f, 74f), strokeWidth = 12f, cap = StrokeCap.Butt)
            drawLine(OutlineGrey, Offset(22f, 6f), Offset(102f, 74f), strokeWidth = 5.5f, cap = StrokeCap.Round)

            // video frame; the cloud line is cut away behind it
            drawRoundRect(
                gap,
                topLeft = Offset(43f, 75f),
                size = Size(105f, 71f),
                cornerRadius = CornerRadius(14f, 14f)
            )
            drawRoundRect(
                OutlineGrey,
                topLeft = Offset(49f, 81f),
                size = Size(93f, 59f),
                cornerRadius = CornerRadius(9f, 9f),
                style = Stroke(width = 5f)
            )
            playTriangle(95f, 110f, 22f, OutlineGrey)

            // amber download badge
            drawCircle(Amber, radius = 23f, center = Offset(145f, 126f))
            drawLine(OnAmber, Offset(145f, 114f), Offset(145f, 134f), strokeWidth = 5f, cap = StrokeCap.Round)
            val arrow = Path().apply {
                moveTo(136f, 126f)
                lineTo(145f, 135f)
                lineTo(154f, 126f)
            }
            drawPath(arrow, OnAmber, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))

            sparks(Offset(154f, 1f), Offset(160f, 12f), Offset(166f, 12f), Offset(180f, 20f))
        }
    }
}
