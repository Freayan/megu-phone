package com.megu.phone.data

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.SharedPreferences
import android.os.StatFs
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.ParserException
import androidx.media3.common.StreamKey
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.FileDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadHelper
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import com.megu.phone.R
import com.megu.phone.download.MeguDownloadService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLDecoder
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class DlState { Preparing, Queued, Downloading, Paused, Completed, Failed, Removing }

/** A subtitle file saved next to a downloaded episode. */
data class LocalSub(val label: String, val path: String, val isDefault: Boolean)

/** What the screens show for one downloaded (or downloading) episode. */
data class DownloadItem(
    val key: String,
    val animeId: Int,
    val episode: Int,
    val dub: Boolean,
    val animeTitle: String,
    val cover: String?,
    val episodeTitle: String?,
    /** A picture saved on the phone (works offline), or null. */
    val thumbFile: String?,
    /** The online picture, used only when there is no saved one. */
    val thumbUrl: String?,
    val state: DlState,
    /** 0f..1f */
    val progress: Float,
    val bytes: Long,
    val error: String?,
    /** The technical reason behind [error], for troubleshooting a failed download. */
    val detail: String?,
    /** Queued only because there is no connection right now. */
    val waitingForNetwork: Boolean,
    val createdAt: Long
)

/** Everything the player needs to play a finished download without the internet. */
class OfflineSource(
    val url: String,
    val mime: String?,
    val streamKeys: List<StreamKey>,
    val subs: List<LocalSub>,
    val server: StreamServer
)

/**
 * Episode downloads.
 *
 * The video itself is downloaded and kept by Media3's own download system (a download
 * manager plus a cache folder on the phone), which resumes after a lost connection or a
 * restart. This object adds what Media3 doesn't know about: which anime and episode each
 * download is, its picture and subtitle files, and the error to show when it fails.
 *
 * Everything here runs on the main thread. [version] goes up on every change, so a screen
 * that reads it redraws by itself (the same idea as MyList.version).
 */
@OptIn(UnstableApi::class)
object Downloads {
    const val CHANNEL_ID = "megu_downloads"
    const val NOTIFICATION_ID = 7301

    private const val PREFS = "megu_downloads"
    private const val MIN_FREE_BYTES = 300L * 1024 * 1024
    private const val LOW_SPACE_BYTES = 50L * 1024 * 1024
    private const val STOP_USER = 1

    /** Used when Profile > Settings says "Auto" quality, so one episode doesn't fill the phone. */
    private const val DEFAULT_CAP = 720

    /** Read this inside a composable to be redrawn whenever a download changes. */
    var version by mutableIntStateOf(0)
        private set

    private class Meta(
        val key: String,
        val animeId: Int,
        val episode: Int,
        val dub: Boolean,
        val animeTitle: String,
        val cover: String?,
        val episodeTitle: String?,
        val thumbUrl: String?,
        val createdAt: Long
    ) {
        var thumbFile: String? = null
        var streamUrl: String? = null
        var mime: String? = null
        var hardsub: Boolean = false
        var intro: TimeRange? = null
        var outro: TimeRange? = null
        var subs: List<LocalSub> = emptyList()
        var error: String? = null
        var detail: String? = null

        /** Download without the playlist's own subtitle track (set when that track broke the download). */
        var noText: Boolean = false

        /** Which quality variant was downloaded; playback must ask for exactly this one. */
        var streamKeys: List<StreamKey> = emptyList()

        fun toJson(): JSONObject {
            val o = JSONObject()
                .put("key", key)
                .put("animeId", animeId)
                .put("episode", episode)
                .put("dub", dub)
                .put("animeTitle", animeTitle)
                .put("cover", cover)
                .put("episodeTitle", episodeTitle)
                .put("thumbUrl", thumbUrl)
                .put("createdAt", createdAt)
                .put("thumbFile", thumbFile)
                .put("streamUrl", streamUrl)
                .put("mime", mime)
                .put("hardsub", hardsub)
                .put("error", error)
                .put("detail", detail)
                .put("noText", noText)
            intro?.let { o.put("intro", JSONObject().put("start", it.start).put("end", it.end)) }
            outro?.let { o.put("outro", JSONObject().put("start", it.start).put("end", it.end)) }
            val arr = JSONArray()
            for (s in subs) {
                arr.put(
                    JSONObject()
                        .put("label", s.label)
                        .put("path", s.path)
                        .put("default", s.isDefault)
                )
            }
            o.put("subs", arr)
            val keys = JSONArray()
            for (k in streamKeys) {
                keys.put(JSONArray().put(k.periodIndex).put(k.groupIndex).put(k.streamIndex))
            }
            o.put("streamKeys", keys)
            return o
        }
    }

    private fun JSONObject.str(name: String): String? =
        if (has(name) && !isNull(name)) optString(name).takeIf { it.isNotBlank() } else null

    private fun JSONObject.range(name: String): TimeRange? {
        val r = optJSONObject(name) ?: return null
        val start = r.optDouble("start", -1.0)
        val end = r.optDouble("end", -1.0)
        return if (start >= 0 && end > start) TimeRange(start, end) else null
    }

    private fun metaFromJson(o: JSONObject): Meta? {
        val key = o.str("key") ?: return null
        val m = Meta(
            key = key,
            animeId = o.optInt("animeId", 0),
            episode = o.optInt("episode", 0),
            dub = o.optBoolean("dub", false),
            animeTitle = o.str("animeTitle") ?: "Untitled",
            cover = o.str("cover"),
            episodeTitle = o.str("episodeTitle"),
            thumbUrl = o.str("thumbUrl"),
            createdAt = o.optLong("createdAt", 0L)
        )
        if (m.animeId == 0 || m.episode == 0) return null
        m.thumbFile = o.str("thumbFile")
        m.streamUrl = o.str("streamUrl")
        m.mime = o.str("mime")
        m.hardsub = o.optBoolean("hardsub", false)
        m.intro = o.range("intro")
        m.outro = o.range("outro")
        m.error = o.str("error")
        m.detail = o.str("detail")
        m.noText = o.optBoolean("noText", false)
        val subs = ArrayList<LocalSub>()
        val arr = o.optJSONArray("subs")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                val path = s.str("path") ?: continue
                subs.add(LocalSub(s.str("label") ?: "Subtitles", path, s.optBoolean("default", false)))
            }
        }
        m.subs = subs
        val keys = ArrayList<StreamKey>()
        val keyArr = o.optJSONArray("streamKeys")
        if (keyArr != null) {
            for (i in 0 until keyArr.length()) {
                val k = keyArr.optJSONArray(i) ?: continue
                if (k.length() == 3) keys.add(StreamKey(k.optInt(0), k.optInt(1), k.optInt(2)))
            }
        }
        m.streamKeys = keys
        return m
    }

    private class DownloadException(message: String) : Exception(message)

    private var app: Context? = null
    private var prefs: SharedPreferences? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cache: SimpleCache? = null
    private var manager: DownloadManager? = null
    private var notifier: DownloadNotificationHelper? = null

    /** What we know about each download, saved on the phone. */
    private val metas = LinkedHashMap<String, Meta>()

    /** The download manager's own record of each download (its progress and state). */
    private var live = HashMap<String, Download>()

    /** Getting the stream and the extra files ready, before the download manager has it. */
    private val jobs = HashMap<String, Job>()

    /** Handed to the download manager but not reported back yet. */
    private val pending = HashSet<String>()

    /** Being deleted; hidden from the lists right away. */
    private val removing = HashSet<String>()

    /** Retry: waiting for the old entry to be gone before starting afresh. */
    private val restarting = HashSet<String>()
    private val removalWaiters = HashMap<String, () -> Unit>()

    private var poller: Job? = null

    /** Size of the saved pictures and subtitles; -1 means "work it out again". */
    private var extrasBytes = -1L

    // ----------------------------------------------------------------- setup

    fun init(context: Context) {
        if (app != null) return
        val a = context.applicationContext
        app = a
        prefs = a.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        loadMetas()
        NotificationManagerCompat.from(a).createNotificationChannel(
            NotificationChannelCompat.Builder(CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                .setName(a.getString(R.string.dl_channel_name))
                .setDescription(a.getString(R.string.dl_channel_desc))
                .build()
        )
        // Only people who already have downloads need the manager at launch; everyone else
        // gets it the first time they download or play something offline.
        if (metas.isNotEmpty()) scope.launch { ready() }
    }

    /** Used by the download service, which can be started in a fresh process. */
    fun manager(context: Context): DownloadManager {
        init(context)
        return ready() ?: throw IllegalStateException("Downloads are not available on this phone")
    }

    @Synchronized
    private fun ready(): DownloadManager? {
        manager?.let { return it }
        val ctx = app ?: return null
        return try {
            val db = StandaloneDatabaseProvider(ctx)
            val c = SimpleCache(File(baseDir(ctx), "media"), NoOpCacheEvictor(), db)
            val upstream = OkHttpDataSource.Factory(Repo.client).setUserAgent(Repo.UA)
            val m = DownloadManager(ctx, db, c, upstream, Executors.newFixedThreadPool(6))
            m.maxParallelDownloads = 2
            // A new manager starts paused; only the download service un-pauses it otherwise.
            m.resumeDownloads()
            m.addListener(listener)
            cache = c
            manager = m
            loadLive(m)
            m
        } catch (e: Exception) {
            null
        }
    }

    /** Videos and pictures go in the "no backup" folder, so they never fill the cloud backup. */
    private fun baseDir(ctx: Context): File =
        File(ctx.noBackupFilesDir, "downloads").also { it.mkdirs() }

    private fun extrasDir(key: String): File? {
        val ctx = app ?: return null
        return File(baseDir(ctx), "extras/" + key.replace(Regex("[^A-Za-z0-9_-]"), "_"))
    }

    private fun loadLive(m: DownloadManager) {
        val map = HashMap<String, Download>()
        try {
            m.downloadIndex.getDownloads().use { c ->
                while (c.moveToNext()) {
                    val d = c.download
                    map[d.request.id] = d
                }
            }
        } catch (e: Exception) {
            // keep what we have
        }
        live = map
        version++
    }

    private fun loadMetas() {
        val raw = prefs?.getString("items", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val m = metaFromJson(arr.getJSONObject(i)) ?: continue
                metas[m.key] = m
            }
        } catch (e: Exception) {
            // an unreadable list just starts empty
        }
    }

    private fun saveMetas() {
        extrasBytes = -1L
        val arr = JSONArray()
        for (m in metas.values) arr.put(m.toJson())
        prefs?.edit()?.putString("items", arr.toString())?.apply()
    }

    private val listener = object : DownloadManager.Listener {
        override fun onInitialized(downloadManager: DownloadManager) {
            loadLive(downloadManager)
            ensurePolling()
            // Downloads interrupted by a restart carry on, with the notification.
            val unfinished = downloadManager.currentDownloads.any {
                it.state == Download.STATE_QUEUED ||
                    it.state == Download.STATE_DOWNLOADING ||
                    it.state == Download.STATE_RESTARTING
            }
            val ctx = app
            if (unfinished && ctx != null) {
                try {
                    DownloadService.start(ctx, MeguDownloadService::class.java)
                } catch (e: Exception) {
                    // the system won't start it right now; they still run while the app is open
                }
            }
        }

        override fun onDownloadChanged(
            downloadManager: DownloadManager,
            download: Download,
            finalException: Exception?
        ) {
            val id = download.request.id
            live[id] = download
            pending.remove(id)
            val m = metas[id]
            if (m != null) {
                if (download.state == Download.STATE_COMPLETED) {
                    m.error = null
                    m.detail = null
                    saveMetas()
                    postResult(m, true)
                } else if (download.state == Download.STATE_FAILED && !m.dub && !m.noText &&
                    isPlaylistError(finalException)
                ) {
                    // The playlist lists a subtitle track that isn't a real playlist. Start
                    // over without it; the app's own subtitle files are still saved.
                    m.noText = true
                    saveMetas()
                    retry(id)
                } else if (download.state == Download.STATE_FAILED) {
                    m.error = describe(finalException)
                    m.detail = detailOf(finalException)
                    saveMetas()
                    postResult(m, false)
                    val url = m.streamUrl
                    if (url != null) {
                        scope.launch {
                            val result = probeStream(url)
                            m.detail = listOfNotNull(m.detail, result).joinToString("\n")
                            saveMetas()
                            version++
                        }
                    }
                }
            }
            ensurePolling()
            version++
        }

        override fun onDownloadRemoved(downloadManager: DownloadManager, download: Download) {
            val id = download.request.id
            live.remove(id)
            val waiter = removalWaiters.remove(id)
            if (waiter != null) {
                waiter()
            } else if (id in removing) {
                discard(id)
            }
            version++
        }
    }

    /** The download manager only reports state changes, so progress is read twice a second. */
    private fun ensurePolling() {
        if (poller?.isActive == true) return
        poller = scope.launch {
            while (true) {
                val m = manager ?: break
                val current = m.currentDownloads
                if (current.none { it.state == Download.STATE_DOWNLOADING }) break
                for (d in current) live[d.request.id] = d
                version++
                delay(500)
            }
            version++
        }
    }

    // ----------------------------------------------------------------- reading

    private fun derive(m: Meta): DownloadItem {
        val d = live[m.key]
        val state = when {
            m.key in removing -> DlState.Removing
            m.key in restarting || jobs.containsKey(m.key) -> DlState.Preparing
            d != null -> when (d.state) {
                Download.STATE_COMPLETED -> DlState.Completed
                Download.STATE_DOWNLOADING -> DlState.Downloading
                Download.STATE_STOPPED -> DlState.Paused
                Download.STATE_FAILED -> DlState.Failed
                Download.STATE_REMOVING -> DlState.Removing
                else -> DlState.Queued
            }
            m.key in pending -> DlState.Queued
            else -> DlState.Failed
        }
        val percent = d?.percentDownloaded ?: 0f
        val progress = if (state == DlState.Completed) 1f else (percent / 100f).coerceIn(0f, 1f)
        val noNetwork = state == DlState.Queued && (manager?.notMetRequirements ?: 0) != 0
        return DownloadItem(
            key = m.key,
            animeId = m.animeId,
            episode = m.episode,
            dub = m.dub,
            animeTitle = m.animeTitle,
            cover = m.cover,
            episodeTitle = m.episodeTitle,
            thumbFile = m.thumbFile?.takeIf { File(it).exists() },
            thumbUrl = m.thumbUrl ?: m.cover,
            state = state,
            progress = progress,
            bytes = d?.bytesDownloaded ?: 0L,
            error = if (state == DlState.Failed) (m.error ?: "The download was interrupted. Tap retry.") else null,
            detail = if (state == DlState.Failed) m.detail else null,
            waitingForNetwork = noNetwork,
            createdAt = m.createdAt
        )
    }

    fun keyOf(animeId: Int, episode: Int, dub: Boolean): String =
        "$animeId:$episode:" + (if (dub) "dub" else "sub")

    /** Everything in the list, newest first. Read [version] first to be redrawn on changes. */
    fun items(): List<DownloadItem> =
        metas.values.map { derive(it) }
            .filter { it.state != DlState.Removing }
            .sortedByDescending { it.createdAt }

    fun item(animeId: Int, episode: Int, dub: Boolean): DownloadItem? =
        metas[keyOf(animeId, episode, dub)]?.let { derive(it) }?.takeIf { it.state != DlState.Removing }

    /** How many are still on their way (for a badge or a summary line). */
    fun activeCount(): Int = items().count {
        it.state == DlState.Preparing || it.state == DlState.Queued || it.state == DlState.Downloading
    }

    // --------------------------------------------------------------- storage

    /** Space taken by downloaded videos and their pictures and subtitles. */
    fun usedBytes(): Long {
        var extras = extrasBytes
        if (extras < 0L) {
            val ctx = app
            extras = if (ctx == null) 0L else {
                File(baseDir(ctx), "extras").walkTopDown().filter { it.isFile }.sumOf { it.length() }
            }
            extrasBytes = extras
        }
        return (cache?.cacheSpace ?: 0L) + extras
    }

    /** Free space left on the phone. */
    fun freeBytes(): Long {
        val ctx = app ?: return Long.MAX_VALUE
        return try {
            StatFs(baseDir(ctx).path).availableBytes
        } catch (e: Exception) {
            Long.MAX_VALUE
        }
    }

    // -------------------------------------------------------------- playback

    /** The finished download of this episode, or null when it isn't (fully) on the phone. */
    fun offlineSource(animeId: Int, episode: Int, dub: Boolean): OfflineSource? {
        val m = metas[keyOf(animeId, episode, dub)] ?: return null
        if (derive(m).state != DlState.Completed) return null
        val url = m.streamUrl ?: return null
        return OfflineSource(
            url = url,
            mime = m.mime,
            streamKeys = m.streamKeys,
            subs = m.subs.filter { File(it.path).exists() },
            server = StreamServer(
                id = "offline",
                label = "Downloaded",
                url = url,
                subtitles = emptyList(),
                intro = m.intro,
                outro = m.outro,
                hardsub = m.hardsub
            )
        )
    }

    /** Episode numbers of this show that are fully downloaded in this language. */
    fun downloadedEpisodes(animeId: Int, dub: Boolean): List<Int> =
        metas.values
            .filter { it.animeId == animeId && it.dub == dub && derive(it).state == DlState.Completed }
            .map { it.episode }
            .sorted()

    /** A bare-bones show (title and cover) built from downloads, for when the internet is gone. */
    fun stub(animeId: Int): Anime? {
        val m = metas.values.firstOrNull { it.animeId == animeId } ?: return null
        return Anime(
            id = animeId,
            idMal = null,
            title = m.animeTitle,
            romaji = m.animeTitle,
            cover = m.cover,
            banner = null,
            episodes = null,
            duration = null,
            score = null,
            format = null,
            year = null,
            genres = emptyList(),
            description = "",
            status = null,
            nextEpisode = null,
            isAdult = false
        )
    }

    /**
     * Reads the saved video only from the downloads folder: no network at all. Subtitle
     * files (plain files on the phone) pass straight through.
     */
    fun offlineDataSourceFactory(): DataSource.Factory {
        ready()
        val c = cache ?: throw IllegalStateException("Downloads are not available on this phone")
        return CacheDataSource.Factory()
            .setCache(c)
            .setUpstreamDataSourceFactory(FileDataSource.Factory())
            .setCacheWriteDataSinkFactory(null)
    }

    // --------------------------------------------------------------- actions

    /** Starts downloading one episode. Does nothing if it is already downloading or saved. */
    fun start(anime: Anime, episode: Int, dub: Boolean, info: EpisodeMeta?) {
        if (app == null) return
        val key = keyOf(anime.id, episode, dub)
        val existing = metas[key]
        if (existing != null) {
            when (derive(existing).state) {
                DlState.Failed -> retry(key)
                DlState.Removing -> toast("Episode $episode is still being deleted. Try again in a moment.")
                else -> toast("Episode $episode is already in your downloads.")
            }
            return
        }
        val m = Meta(
            key = key,
            animeId = anime.id,
            episode = episode,
            dub = dub,
            animeTitle = anime.title,
            cover = anime.cover,
            episodeTitle = info?.title,
            thumbUrl = info?.image ?: anime.cover,
            createdAt = System.currentTimeMillis()
        )
        metas[key] = m
        launchPrepare(m)
    }

    fun pause(key: String) = sendStopReason(key, STOP_USER, false)

    fun resume(key: String) = sendStopReason(key, Download.STOP_REASON_NONE, true)

    /** Cancels a running download, or deletes a finished or failed one, and frees its space. */
    fun remove(key: String) {
        if (!metas.containsKey(key)) return
        jobs.remove(key)?.cancel()
        restarting.remove(key)
        val wasPending = pending.remove(key)
        removalWaiters.remove(key)
        if (live.containsKey(key)) {
            removing.add(key)
            sendRemove(key)
            watchRemoval(key)
        } else {
            // Handed to the manager but not reported back yet: the add is still on its way,
            // so the remove is sent behind it (they arrive in order).
            if (wasPending) sendRemove(key)
            discard(key)
        }
        version++
    }

    fun removeAll() {
        for (key in metas.keys.toList()) remove(key)
    }

    /**
     * Tries a failed download again from the beginning. The stream link is fetched afresh
     * (links expire), so the old partial download is removed first.
     */
    fun retry(key: String) {
        val m = metas[key] ?: return
        if (jobs.containsKey(key)) return
        if (live.containsKey(key)) {
            restarting.add(key)
            removalWaiters[key] = { launchPrepare(m) }
            sendRemove(key)
            watchRemoval(key)
            version++
        } else {
            launchPrepare(m)
        }
    }

    // ------------------------------------------------------------- internals

    /**
     * Asking the manager to remove something it doesn't hold gets no answer back, so a removal
     * that is still unanswered after a while is checked against the manager's own records.
     */
    private fun watchRemoval(key: String) {
        scope.launch {
            delay(8_000L)
            if (key !in removing && !removalWaiters.containsKey(key)) return@launch
            val held = try {
                manager?.downloadIndex?.getDownload(key)
            } catch (e: Exception) {
                null
            }
            if (held == null) {
                live.remove(key)
                val waiter = removalWaiters.remove(key)
                if (waiter != null) waiter() else discard(key)
                version++
            }
        }
    }

    private fun launchPrepare(m: Meta) {
        restarting.remove(m.key)
        m.error = null
        m.detail = null
        saveMetas()
        val job = scope.launch {
            val self = coroutineContext[Job]
            try {
                prepareAndEnqueue(m)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = if (e is DownloadException) {
                    e.message ?: "The download couldn't start."
                } else {
                    "Couldn't start the download. Tap retry.\n" + technicalDetail(e)
                }
                m.error = msg
                m.detail = detailOf(e)
                saveMetas()
                toast("Episode ${m.episode}: $msg")
            } finally {
                if (jobs[m.key] === self) jobs.remove(m.key)
                version++
            }
        }
        jobs[m.key] = job
        version++
    }

    private suspend fun prepareAndEnqueue(m: Meta) {
        val ctx = app ?: throw DownloadException("The app isn't ready yet. Try again.")
        if (ready() == null) throw DownloadException("Downloads are not available on this phone.")
        if (freeBytes() < MIN_FREE_BYTES) {
            throw DownloadException("Not enough storage space. Free some up and tap retry.")
        }

        val servers = Repo.resolveStream(m.animeId, m.episode, m.dub)
        if (servers.isEmpty()) {
            throw DownloadException("No stream found for this episode. Try again later.")
        }

        // Use the first server whose stream can actually be read.
        var request: DownloadRequest? = null
        var chosen: StreamServer? = null
        for (s in servers) {
            try {
                request = withTimeout(30_000L) { prepareRequest(ctx, m.key, s.url, !m.dub && !m.noText) }
                chosen = s
                break
            } catch (e: TimeoutCancellationException) {
                // try the next server
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // try the next server
            }
        }
        val req = request
        val server = chosen
        if (req == null || server == null) {
            throw DownloadException("None of the servers could be read for this episode. Try again later.")
        }

        // The picture and subtitle files are small; the episode still downloads without them.
        val dir = extrasDir(m.key)
        var thumbPath: String? = null
        val subs = ArrayList<LocalSub>()
        if (dir != null) {
            val thumbSource = m.thumbUrl
            if (thumbSource != null) {
                val bytes = fetchBytes(thumbSource, 3 * 1024 * 1024)
                if (bytes != null && writeFile(File(dir, "thumb.img"), bytes)) {
                    thumbPath = File(dir, "thumb.img").path
                }
            }
            for ((i, t) in server.subtitles.take(6).withIndex()) {
                val bytes = fetchBytes(t.url, 2 * 1024 * 1024) ?: continue
                val f = File(dir, "sub_$i." + subtitleExtension(t.url))
                if (writeFile(f, bytes)) subs.add(LocalSub(t.label, f.path, t.isDefault))
            }
        }

        m.thumbFile = thumbPath
        m.subs = subs
        m.streamUrl = req.uri.toString()
        m.mime = req.mimeType
        m.streamKeys = req.streamKeys
        m.hardsub = server.hardsub
        m.intro = server.intro
        m.outro = server.outro
        m.error = null
        saveMetas()

        pending.add(m.key)
        sendAdd(req)
        scope.launch {
            // If the download manager never reports it, stop showing it as queued.
            delay(20_000L)
            if (pending.remove(m.key)) version++
        }
    }

    /**
     * Reads the stream's playlist and picks ONE video quality (not every quality the
     * server offers), so the download is a sensible size. The quality limit from
     * Profile > Settings is used; with "Auto" it is 720p.
     */
    private suspend fun prepareRequest(
        ctx: Context,
        id: String,
        url: String,
        withText: Boolean
    ): DownloadRequest =
        suspendCancellableCoroutine { cont ->
            val item = MediaItem.Builder().setUri(url).setMimeType(mimeFor(url)).build()
            val factory = dataSourceFor()
            val helper = DownloadHelper.forMediaItem(ctx, item, DefaultRenderersFactory(ctx), factory)
            cont.invokeOnCancellation { helper.release() }
            helper.prepare(object : DownloadHelper.Callback {
                override fun onPrepared(helper: DownloadHelper) {
                    try {
                        val cap = AppSettings.maxQuality.let { if (it > 0) it else DEFAULT_CAP }
                        val params = DownloadHelper.getDefaultTrackSelectorParameters(ctx).buildUpon()
                            .setForceHighestSupportedBitrate(true)
                            .setMaxVideoSize(Int.MAX_VALUE, cap)
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !withText)
                            .setPreferredTextLanguage("en")
                            .build()
                        for (p in 0 until helper.periodCount) {
                            helper.clearTrackSelections(p)
                            helper.addTrackSelection(p, params)
                        }
                        val request = helper.getDownloadRequest(id, null)
                        helper.release()
                        if (cont.isActive) cont.resume(request)
                    } catch (e: Exception) {
                        helper.release()
                        if (cont.isActive) cont.resumeWithException(e)
                    }
                }

                override fun onPrepareError(helper: DownloadHelper, e: IOException) {
                    helper.release()
                    if (cont.isActive) cont.resumeWithException(e)
                }
            })
        }

    private fun dataSourceFor(): DataSource.Factory =
        OkHttpDataSource.Factory(Repo.client).setUserAgent(Repo.UA)

    private fun sendAdd(request: DownloadRequest) {
        val ctx = app ?: return
        try {
            DownloadService.sendAddDownload(
                ctx, MeguDownloadService::class.java, request, Download.STOP_REASON_NONE, true
            )
        } catch (e: Exception) {
            // The system wouldn't start the service (app in the background): add directly.
            manager?.addDownload(request)
        }
    }

    private fun sendStopReason(key: String, reason: Int, foreground: Boolean) {
        val ctx = app ?: return
        try {
            DownloadService.sendSetStopReason(ctx, MeguDownloadService::class.java, key, reason, foreground)
        } catch (e: Exception) {
            manager?.setStopReason(key, reason)
        }
    }

    private fun sendRemove(key: String) {
        val ctx = app ?: return
        try {
            DownloadService.sendRemoveDownload(ctx, MeguDownloadService::class.java, key, false)
        } catch (e: Exception) {
            manager?.removeDownload(key)
        }
    }

    /** Forgets one episode completely: its saved record and its picture / subtitle files. */
    private fun discard(key: String) {
        extrasDir(key)?.deleteRecursively()
        metas.remove(key)
        removing.remove(key)
        saveMetas()
        version++
    }

    /**
     * One sentence saying what to do, then the real error underneath (its type, message and
     * where it was thrown), so a failure can be diagnosed from a screenshot.
     */
    private fun describe(t: Throwable?): String {
        var friendly: String? = null
        var root: Throwable? = t
        var cur = t
        var guard = 0
        while (cur != null && guard < 8) {
            guard++
            root = cur
            val msg = cur.message.orEmpty()
            if (friendly == null) {
                if (msg.contains("ENOSPC") || msg.contains("No space left", ignoreCase = true)) {
                    friendly = "Not enough storage space. Free some up and tap retry."
                } else if (cur is HttpDataSource.InvalidResponseCodeException) {
                    val code = cur.responseCode
                    friendly = if (code == 403 || code == 404 || code == 410) {
                        "The download link expired. Tap retry to get a fresh one."
                    } else {
                        "The server refused the download (HTTP $code). Tap retry."
                    }
                }
            }
            cur = cur.cause
        }
        val sentence = friendly
            ?: if (freeBytes() < LOW_SPACE_BYTES) {
                "Not enough storage space. Free some up and tap retry."
            } else {
                "The download failed. Tap retry."
            }
        return sentence + "\n" + technicalDetail(root)
    }

    private fun technicalDetail(t: Throwable?): String {
        if (t == null) return "Details: the download manager reported no error."
        val frame = t.stackTrace.firstOrNull()
        val where = if (frame != null) {
            " at " + frame.className.substringAfterLast('.') + "." + frame.methodName
        } else {
            ""
        }
        return "Details: " + t.javaClass.simpleName + ": " + (t.message ?: "no message").take(160) + where
    }

    /** "SocketTimeoutException: timeout ← IOException: ..." for the failed-download screen. */
    private fun detailOf(t: Throwable?): String? {
        if (t == null) return null
        val parts = ArrayList<String>()
        var cur: Throwable? = t
        var guard = 0
        while (cur != null && guard < 4) {
            guard++
            val msg = cur.message?.replace('\n', ' ')?.take(160)
            parts.add(cur.javaClass.simpleName + (if (msg.isNullOrBlank()) "" else ": $msg"))
            cur = cur.cause
        }
        return parts.joinToString(" ← ")
    }

    /**
     * Run once after a download fails: reads the stream's playlist and then asks for every
     * entry in it (qualities, audio, subtitles), one line each: what kind it is, the HTTP
     * status and the first characters that came back. A line that doesn't start with
     * "#EXTM3U" for a playlist entry is the one the downloader choked on.
     */
    private suspend fun probeStream(start: String): String =
        withContext(Dispatchers.IO) {
            val out = ArrayList<String>()
            try {
                val master = peek(start)
                out.add("playlist ${master.first}")
                if (master.second.trimStart().startsWith("#EXTM3U")) {
                    val base = start.toHttpUrlOrNull()
                    val targets = ArrayList<Pair<String, String>>()
                    var variantNext = false
                    for (raw in master.second.lineSequence()) {
                        val line = raw.trim()
                        if (line.startsWith("#EXT-X-STREAM-INF")) {
                            variantNext = true
                        } else if (line.startsWith("#EXT-X-MEDIA:")) {
                            val uri = Regex("URI=\"([^\"]+)\"").find(line)?.groupValues?.get(1)
                            val type = Regex("TYPE=([A-Z-]+)").find(line)?.groupValues?.get(1) ?: "MEDIA"
                            if (uri != null) targets.add(type to uri)
                        } else if (line.isNotEmpty() && !line.startsWith("#")) {
                            targets.add((if (variantNext) "VIDEO" else "ENTRY") to line)
                            variantNext = false
                        }
                    }
                    for ((label, rel) in targets.take(10)) {
                        val abs = base?.resolve(rel)?.toString() ?: rel
                        try {
                            out.add("$label ${peek(abs).first}")
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            out.add("$label failed: ${e.javaClass.simpleName}")
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                out.add("failed: ${e.javaClass.simpleName}: ${e.message?.take(80)}")
            }
            "Server check:\n" + out.joinToString("\n")
        }

    /** One request: "200 \"#EXTM3U\"" (status and first characters) plus the first 8 KB of text. */
    private fun peek(url: String): Pair<String, String> {
        val req = Request.Builder().url(url).header("User-Agent", Repo.UA).build()
        return Repo.client.newCall(req).execute().use { resp ->
            val text = String(resp.peekBody(8192).bytes(), Charsets.UTF_8)
            val head = text.take(10).replace(Regex("[^\\x20-\\x7E]"), "?")
            "${resp.code} \"$head\"" to text
        }
    }

    /** True when the downloader read something that isn't an HLS playlist where one belongs. */
    private fun isPlaylistError(t: Throwable?): Boolean {
        var cur: Throwable? = t
        var guard = 0
        while (cur != null && guard < 8) {
            guard++
            if (cur is ParserException && cur.message.orEmpty().contains("EXTM3U")) return true
            cur = cur.cause
        }
        return false
    }

    private suspend fun fetchBytes(url: String, maxBytes: Int): ByteArray? =
        withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder().url(url).header("User-Agent", Repo.UA).build()
                Repo.client.newCall(req).execute().use { resp ->
                    val body = resp.body
                    if (!resp.isSuccessful || body == null || body.contentLength() > maxBytes) {
                        null
                    } else {
                        body.bytes().takeIf { it.size <= maxBytes }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }

    private suspend fun writeFile(file: File, bytes: ByteArray): Boolean =
        withContext(Dispatchers.IO) {
            try {
                file.parentFile?.mkdirs()
                file.writeBytes(bytes)
                true
            } catch (e: Exception) {
                false
            }
        }

    private fun decoded(url: String): String =
        try {
            URLDecoder.decode(url, "UTF-8").lowercase()
        } catch (e: Exception) {
            url.lowercase()
        }

    private fun mimeFor(url: String): String? {
        val d = decoded(url)
        return when {
            d.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            d.contains(".mp4") && !d.contains(".m3u8") -> null
            else -> MimeTypes.APPLICATION_M3U8
        }
    }

    private fun subtitleExtension(url: String): String {
        val d = decoded(url)
        return when {
            d.contains(".srt") -> "srt"
            d.contains(".ass") || d.contains(".ssa") -> "ass"
            else -> "vtt"
        }
    }

    // --------------------------------------------------------- notifications

    private fun helper(ctx: Context): DownloadNotificationHelper =
        notifier ?: DownloadNotificationHelper(ctx, CHANNEL_ID).also { notifier = it }

    private fun openAppIntent(ctx: Context): PendingIntent? {
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: return null
        return PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    /** The ongoing "Downloading…" notification the download service shows. */
    fun progressNotification(ctx: Context, downloads: List<Download>, notMetRequirements: Int): Notification {
        val only = if (downloads.size == 1) metas[downloads[0].request.id] else null
        val text = if (only != null) "${only.animeTitle} · Episode ${only.episode}" else null
        return helper(ctx).buildProgressNotification(
            ctx, R.drawable.ic_download, openAppIntent(ctx), text, downloads, notMetRequirements
        )
    }

    /** "Download complete" or "Download failed" for one episode. */
    @SuppressLint("MissingPermission")
    private fun postResult(m: Meta, ok: Boolean) {
        val ctx = app ?: return
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val text = "${m.animeTitle} · Episode ${m.episode}"
        val n = if (ok) {
            helper(ctx).buildDownloadCompletedNotification(
                ctx, R.drawable.ic_download_done, openAppIntent(ctx), text
            )
        } else {
            helper(ctx).buildDownloadFailedNotification(
                ctx, R.drawable.ic_download, openAppIntent(ctx), text
            )
        }
        try {
            nm.notify(NOTIFICATION_ID + 1 + (m.key.hashCode() and 0xFFFF), n)
        } catch (e: SecurityException) {
            // notifications not allowed; the Downloads screen still shows the result
        }
    }

    private fun toast(text: String) {
        val ctx = app ?: return
        Toast.makeText(ctx, text, Toast.LENGTH_LONG).show()
    }
}
