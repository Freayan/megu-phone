package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.megu.phone.data.AppSettings

private val QUALITIES = listOf(0 to "Auto", 1080 to "1080p", 720 to "720p", 480 to "480p")

/** Appearance and playback options, shown at the bottom of the Profile screen. */
@Composable
fun SettingsSection() {
    Column(Modifier.fillMaxWidth()) {
        Text(
            "Settings",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))

        SettingsCard(title = "Appearance") {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Pure black (AMOLED)", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "A true black background. Saves battery on OLED screens.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = AppSettings.amoled,
                    onCheckedChange = { AppSettings.setAmoled(it) }
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("Accent colour", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AccentPresets.forEachIndexed { index, preset ->
                    val picked = index == AppSettings.accent
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(preset.primary)
                            .then(
                                if (picked) {
                                    Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                } else {
                                    Modifier
                                }
                            )
                            .clickable { AppSettings.setAccent(index) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (picked) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = "${preset.name} (selected)",
                                tint = preset.onPrimary
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCard(title = "Playback") {
            Text("Preferred audio", style = MaterialTheme.typography.bodyLarge)
            Text(
                "Dub is used only for shows and episodes that have one.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !AppSettings.defaultDub,
                    onClick = { AppSettings.setDefaultDub(false) },
                    label = { Text("Sub") }
                )
                FilterChip(
                    selected = AppSettings.defaultDub,
                    onClick = { AppSettings.setDefaultDub(true) },
                    label = { Text("Dub") }
                )
            }
            Spacer(Modifier.height(16.dp))
            Text("Maximum quality", style = MaterialTheme.typography.bodyLarge)
            Text(
                "Lower it to save data. Applies the next time you start an episode.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for ((cap, label) in QUALITIES) {
                    FilterChip(
                        selected = AppSettings.maxQuality == cap,
                        onClick = { AppSettings.setMaxQuality(cap) },
                        label = { Text(label) }
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        content()
    }
}
