package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.megu.phone.data.AppSettings

private val QUALITIES = listOf(0 to "Auto", 1080 to "1080p", 720 to "720p", 480 to "480p")

/** The heading of one setting inside a settings card ("Preferred audio", "Maximum quality"). */
private val SettingHeading
    @Composable get() = MaterialTheme.typography.titleMedium.copy(
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold
    )

/** Appearance and playback options, shown at the bottom of the Profile screen. */
@Composable
fun SettingsSection() {
    Column(Modifier.fillMaxWidth()) {
        Text(
            "Settings",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))

        SettingsCard(title = "Appearance") {
            Text("Theme", style = MaterialTheme.typography.bodyLarge)
            Text(
                "Only the colours change. The layout is the same in every theme.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            val rows = MeguThemes.chunked(4)
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                for (row in rows) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (palette in row) {
                            ThemeTile(
                                palette = palette,
                                picked = palette.id == AppSettings.theme,
                                onPick = { AppSettings.changeTheme(palette.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Pure black background", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "A true black background in any theme. Saves battery on OLED screens.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = AppSettings.amoled,
                    onCheckedChange = { AppSettings.changeAmoled(it) }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCard(title = "Playback") {
            val palette = MaterialTheme.megu
            Text("Preferred audio", style = SettingHeading)
            Spacer(Modifier.height(12.dp))
            SettingsSegmented(
                options = listOf("Sub", "Dub"),
                selected = if (AppSettings.defaultDub) 1 else 0,
                onSelect = { AppSettings.changeDefaultDub(it == 1) },
                height = 50.dp,
                labelSize = 18.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Dub is used only when available.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = palette.elevated)
            Spacer(Modifier.height(16.dp))
            Text("Maximum quality", style = SettingHeading)
            Spacer(Modifier.height(12.dp))
            SettingsSegmented(
                options = QUALITIES.map { it.second },
                selected = QUALITIES.indexOfFirst { it.first == AppSettings.maxQuality },
                onSelect = { AppSettings.changeMaxQuality(QUALITIES[it].first) },
                height = 44.dp,
                labelSize = 16.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Applies the next time you start an episode.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(MeguDims.RadiusCard))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            ),
            color = MaterialTheme.megu.textPrimary
        )
        Spacer(Modifier.height(16.dp))
        content()
    }
}

/** A small preview of one theme: its background, a card, and its accent colour. */
@Composable
private fun ThemeTile(
    palette: MeguPalette,
    picked: Boolean,
    onPick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(MeguDims.RadiusThumb)
    val current = MaterialTheme.megu
    Column(
        modifier
            .clip(shape)
            .clickable(onClick = onPick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(shape)
                .background(palette.background)
                .border(
                    width = if (picked) 2.dp else 1.dp,
                    color = if (picked) current.accent else current.elevated,
                    shape = shape
                )
                .padding(8.dp)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(18.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(palette.card)
            )
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .size(width = 22.dp, height = 8.dp)
                    .clip(CircleShape)
                    .background(palette.accent)
            )
            if (picked) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "${palette.name} (selected)",
                    tint = palette.accent,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(16.dp)
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            palette.name,
            style = MaterialTheme.typography.labelMedium,
            color = if (picked) current.textPrimary else current.textSecondary,
            maxLines = 1
        )
    }
}
