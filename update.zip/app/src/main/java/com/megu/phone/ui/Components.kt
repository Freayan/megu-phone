package com.megu.phone.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.meta
import com.megu.phone.data.scoreText

/** Loading / ready / failed, used by every screen that fetches data. */
sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Ready<T>(val data: T) : Load<T>
    data class Failed(val message: String, val cause: Throwable? = null) : Load<Nothing>
}

@Composable
fun LoadingBox() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
fun ErrorBox(message: String, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Couldn't load this", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text("Try again") }
    }
}

@Composable
fun ScoreBadge(score: Int, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(MaterialTheme.megu.background.copy(alpha = 0.82f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            "★ ${scoreText(score)}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.megu.textPrimary
        )
    }
}

/** Wraps a tap (and optionally a press-and-hold with a small buzz) around any card. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tapOrHold(onClick: () -> Unit, onLongClick: (() -> Unit)?): Modifier {
    val haptic = LocalHapticFeedback.current
    return this.combinedClickable(
        onClick = onClick,
        onLongClick = if (onLongClick != null) {
            {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onLongClick()
            }
        } else null
    )
}

@Composable
fun PosterCard(
    title: String,
    subtitle: String,
    cover: String?,
    score: Int?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    progress: Float = 0f,
    badge: String? = null,
    onLongClick: (() -> Unit)? = null
) {
    Column(modifier.tapOrHold(onClick, onLongClick)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(MeguDims.RadiusThumb))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = cover,
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (score != null) {
                ScoreBadge(score, Modifier.align(Alignment.TopEnd).padding(6.dp))
            }
            if (badge != null) {
                Text(
                    badge,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    maxLines = 1,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .background(MaterialTheme.megu.accent, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            if (progress > 0f) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .height(3.dp)
                        .background(MaterialTheme.megu.accent)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelLarge
        )
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AnimeCard(
    anime: Anime,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null
) {
    PosterCard(
        title = anime.title,
        subtitle = anime.meta(),
        cover = anime.cover,
        score = anime.score,
        onClick = onClick,
        modifier = modifier,
        onLongClick = onLongClick
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(horizontal = MeguDims.ScreenPadding, vertical = 10.dp)
    )
}

@Composable
fun AnimeRow(
    title: String,
    list: List<Anime>,
    onOpen: (Int) -> Unit,
    onLongPress: ((Anime) -> Unit)? = null
) {
    if (list.isEmpty()) return
    Column {
        SectionTitle(title)
        LazyRow(
            contentPadding = PaddingValues(horizontal = MeguDims.ScreenPadding),
            horizontalArrangement = Arrangement.spacedBy(MeguDims.ItemGap)
        ) {
            items(list, key = { it.id }) { anime ->
                AnimeCard(
                    anime,
                    onClick = { onOpen(anime.id) },
                    modifier = Modifier.width(MeguDims.PosterWidth),
                    onLongClick = if (onLongPress != null) ({ onLongPress(anime) }) else null
                )
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** A soft pulsing colour used for the grey placeholder shapes while something loads. */
@Composable
fun pulseColor(): Color {
    val transition = rememberInfiniteTransition(label = "pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    return MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha)
}

/** Grey placeholder posters shown under a row title while the row loads. */
@Composable
fun SkeletonRow(title: String) {
    val color = pulseColor()
    Column {
        SectionTitle(title)
        Row(
            Modifier.padding(horizontal = MeguDims.ScreenPadding),
            horizontalArrangement = Arrangement.spacedBy(MeguDims.ItemGap)
        ) {
            repeat(3) {
                Column(Modifier.width(MeguDims.PosterWidth)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(MeguDims.RadiusThumb))
                            .background(color)
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth(0.8f)
                            .height(10.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(color)
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** Shown in place of one row that failed, so the rest of the page still works. */
@Composable
fun RowFailed(title: String, onRetry: () -> Unit) {
    Column {
        SectionTitle(title)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Couldn't load this row",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onRetry) { Text("Retry") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/**
 * One episode as a card: thumbnail with its number, title, a line of details, and on the right
 * the state of the episode.
 *
 *  - [current]: the card is filled with the accent colour (text and icons switch to the theme's "on accent" colour); [currentLabel] is shown
 *    under the details (for example "Now Playing").
 *  - [playing]: an equaliser icon is shown (the episode that is on screen right now).
 *  - [watched]: a check ring is shown.
 *  - [trailing]: anything else, usually the download button.
 */
@Composable
fun EpisodeRow(
    number: Int,
    title: String?,
    subtitle: String,
    image: String?,
    progress: Float,
    watched: Boolean,
    current: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    currentLabel: String? = null,
    playing: Boolean = false
) {
    val palette = MaterialTheme.megu
    val shape = RoundedCornerShape(MeguDims.RadiusCard)
    // Colours are set explicitly so that nothing in the row depends on whatever content colour
    // the screen around it happens to provide. The selected row is filled with the accent and
    // uses the theme's "on accent" colour (dark on amber) for everything drawn on it.
    val titleColor = if (current) palette.onAccent else palette.textPrimary
    val metaColor = if (current) palette.onAccent.copy(alpha = 0.78f) else palette.textSecondary
    CompositionLocalProvider(LocalContentColor provides titleColor) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = MeguDims.ScreenPadding, vertical = 3.dp)
                .clip(shape)
                .background(if (current) lerp(palette.card, palette.accent, 0.82f) else palette.card)
                .then(
                    if (current) Modifier.border(1.dp, palette.accentText, shape) else Modifier
                )
                .tapOrHold(onClick, onLongClick)
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .width(MeguDims.EpisodeThumbWidth)
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(MeguDims.RadiusThumb))
                    .background(palette.elevated)
            ) {
                if (image != null) {
                    AsyncImage(
                        model = image,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(
                    "$number",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textPrimary,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .background(palette.background.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                if (progress > 0f) {
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth(progress.coerceIn(0f, 1f))
                            .height(3.dp)
                            .background(palette.accent)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title ?: "Episode $number",
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    color = titleColor,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontSize = 18.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                if (subtitle.isNotBlank()) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = metaColor,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (current && currentLabel != null) {
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painterResource(R.drawable.ic_play),
                            contentDescription = null,
                            tint = titleColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            currentLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = titleColor,
                            maxLines = 1
                        )
                    }
                }
            }
            if (playing) {
                Icon(
                    painterResource(R.drawable.ic_equalizer),
                    contentDescription = "Playing now",
                    tint = if (current) palette.onAccent else palette.accent,
                    modifier = Modifier.padding(horizontal = 4.dp).size(24.dp)
                )
            } else if (watched) {
                Icon(
                    painterResource(R.drawable.ic_watched),
                    contentDescription = "Watched",
                    tint = titleColor,
                    modifier = Modifier.padding(horizontal = 4.dp).size(24.dp)
                )
            }
            if (trailing != null) {
                // The download button draws with the content colour and the theme's primary
                // colour (progress ring, "downloaded" tick); on the filled selected row both
                // must be the dark "on accent" colour or they would vanish into the amber.
                if (current) {
                    MaterialTheme(
                        colorScheme = MaterialTheme.colorScheme.copy(primary = palette.onAccent)
                    ) { trailing.invoke() }
                } else {
                    trailing.invoke()
                }
            } else {
                Spacer(Modifier.width(6.dp))
            }
        }
    }
}
