package com.megu.phone.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.megu.phone.R

private data class Tab(
    val route: String,
    val label: String,
    val icon: ImageVector? = null,
    @DrawableRes val iconRes: Int? = null
)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("search", "Search", Icons.Filled.Search),
    Tab("mylist", "My List", Icons.Filled.Favorite),
    Tab("downloads", "Downloads", iconRes = R.drawable.ic_download),
    Tab("profile", "Profile", Icons.Filled.Person)
)

@Composable
fun MeguApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = tabs.any { it.route == route }

    fun goToTab(target: String) {
        nav.navigate(target) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(
                    containerColor = MaterialTheme.megu.surface,
                    contentColor = MaterialTheme.megu.textPrimary,
                    tonalElevation = 0.dp
                ) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = { goToTab(tab.route) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.megu.textPrimary,
                                selectedTextColor = MaterialTheme.megu.textPrimary,
                                unselectedIconColor = MaterialTheme.megu.textSecondary,
                                unselectedTextColor = MaterialTheme.megu.textSecondary,
                                indicatorColor = MaterialTheme.megu.accentContainer
                            ),
                            icon = {
                                if (tab.icon != null) {
                                    Icon(tab.icon, contentDescription = tab.label)
                                } else if (tab.iconRes != null) {
                                    Icon(painterResource(tab.iconRes), contentDescription = tab.label)
                                }
                            },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding).consumeWindowInsets(padding),
            // The default fade is slow (0.7 s); these feel snappier.
            enterTransition = { fadeIn(tween(220)) },
            exitTransition = { fadeOut(tween(120)) },
            popEnterTransition = { fadeIn(tween(220)) },
            popExitTransition = { fadeOut(tween(120)) }
        ) {
            composable("home") {
                HomeScreen(
                    onOpen = { id -> nav.navigate("details/$id") },
                    onSearch = { goToTab("search") },
                    onGoToDownloads = { goToTab("downloads") },
                    onOpenProfile = { goToTab("profile") }
                )
            }
            composable("search") {
                SearchScreen(onOpen = { id -> nav.navigate("details/$id") })
            }
            composable("mylist") {
                MyListScreen(onOpen = { id -> nav.navigate("details/$id") })
            }
            composable("downloads") {
                DownloadsScreen(onOpenAnime = { id -> nav.navigate("details/$id") })
            }
            composable("profile") {
                ProfileScreen()
            }
            composable(
                route = "details/{id}",
                arguments = listOf(navArgument("id") { type = NavType.IntType })
            ) { entry ->
                DetailsScreen(
                    id = entry.arguments?.getInt("id") ?: 0,
                    onBack = { nav.popBackStack() },
                    onOpen = { id -> nav.navigate("details/$id") }
                )
            }
        }
    }
}
