package com.megu.phone.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import com.megu.phone.data.AppSettings

/** One selectable accent colour (the pink one is the original look). */
class AccentPreset(
    val name: String,
    val primary: Color,
    val onPrimary: Color,
    val container: Color,
    val onContainer: Color
)

val AccentPresets = listOf(
    AccentPreset("Sakura", Color(0xFFFF9BB0), Color(0xFF4A0F23), Color(0xFF6B2A41), Color(0xFFFFD9E1)),
    AccentPreset("Sky", Color(0xFF8FCBFF), Color(0xFF00324F), Color(0xFF1F4A68), Color(0xFFD3E8FF)),
    AccentPreset("Mint", Color(0xFF86E0B0), Color(0xFF00391F), Color(0xFF1E5237), Color(0xFFB2F5D0)),
    AccentPreset("Amber", Color(0xFFFFC56B), Color(0xFF442B00), Color(0xFF614000), Color(0xFFFFDEA8)),
    AccentPreset("Lilac", Color(0xFFCDB4FF), Color(0xFF3A1B6E), Color(0xFF52358A), Color(0xFFEADDFF))
)

private fun buildScheme(accent: AccentPreset, amoled: Boolean): ColorScheme {
    return if (amoled) {
        darkColorScheme(
            primary = accent.primary,
            onPrimary = accent.onPrimary,
            primaryContainer = accent.container,
            onPrimaryContainer = accent.onContainer,
            secondary = Color(0xFF9ED0FF),
            onSecondary = Color(0xFF00324F),
            background = Color(0xFF000000),
            onBackground = Color(0xFFEDEDF2),
            surface = Color(0xFF000000),
            onSurface = Color(0xFFEDEDF2),
            surfaceVariant = Color(0xFF1B1B20),
            onSurfaceVariant = Color(0xFFB8B8C4),
            surfaceContainer = Color(0xFF0C0C0F),
            surfaceContainerHigh = Color(0xFF1B1B20),
            outline = Color(0xFF6F6F7A),
            error = Color(0xFFFF8A80)
        )
    } else {
        darkColorScheme(
            primary = accent.primary,
            onPrimary = accent.onPrimary,
            primaryContainer = accent.container,
            onPrimaryContainer = accent.onContainer,
            secondary = Color(0xFF9ED0FF),
            onSecondary = Color(0xFF00324F),
            background = Color(0xFF15101C),
            onBackground = Color(0xFFF1E9F7),
            surface = Color(0xFF1E1729),
            onSurface = Color(0xFFF1E9F7),
            surfaceVariant = Color(0xFF2B2139),
            onSurfaceVariant = Color(0xFFBDB0CC),
            surfaceContainer = Color(0xFF1E1729),
            surfaceContainerHigh = Color(0xFF2B2139),
            outline = Color(0xFF7A6E8A),
            error = Color(0xFFFF8A80)
        )
    }
}

@Composable
fun MeguTheme(content: @Composable () -> Unit) {
    val accent = AccentPresets.getOrElse(AppSettings.accent) { AccentPresets[0] }
    val amoled = AppSettings.amoled
    val scheme = remember(accent, amoled) { buildScheme(accent, amoled) }
    MaterialTheme(colorScheme = scheme, content = content)
}
