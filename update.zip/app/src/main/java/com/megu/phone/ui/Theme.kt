package com.megu.phone.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.ColorDrawable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.megu.phone.data.AppSettings

/*
 * ONE design, many colour themes.
 *
 * Everything that changes between themes is in [MeguPalette] below. Layout, sizes, type and
 * shapes are shared by every theme (see [MeguDims], [MeguTypography] and [MeguShapes]), so
 * switching theme only ever recolours the screen. Screens should read colours from
 * MaterialTheme.colorScheme (which is built from the palette) or MaterialTheme.megu, and
 * never use a literal colour.
 */

/** The colour tokens of one theme. */
@Immutable
class MeguPalette(
    val id: String,
    val name: String,
    /** Page background. */
    val background: Color,
    /** Secondary surface: the navigation bar, search fields, segmented controls. */
    val surface: Color,
    /** Cards and list rows. */
    val card: Color,
    /** Elevated surfaces: dialogs, bottom sheets, menus, the player menu. */
    val elevated: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    /** Text and icons drawn on top of [accent]. */
    val onAccent: Color
) {
    /** A quiet accent tint used for selected rows, chips and the active tab. */
    val accentContainer: Color = lerp(card, accent, 0.24f)

    /**
     * The accent, lightened just enough to be readable as small text on every surface of this
     * theme (WCAG AA, 4.5:1). Fills, icons and bars use [accent] itself.
     */
    val accentText: Color = readableOn(accent, elevated)

    /** The same theme with a true black page background (the "Pure black" setting). */
    fun withPureBlack(): MeguPalette = MeguPalette(
        id, name, Color(0xFF000000), surface, card, elevated, textPrimary, textSecondary, accent, onAccent
    )
}

private fun contrast(a: Color, b: Color): Float {
    val l1 = a.luminance()
    val l2 = b.luminance()
    return (maxOf(l1, l2) + 0.05f) / (minOf(l1, l2) + 0.05f)
}

private fun readableOn(color: Color, surface: Color): Color {
    var t = 0f
    var out = color
    while (contrast(out, surface) < 4.5f && t < 1f) {
        t += 0.05f
        out = lerp(color, Color.White, t)
    }
    return out
}

// ------------------------------------------------------------------ the themes

private val White = Color(0xFFFFFFFF)

/** Black and charcoal surfaces with an amber accent. */
val BlackTheme = MeguPalette(
    id = "black", name = "Black",
    background = Color(0xFF000000), surface = Color(0xFF101010), card = Color(0xFF181818),
    elevated = Color(0xFF222222), textPrimary = White, textSecondary = Color(0xFFB3B3B3),
    accent = Color(0xFFFFB300), onAccent = Color(0xFF1A1200)
)

/** The same interface in purple. */
val PurpleTheme = MeguPalette(
    id = "purple", name = "Purple",
    background = Color(0xFF0D0B12), surface = Color(0xFF15121D), card = Color(0xFF1D1828),
    elevated = Color(0xFF292235), textPrimary = White, textSecondary = Color(0xFFB8B1C7),
    accent = Color(0xFF9B6DFF), onAccent = White
)

// The original accent colours, on surfaces tinted the same way the Purple theme is tinted
// (same lightness and saturation steps, only the hue follows the accent).
private val SakuraTheme = MeguPalette(
    id = "sakura", name = "Sakura",
    background = Color(0xFF120B0C), surface = Color(0xFF1D1214), card = Color(0xFF28181B),
    elevated = Color(0xFF352226), textPrimary = White, textSecondary = Color(0xFFC7B1B6),
    accent = Color(0xFFFF9BB0), onAccent = Color(0xFF4A0F23)
)

private val SkyTheme = MeguPalette(
    id = "sky", name = "Sky",
    background = Color(0xFF0B0F12), surface = Color(0xFF12181D), card = Color(0xFF182128),
    elevated = Color(0xFF222C35), textPrimary = White, textSecondary = Color(0xFFB1BDC7),
    accent = Color(0xFF8FCBFF), onAccent = Color(0xFF00324F)
)

private val MintTheme = MeguPalette(
    id = "mint", name = "Mint",
    background = Color(0xFF0B120E), surface = Color(0xFF121D17), card = Color(0xFF18281F),
    elevated = Color(0xFF22352B), textPrimary = White, textSecondary = Color(0xFFB1C7BB),
    accent = Color(0xFF86E0B0), onAccent = Color(0xFF00391F)
)

private val AmberTheme = MeguPalette(
    id = "amber", name = "Amber",
    background = Color(0xFF120F0B), surface = Color(0xFF1D1912), card = Color(0xFF282218),
    elevated = Color(0xFF352E22), textPrimary = White, textSecondary = Color(0xFFC7BEB1),
    accent = Color(0xFFFFC56B), onAccent = Color(0xFF442B00)
)

private val LilacTheme = MeguPalette(
    id = "lilac", name = "Lilac",
    background = Color(0xFF0D0B12), surface = Color(0xFF16121D), card = Color(0xFF1D1828),
    elevated = Color(0xFF282235), textPrimary = White, textSecondary = Color(0xFFB8B1C7),
    accent = Color(0xFFCDB4FF), onAccent = Color(0xFF3A1B6E)
)

/** Every theme the Profile screen offers, in the order shown. */
val MeguThemes: List<MeguPalette> = listOf(
    BlackTheme, PurpleTheme, SakuraTheme, SkyTheme, MintTheme, AmberTheme, LilacTheme
)

fun paletteFor(id: String): MeguPalette = MeguThemes.firstOrNull { it.id == id } ?: BlackTheme

// ---------------------------------------------------- colours drawn over pictures
// Text, icons and scrims that sit on top of video frames or artwork. They stay the same in
// every theme so they remain readable whatever picture is underneath.

object OnImage {
    val videoBackdrop = Color(0xFF000000)
    val content = Color(0xFFFFFFFF)
    val contentMuted = Color(0xCCFFFFFF)
    val contentDisabled = Color(0x66FFFFFF)
    val scrimLight = Color(0x40000000)
    val scrim = Color(0x73000000)
    val scrimStrong = Color(0x99000000)
    val track = Color(0x55FFFFFF)
}

// ------------------------------------------------------------- shared dimensions

/** Spacing, corner radii and component sizes used by every screen and every theme. */
object MeguDims {
    val ScreenPadding = 16.dp
    val SectionGap = 12.dp
    val ItemGap = 12.dp

    val RadiusCard = 12.dp
    val RadiusThumb = 8.dp
    val RadiusPill = 20.dp

    val PosterWidth = 118.dp
    val ContinueWidth = 232.dp
    val EpisodeThumbWidth = 128.dp
    val HeroHeight = 300.dp
    val BannerHeight = 170.dp

    val Touch = 48.dp
    val Control = 40.dp
}

// ---------------------------------------------------------------- type and shape

private val MeguTypography = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
)

private val MeguShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp)
)

// ------------------------------------------------------------------ the theme

private val LocalPalette = staticCompositionLocalOf { BlackTheme }

/** The current theme's colour tokens: MaterialTheme.megu.card, .accentText and so on. */
val MaterialTheme.megu: MeguPalette
    @Composable
    @ReadOnlyComposable
    get() = LocalPalette.current

private fun buildScheme(p: MeguPalette): ColorScheme = darkColorScheme(
    primary = p.accent,
    onPrimary = p.onAccent,
    primaryContainer = p.accentContainer,
    onPrimaryContainer = p.textPrimary,
    inversePrimary = p.accent,
    secondary = p.accent,
    onSecondary = p.onAccent,
    secondaryContainer = p.accentContainer,
    onSecondaryContainer = p.textPrimary,
    tertiary = p.accent,
    onTertiary = p.onAccent,
    background = p.background,
    onBackground = p.textPrimary,
    surface = p.background,
    onSurface = p.textPrimary,
    surfaceVariant = p.card,
    onSurfaceVariant = p.textSecondary,
    surfaceTint = p.accent,
    inverseSurface = p.textPrimary,
    inverseOnSurface = p.background,
    outline = p.textSecondary.copy(alpha = 0.55f),
    outlineVariant = p.elevated,
    scrim = Color(0xFF000000),
    surfaceBright = p.elevated,
    surfaceDim = p.background,
    surfaceContainerLowest = p.background,
    surfaceContainerLow = p.surface,
    surfaceContainer = p.elevated,
    surfaceContainerHigh = p.elevated,
    surfaceContainerHighest = p.elevated,
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF3A0000)
)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun MeguTheme(content: @Composable () -> Unit) {
    val base = paletteFor(AppSettings.theme)
    val pure = AppSettings.amoled
    val palette = remember(base, pure) { if (pure) base.withPureBlack() else base }
    val scheme = remember(palette) { buildScheme(palette) }

    // Keep the window behind the app the same colour, so there is no flash on rotate or resume.
    val view = LocalView.current
    SideEffect {
        view.context.findActivity()?.window?.setBackgroundDrawable(ColorDrawable(palette.background.toArgb()))
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(
            colorScheme = scheme,
            typography = MeguTypography,
            shapes = MeguShapes,
            content = content
        )
    }
}
