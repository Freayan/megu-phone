package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/*
 * The small building blocks every screen shares, so a title, a chip, a toggle or a search field
 * looks and measures the same wherever it appears. Colours come from the theme only.
 */

/** The title row at the top of a main tab (Home, My List, Downloads, Profile). */
@Composable
fun ScreenHeader(
    title: String,
    modifier: Modifier = Modifier,
    titleColor: Color = MaterialTheme.colorScheme.onBackground,
    trailing: (@Composable RowScope.() -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(start = MeguDims.ScreenPadding, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            style = MaterialTheme.typography.headlineMedium,
            color = titleColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        trailing?.invoke(this)
    }
}

/** The top row of a page you open from a list: a back arrow and the page's title. */
@Composable
fun BackBar(title: String, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(56.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(end = MeguDims.ScreenPadding)
        )
    }
}

/** The pill-shaped two-way switch used for Sub / Dub. The picked side is filled with the accent. */
@Composable
fun SegmentedSelector(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    isEnabled: (Int) -> Boolean = { true }
) {
    val palette = MaterialTheme.megu
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .height(MeguDims.Control)
            .clip(shape)
            .background(palette.surface)
            .border(1.dp, palette.elevated, shape)
            .padding(3.dp)
    ) {
        options.forEachIndexed { index, label ->
            val on = index == selected
            val enabled = isEnabled(index)
            Box(
                Modifier
                    .fillMaxHeight()
                    .defaultMinSize(minWidth = 88.dp)
                    .clip(shape)
                    .background(if (on) palette.accent else Color.Transparent)
                    .selectable(
                        selected = on,
                        enabled = enabled,
                        role = Role.RadioButton,
                        onClick = { onSelect(index) }
                    )
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = when {
                        on -> palette.onAccent
                        enabled -> palette.textSecondary
                        else -> palette.textSecondary.copy(alpha = 0.4f)
                    }
                )
            }
        }
    }
}

/**
 * A full-width segmented control for settings: every option gets an equal share of a dark track,
 * and the picked one sits on the quiet accent tint with bold text. (The Sub / Dub switch on the
 * player and details screens uses [SegmentedSelector], which is filled with the accent.)
 */
@Composable
fun SettingsSegmented(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    labelSize: TextUnit = 16.sp
) {
    val palette = MaterialTheme.megu
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(palette.surface)
            .border(1.dp, palette.elevated, shape)
            .padding(3.dp)
    ) {
        options.forEachIndexed { index, label ->
            val on = index == selected
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(shape)
                    .background(if (on) palette.accentContainer else Color.Transparent)
                    .selectable(
                        selected = on,
                        role = Role.RadioButton,
                        onClick = { onSelect(index) }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    fontSize = labelSize,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    color = if (on) palette.textPrimary else palette.textSecondary,
                    maxLines = 1
                )
            }
        }
    }
}

/** A filter / choice chip. Unpicked chips sit on the card colour, the picked one on the accent tint. */
@Composable
fun MeguChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null
) {
    val palette = MaterialTheme.megu
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = label,
        modifier = modifier,
        enabled = enabled,
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        shape = RoundedCornerShape(MeguDims.RadiusPill),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = palette.card,
            labelColor = palette.textSecondary,
            selectedContainerColor = palette.accentContainer,
            selectedLabelColor = palette.textPrimary
        ),
        border = null
    )
}

/** Colours shared by every text field: a quiet filled box that gets an accent outline when focused. */
@Composable
fun meguFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = MaterialTheme.megu.surface,
    unfocusedContainerColor = MaterialTheme.megu.surface,
    focusedBorderColor = MaterialTheme.megu.accent,
    unfocusedBorderColor = MaterialTheme.megu.elevated,
    cursorColor = MaterialTheme.megu.accent,
    focusedPlaceholderColor = MaterialTheme.megu.textSecondary,
    unfocusedPlaceholderColor = MaterialTheme.megu.textSecondary
)

/** The corner shape of every text field. */
val MeguFieldShape: Shape = RoundedCornerShape(MeguDims.RadiusCard)
