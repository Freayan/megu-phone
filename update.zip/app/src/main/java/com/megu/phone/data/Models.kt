package com.megu.phone.data

data class Anime(
    val id: Int,
    val idMal: Int?,
    val title: String,
    val romaji: String,
    val cover: String?,
    val banner: String?,
    val episodes: Int?,
    val duration: Int?,
    val score: Int?,
    val format: String?,
    val year: Int?,
    val genres: List<String>,
    val description: String,
    val status: String?,
    val nextEpisode: Int?,
    val isAdult: Boolean,
    val related: List<Related> = emptyList()
)

data class Related(
    val id: Int,
    val title: String,
    val cover: String?,
    val relation: String,
    val format: String?
)

/** Answer of https://meguanime.com/api/langinfo?al=<id> */
data class LangInfo(
    val sub: Int,
    val dub: Int,
    val dubEps: List<Int>,
    val hasDub: Boolean
)

/** Episode title / thumbnail from https://api.ani.zip/mappings?anilist_id=<id> */
data class EpisodeMeta(
    val title: String?,
    val image: String?,
    val overview: String?,
    val runtime: Int?
)

data class TimeRange(val start: Double, val end: Double)

data class SubtitleTrack(val url: String, val label: String, val isDefault: Boolean)

/** One playable server for one episode. */
data class StreamServer(
    val id: String,
    val label: String,
    val url: String,
    val subtitles: List<SubtitleTrack>,
    val intro: TimeRange?,
    val outro: TimeRange?,
    val hardsub: Boolean
)

fun Anime.meta(): String =
    listOfNotNull(
        format?.replace('_', ' '),
        year?.toString(),
        episodes?.let { "$it eps" }
    ).joinToString(" • ")

fun Anime.prettyStatus(): String? =
    status?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercase() }

fun scoreText(score: Int): String = "${score / 10}.${score % 10}"

/** Episode numbers to show, for sub or dub. */
fun episodeList(anime: Anime?, lang: LangInfo?, dub: Boolean): List<Int> {
    if (dub && lang != null && lang.hasDub) {
        return if (lang.dubEps.isNotEmpty()) lang.dubEps else (1..lang.dub).toList()
    }
    val fromSite = lang?.sub ?: 0
    val fromAniList = anime?.episodes ?: 0
    val next = anime?.nextEpisode ?: 0
    val count = when {
        fromSite > 0 -> fromSite
        fromAniList > 0 -> fromAniList
        next > 1 -> next - 1
        else -> 0
    }
    return (1..count).toList()
}

/** True when this episode has an English dub. */
fun canDub(lang: LangInfo?, episode: Int): Boolean {
    if (lang == null || !lang.hasDub) return false
    return if (lang.dubEps.isNotEmpty()) lang.dubEps.contains(episode) else lang.dub >= episode
}

/** What Search is asking AniList for: some words and/or filters. */
data class SearchSpec(
    val text: String = "",
    val genre: String? = null,
    val year: Int? = null,
    val season: String? = null,
    val format: String? = null,
    val sort: String? = null
) {
    /** True when anything besides the typed words is set. */
    val hasFilters: Boolean
        get() = genre != null || year != null || season != null || format != null || sort != null

    fun key(): String =
        listOf(text.trim().lowercase(), genre, year, season, format, sort).joinToString("|")
}
