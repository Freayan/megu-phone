package com.megu.phone.data

import okhttp3.Response
import org.json.JSONException
import java.io.IOException

/** The server answered, but with an error status (401, 404, 429, 503, ...). */
class HttpStatusException(
    val code: Int,
    val retryAfterSeconds: Long?,
    message: String
) : IOException(message)

/** The server answered 200 but with nothing usable in it. */
class BadResponseException(message: String) : IOException(message)

/** What went wrong with a load, in terms of what the person should see and be able to do. */
sealed interface LoadProblem {
    /** The phone has no working internet. */
    data object Offline : LoadProblem

    /** Internet is fine, but the server or the connection to it failed for now. Worth retrying. */
    data object Temporary : LoadProblem

    /** The server asked us to wait before asking again (HTTP 429). */
    data class RateLimited(val waitSeconds: Long) : LoadProblem

    /** HTTP 401. */
    data object Unauthorized : LoadProblem

    /** HTTP 403. */
    data object Forbidden : LoadProblem

    /** HTTP 404. */
    data object NotFound : LoadProblem

    /** Other 4xx: the request itself was wrong, so retrying the same thing won't help. */
    data object InvalidRequest : LoadProblem

    /** Something we did not expect at all. */
    data object Unexpected : LoadProblem
}

/** Default wait when a 429 comes without a Retry-After header. */
private const val DEFAULT_RATE_LIMIT_WAIT_SECONDS = 60L

/** Reads the Retry-After header (seconds, or a date) as a number of seconds, or null. */
internal fun retryAfterSeconds(resp: Response): Long? {
    val raw = resp.header("Retry-After")?.trim() ?: return null
    val seconds = raw.toLongOrNull()
    if (seconds != null) return seconds.coerceIn(1L, 3600L)
    val date = resp.headers.getDate("Retry-After") ?: return null
    return ((date.time - System.currentTimeMillis()) / 1000L).coerceIn(1L, 3600L)
}

/**
 * Turns a failure into a LoadProblem.
 *
 * A failed connection (DNS, timeout, reset) only means "offline" when the phone really has no
 * internet. When the phone does have internet it is a temporary problem with the server or the
 * route to it, and the person must not be told they are offline.
 */
fun classifyFailure(e: Throwable, online: Boolean = NetworkMonitor.online): LoadProblem {
    return when (e) {
        is HttpStatusException -> when (e.code) {
            401 -> LoadProblem.Unauthorized
            403 -> LoadProblem.Forbidden
            404 -> LoadProblem.NotFound
            408 -> LoadProblem.Temporary
            429 -> LoadProblem.RateLimited(e.retryAfterSeconds ?: DEFAULT_RATE_LIMIT_WAIT_SECONDS)
            in 500..599 -> LoadProblem.Temporary
            in 400..499 -> LoadProblem.InvalidRequest
            else -> LoadProblem.Unexpected
        }
        is BadResponseException -> LoadProblem.Temporary
        is JSONException -> LoadProblem.Temporary
        // UnknownHostException, SocketTimeoutException, ConnectException, SSL and reset errors
        // are all IOExceptions that did not come with a server answer.
        is IOException -> if (online) LoadProblem.Temporary else LoadProblem.Offline
        else -> LoadProblem.Unexpected
    }
}

/** A short sentence that is safe to show; never the raw exception text. */
fun friendlyMessage(e: Throwable, online: Boolean = NetworkMonitor.online): String {
    return when (classifyFailure(e, online)) {
        LoadProblem.Offline -> "No internet connection."
        LoadProblem.Temporary -> "Couldn't connect right now. Please try again."
        is LoadProblem.RateLimited -> "Too many requests. Please wait a moment and try again."
        LoadProblem.Unauthorized -> "Please sign in and try again."
        LoadProblem.Forbidden -> "This isn't available for your account."
        LoadProblem.NotFound -> "We couldn't find that."
        LoadProblem.InvalidRequest, LoadProblem.Unexpected -> "Something went wrong."
    }
}
