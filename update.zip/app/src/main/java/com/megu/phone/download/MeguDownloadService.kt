package com.megu.phone.download

import android.app.Notification
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import com.megu.phone.R
import com.megu.phone.data.Downloads

/**
 * Keeps episode downloads running while the app is in the background, with the usual
 * "Downloading…" notification. The download manager itself lives in [Downloads].
 */
@OptIn(UnstableApi::class)
class MeguDownloadService : DownloadService(
    Downloads.NOTIFICATION_ID,
    DownloadService.DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    Downloads.CHANNEL_ID,
    R.string.dl_channel_name,
    R.string.dl_channel_desc
) {
    override fun getDownloadManager(): DownloadManager = Downloads.manager(applicationContext)

    // No background scheduler: after a restart the manager resumes when the app next opens.
    override fun getScheduler(): Scheduler? = null

    override fun getForegroundNotification(
        downloads: MutableList<Download>,
        notMetRequirements: Int
    ): Notification = Downloads.progressNotification(this, downloads, notMetRequirements)
}
