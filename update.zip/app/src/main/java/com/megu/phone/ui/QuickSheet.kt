package com.megu.phone.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.AppSettings
import com.megu.phone.data.Anime
import com.megu.phone.data.MyList
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.canDub
import com.megu.phone.data.meta
import com.megu.phone.player.PlayerActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Plays [episode] of a show. If you prefer Dub (Profile > Settings) it is used when the show
 * has a dub for that episode, otherwise it plays Sub.
 */
fun startPlayback(context: Context, scope: CoroutineScope, animeId: Int, episode: Int) {
    if (!AppSettings.defaultDub) {
        PlayerActivity.start(context, animeId, episode, false)
        return
    }
    scope.launch {
        val dub = canDub(Repo.langInfo(animeId), episode)
        PlayerActivity.start(context, animeId, episode, dub)
    }
}

/** Plays a show: continues where you left off, or starts at episode 1. */
fun playShow(context: Context, scope: CoroutineScope, animeId: Int) {
    val resume = Progress.continueWatching().firstOrNull { it.animeId == animeId }
    if (resume != null) {
        PlayerActivity.start(context, animeId, resume.episode, resume.dub)
    } else {
        startPlayback(context, scope, animeId, 1)
    }
}

/** One tappable line in a bottom sheet, with an optional small icon in front. */
@Composable
fun SheetAction(
    label: String,
    onClick: () -> Unit,
    color: Color = Color.Unspecified,
    leading: (@Composable () -> Unit)? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(36.dp)) { leading?.invoke() }
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
    }
}

/**
 * The little menu that opens when you press and hold a poster on Home or Search:
 * play, add to / remove from My List, or open the details page.
 * [scope] must outlive the sheet (use the screen's scope), so playback can still start.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickSheet(
    anime: Anime,
    scope: CoroutineScope,
    onDismiss: () -> Unit,
    onOpen: (Int) -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val saved = remember(MyList.version, anime.id) { MyList.contains(anime.id) }
    val resume = remember(anime.id) {
        Progress.continueWatching().firstOrNull { it.animeId == anime.id }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(56.dp)
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        anime.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        anime.meta(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            SheetAction(
                label = if (resume != null) "Continue episode ${resume.episode}" else "Play episode 1",
                leading = {
                    Icon(painterResource(R.drawable.ic_play), contentDescription = null)
                },
                onClick = {
                    playShow(context, scope, anime.id)
                    onDismiss()
                }
            )
            SheetAction(
                label = if (saved) "Remove from My List" else "Add to My List",
                leading = {
                    Icon(
                        if (saved) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = null
                    )
                },
                onClick = {
                    MyList.toggle(anime)
                    onDismiss()
                }
            )
            SheetAction(
                label = "Open details",
                onClick = {
                    onDismiss()
                    onOpen(anime.id)
                }
            )
        }
    }
}
