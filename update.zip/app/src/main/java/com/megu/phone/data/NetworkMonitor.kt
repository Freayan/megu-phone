package com.megu.phone.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Tells the app whether the phone really has internet.
 *
 * "Connected to Wi-Fi" is not enough: a router with no uplink, a login (captive portal) page
 * or a dead mobile plan all look connected. Android probes the network and marks one that
 * really reaches the internet as VALIDATED, so that is what this checks.
 *
 * This is only about the phone. Whether one particular request worked is a separate question,
 * answered by the request itself (see LoadErrors.kt).
 */
object NetworkMonitor {
    /** True only while the active network is validated. Reading it inside a composable redraws on change. */
    var online by mutableStateOf(true)
        private set

    private var manager: ConnectivityManager? = null
    private var started = false

    fun init(context: Context) {
        if (started) return
        val cm = context.applicationContext
            .getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) {
            // No connectivity service: never block the app because of it.
            started = true
            return
        }
        started = true
        manager = cm
        online = read(cm)
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    online = read(cm)
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    online = reaches(caps)
                }

                override fun onLost(network: Network) {
                    // The default network went away and nothing replaced it.
                    online = read(cm)
                }
            })
        } catch (e: Exception) {
            // Can't listen for changes; refresh() still gives a fresh answer when asked.
        }
    }

    /** Asks the system again right now (used by Try Again) and returns the answer. */
    fun refresh(): Boolean {
        val cm = manager ?: return online
        val now = read(cm)
        online = now
        return now
    }

    private fun read(cm: ConnectivityManager): Boolean {
        val network = try {
            cm.activeNetwork
        } catch (e: Exception) {
            null
        } ?: return false
        val caps = try {
            cm.getNetworkCapabilities(network)
        } catch (e: Exception) {
            null
        } ?: return false
        return reaches(caps)
    }

    private fun reaches(caps: NetworkCapabilities): Boolean {
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) &&
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)
    }
}
