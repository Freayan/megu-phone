package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.DlState
import com.megu.phone.data.DownloadItem
import com.megu.phone.data.Downloads
import com.megu.phone.player.PlayerActivity
import java.io.File

/** Everything saved for offline watching, with how much space it takes. */
@Composable
fun DownloadsScreen(onOpenAnime: (Int) -> Unit) {
    val context = LocalContext.current

    // Reading the version redraws this screen as downloads progress.
    val version = Downloads.version
    val list = remember(version) { Downloads.items() }
    val used = remember(version) { Downloads.usedBytes() }
    val free = remember(version) { Downloads.freeBytes() }

    var confirmAll by remember { mutableStateOf(false) }
    var confirmOne by remember { mutableStateOf<DownloadItem?>(null) }

    val groups = remember(list) {
        list.groupBy { it.animeId }.values
            .map { group -> group.sortedBy { it.episode } }
            .sortedByDescending { group -> group.maxOf { it.createdAt } }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 8.dp, top = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Downloads",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.weight(1f)
            )
            if (list.isNotEmpty()) {
                TextButton(onClick = { confirmAll = true }) { Text("Delete all") }
            }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                "Downloads use ${formatBytes(used)}",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "${formatBytes(free)} free on this phone",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (list.isEmpty()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    painterResource(R.drawable.ic_download),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text("No downloads yet", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Tap the download icon next to an episode to watch it later, even without internet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                for (group in groups) {
                    val first = group.first()
                    item(key = "show-${first.animeId}") {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onOpenAnime(first.animeId) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                first.animeTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                if (group.size == 1) "1 episode" else "${group.size} episodes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    items(group, key = { it.key }) { item ->
                        DownloadRow(
                            item = item,
                            onPlay = {
                                PlayerActivity.start(context, item.animeId, item.episode, item.dub)
                            },
                            onAskDelete = { confirmOne = item }
                        )
                    }
                    item(key = "gap-${first.animeId}") {
                        HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    }
                }
            }
        }
    }

    confirmOne?.let { item ->
        AlertDialog(
            onDismissRequest = { confirmOne = null },
            title = { Text("Delete this download?") },
            text = {
                Text(
                    "Episode ${item.episode} of ${item.animeTitle} will be removed from this phone " +
                        "and its space freed. You can download it again later."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Downloads.remove(item.key)
                    confirmOne = null
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmOne = null }) { Text("Keep") }
            }
        )
    }

    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Delete all downloads?") },
            text = {
                Text(
                    "Every downloaded episode will be removed from this phone, freeing " +
                        "${formatBytes(used)}. Downloads still in progress are cancelled."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Downloads.removeAll()
                    confirmAll = false
                }) { Text("Delete all", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmAll = false }) { Text("Keep") }
            }
        )
    }
}

@Composable
private fun DownloadRow(
    item: DownloadItem,
    onPlay: () -> Unit,
    onAskDelete: () -> Unit
) {
    val done = item.state == DlState.Completed
    val failed = item.state == DlState.Failed
    val thumb: Any? = item.thumbFile?.let { File(it) } ?: item.thumbUrl

    Row(
        Modifier
            .fillMaxWidth()
            .then(if (done) Modifier.clickable { onPlay() } else Modifier)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(112.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = thumb,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Text(
                "${item.episode}",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .background(Color(0xAA15101C), RoundedCornerShape(bottomEnd = 8.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            if (done) {
                Icon(
                    painterResource(R.drawable.ic_play),
                    contentDescription = "Play offline",
                    tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(32.dp)
                        .background(Color(0x8015101C), RoundedCornerShape(16.dp))
                        .padding(6.dp)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.episodeTitle ?: "Episode ${item.episode}",
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "Episode ${item.episode} · " + (if (item.dub) "Dub" else "Sub"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                downloadStatus(item),
                style = MaterialTheme.typography.bodySmall,
                color = when {
                    failed -> MaterialTheme.colorScheme.error
                    done -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            when (item.state) {
                DlState.Downloading, DlState.Paused -> {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { item.progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                DlState.Preparing, DlState.Queued -> {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                else -> {}
            }
        }
        when (item.state) {
            DlState.Downloading, DlState.Queued -> {
                IconButton(onClick = { Downloads.pause(item.key) }) {
                    Icon(painterResource(R.drawable.ic_pause), contentDescription = "Pause")
                }
                IconButton(onClick = { Downloads.remove(item.key) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancel download")
                }
            }
            DlState.Paused -> {
                IconButton(onClick = { Downloads.resume(item.key) }) {
                    Icon(painterResource(R.drawable.ic_play), contentDescription = "Resume")
                }
                IconButton(onClick = { Downloads.remove(item.key) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancel download")
                }
            }
            DlState.Preparing -> {
                IconButton(onClick = { Downloads.remove(item.key) }) {
                    Icon(Icons.Filled.Close, contentDescription = "Cancel download")
                }
            }
            DlState.Failed -> {
                IconButton(onClick = { Downloads.retry(item.key) }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Retry")
                }
                IconButton(onClick = { Downloads.remove(item.key) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Remove")
                }
            }
            DlState.Completed -> {
                IconButton(onClick = onAskDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete download")
                }
            }
            DlState.Removing -> {}
        }
    }
}
