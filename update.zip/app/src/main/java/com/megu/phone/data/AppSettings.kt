package com.megu.phone.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * The few things you can change on the Profile screen: how the app looks and what the
 * player does by default. Stored on the phone. The values are Compose state, so changing
 * one redraws whatever is showing it straight away.
 */
object AppSettings {
    private var prefs: SharedPreferences? = null

    /** The colour theme, by id (see MeguThemes in Theme.kt). Black is the default. */
    var theme by mutableStateOf("black")
        private set

    /** Pure black background in any theme (saves battery on OLED screens). */
    var amoled by mutableStateOf(false)
        private set

    /** Open shows in Dub by default (only when the show actually has a dub). */
    var defaultDub by mutableStateOf(false)
        private set

    /** Highest video height to start with: 0 = automatic, otherwise 1080 / 720 / 480. */
    var maxQuality by mutableIntStateOf(0)
        private set

    /** Press and hold the video to play at 2x until you let go. On by default. */
    var holdFor2x by mutableStateOf(true)
        private set

    /** Show the My List tab in the bottom bar. On by default; the saved list is kept either way. */
    var showMyList by mutableStateOf(true)
        private set

    // The accent colours of earlier versions, in their old order.
    private val legacyAccents = listOf("sakura", "sky", "mint", "amber", "lilac")

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("megu_settings", Context.MODE_PRIVATE)
        prefs = p
        amoled = p.getBoolean("amoled", false)
        // Someone who picked an accent colour in an earlier version keeps it as their theme.
        theme = p.getString("theme", null)
            ?: if (p.contains("accent")) legacyAccents.getOrElse(p.getInt("accent", 0)) { "black" } else "black"
        defaultDub = p.getBoolean("dub", false)
        maxQuality = p.getInt("quality", 0)
        holdFor2x = p.getBoolean("hold2x", true)
        showMyList = p.getBoolean("mylist_tab", true)
    }

    fun changeAmoled(value: Boolean) {
        amoled = value
        prefs?.edit()?.putBoolean("amoled", value)?.apply()
    }

    fun changeTheme(id: String) {
        theme = id
        prefs?.edit()?.putString("theme", id)?.apply()
    }

    fun changeDefaultDub(value: Boolean) {
        defaultDub = value
        prefs?.edit()?.putBoolean("dub", value)?.apply()
    }

    fun changeMaxQuality(height: Int) {
        maxQuality = height
        prefs?.edit()?.putInt("quality", height)?.apply()
    }

    fun changeHoldFor2x(value: Boolean) {
        holdFor2x = value
        prefs?.edit()?.putBoolean("hold2x", value)?.apply()
    }

    fun changeShowMyList(value: Boolean) {
        showMyList = value
        prefs?.edit()?.putBoolean("mylist_tab", value)?.apply()
    }
}
