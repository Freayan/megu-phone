package com.megu.phone.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * The few things you can change on the Profile screen: how the app looks and what the
 * player does by default. Stored on the phone. The values are Compose state, so changing
 * one redraws whatever is showing it straight away.
 */
object AppSettings {
    private var prefs: SharedPreferences? = null

    /** Pure black background (saves battery on OLED screens). */
    var amoled by mutableStateOf(false)
        private set

    /** Index into the accent colour list in Theme.kt. */
    var accent by mutableIntStateOf(0)
        private set

    /** Open shows in Dub by default (only when the show actually has a dub). */
    var defaultDub by mutableStateOf(false)
        private set

    /** Highest video height to start with: 0 = automatic, otherwise 1080 / 720 / 480. */
    var maxQuality by mutableIntStateOf(0)
        private set

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("megu_settings", Context.MODE_PRIVATE)
        prefs = p
        amoled = p.getBoolean("amoled", false)
        accent = p.getInt("accent", 0)
        defaultDub = p.getBoolean("dub", false)
        maxQuality = p.getInt("quality", 0)
    }

    fun changeAmoled(value: Boolean) {
        amoled = value
        prefs?.edit()?.putBoolean("amoled", value)?.apply()
    }

    fun changeAccent(index: Int) {
        accent = index
        prefs?.edit()?.putInt("accent", index)?.apply()
    }

    fun changeDefaultDub(value: Boolean) {
        defaultDub = value
        prefs?.edit()?.putBoolean("dub", value)?.apply()
    }

    fun changeMaxQuality(height: Int) {
        maxQuality = height
        prefs?.edit()?.putInt("quality", height)?.apply()
    }
}
