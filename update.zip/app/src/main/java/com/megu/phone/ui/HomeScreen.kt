package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.LoadProblem
import com.megu.phone.data.NetworkMonitor
import com.megu.phone.data.MyList
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.Sync
import com.megu.phone.data.WatchEntry
import com.megu.phone.data.classifyFailure
import com.megu.phone.data.friendlyMessage
import com.megu.phone.data.scoreText
import com.megu.phone.player.PlayerActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Runs one request and turns the outcome into Ready / Failed, so one bad row can't break the page. */
private suspend fun <T> loadRow(block: suspend () -> T): Load<T> {
    return try {
        Load.Ready(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Load.Failed(friendlyMessage(e), e)
    }
}

/**
 * What to tell the person when Home has nothing to show. No internet wins; otherwise the most
 * specific cause among the failed rows (a 401 or 404 says more than a timeout).
 */
private fun pickProblem(rows: List<Load<List<Anime>>>): LoadProblem {
    if (!NetworkMonitor.online) return LoadProblem.Offline
    val problems = rows.mapNotNull { row ->
        (row as? Load.Failed)?.cause?.let { classifyFailure(it) }
    }
    return problems.firstOrNull { it is LoadProblem.RateLimited }
        ?: problems.firstOrNull { it == LoadProblem.Unauthorized }
        ?: problems.firstOrNull { it == LoadProblem.Forbidden }
        ?: problems.firstOrNull { it == LoadProblem.NotFound }
        ?: problems.firstOrNull { it == LoadProblem.InvalidRequest }
        ?: problems.firstOrNull { it == LoadProblem.Temporary }
        ?: problems.firstOrNull()
        ?: LoadProblem.Temporary
}

/** Shortest gap between two reloads that the app starts by itself when internet comes back. */
private const val AUTO_RELOAD_GAP_MS = 5_000L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpen: (Int) -> Unit,
    onSearch: () -> Unit,
    onGoToDownloads: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    // Every row loads on its own, so one failing request doesn't blank the whole page.
    var trending by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var popular by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var airing by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var topRated by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var reload by remember { mutableIntStateOf(0) }
    var refreshing by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var sheetFor by remember { mutableStateOf<Anime?>(null) }

    // Why Home has nothing to show (null while it has content or is still loading).
    var problem by remember {
        mutableStateOf<LoadProblem?>(if (NetworkMonitor.online) null else LoadProblem.Offline)
    }
    // True from the moment Try Again is pressed until that attempt has finished.
    var retrying by remember { mutableStateOf(false) }
    // After HTTP 429: no request is sent before this time (Retry-After).
    var blockedUntil by remember { mutableLongStateOf(0L) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastAutoReload by remember { mutableLongStateOf(0L) }
    val online = NetworkMonitor.online

    // Refresh "Continue watching" every time the screen comes back (e.g. from the player).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val continueEntries = remember(tick, Progress.version) { Progress.continueWatching() }

    LaunchedEffect(reload) {
        val hasContent = trending is Load.Ready || popular is Load.Ready ||
            airing is Load.Ready || topRated is Load.Ready

        // A 429 told us to wait: don't ask again before that, whoever asked.
        if (System.currentTimeMillis() < blockedUntil) {
            refreshing = false
            retrying = false
            return@LaunchedEffect
        }
        // No internet: don't call the API at all. Offline is only about the phone's connection.
        if (!NetworkMonitor.refresh()) {
            refreshing = false
            retrying = false
            if (hasContent) {
                snackbar.currentSnackbarData?.dismiss()
                snackbar.showSnackbar("You're offline")
            } else {
                problem = LoadProblem.Offline
            }
            return@LaunchedEffect
        }

        if (trending !is Load.Ready) trending = Load.Loading
        if (popular !is Load.Ready) popular = Load.Loading
        if (airing !is Load.Ready) airing = Load.Loading
        if (topRated !is Load.Ready) topRated = Load.Loading
        // A refresh that fails keeps what is already on screen.
        coroutineScope {
            launch {
                val r = loadRow { Repo.page("TRENDING_DESC") }
                if (r is Load.Ready || trending !is Load.Ready) trending = r
            }
            launch {
                val r = loadRow { Repo.page("POPULARITY_DESC") }
                if (r is Load.Ready || popular !is Load.Ready) popular = r
            }
            launch {
                val r = loadRow { Repo.page("POPULARITY_DESC", "RELEASING") }
                if (r is Load.Ready || airing !is Load.Ready) airing = r
            }
            launch {
                val r = loadRow { Repo.page("SCORE_DESC") }
                if (r is Load.Ready || topRated !is Load.Ready) topRated = r
            }
        }
        refreshing = false

        val rows = listOf(trending, popular, airing, topRated)
        val anyReady = rows.any { it is Load.Ready }
        // Remember a "wait" from the server so nothing asks again too soon.
        for (row in rows) {
            val cause = (row as? Load.Failed)?.cause ?: continue
            val c = classifyFailure(cause)
            if (c is LoadProblem.RateLimited) {
                blockedUntil = maxOf(blockedUntil, System.currentTimeMillis() + c.waitSeconds * 1000L)
            }
        }
        problem = if (anyReady) null else pickProblem(rows)
        retrying = false
    }

    // Counts the 429 wait down on screen.
    LaunchedEffect(problem, blockedUntil) {
        while (System.currentTimeMillis() < blockedUntil) {
            nowMs = System.currentTimeMillis()
            delay(500)
        }
        nowMs = System.currentTimeMillis()
    }

    // Keep watching the connection while a problem screen is up.
    LaunchedEffect(online) {
        val shown = problem
        if (!online) {
            // Internet went away while "couldn't connect" was showing: it is now an offline problem.
            if (shown == LoadProblem.Temporary) problem = LoadProblem.Offline
        } else if (shown != null) {
            // Internet is back. Wait a moment (quick on/off flapping restarts this wait), then
            // reload once, and never more often than every few seconds.
            delay(1_500)
            val now = System.currentTimeMillis()
            if (NetworkMonitor.online && problem != null && !retrying &&
                now >= blockedUntil && now - lastAutoReload >= AUTO_RELOAD_GAP_MS
            ) {
                lastAutoReload = now
                retrying = true
                reload++
            }
        }
    }

    val onTryAgain: () -> Unit = {
        // Ignore extra taps while an attempt is already running.
        if (!retrying && System.currentTimeMillis() >= blockedUntil) {
            retrying = true
            if (NetworkMonitor.refresh()) {
                Repo.clearPageCache()
                reload++
            } else {
                // Still no internet: say so, and drop Try Again.
                problem = LoadProblem.Offline
                retrying = false
            }
        }
    }

    val removeFromContinue: (WatchEntry) -> Unit = { entry ->
        Progress.removeEntry(entry.animeId)
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val result = snackbar.showSnackbar(
                message = "Removed ${entry.title}",
                actionLabel = "Undo",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) Progress.restoreEntry(entry)
        }
    }

    val shownProblem = problem

    Box(Modifier.fillMaxSize()) {
        if (shownProblem != null) {
            val waitSeconds = ((blockedUntil - nowMs + 999L) / 1000L).toInt().coerceAtLeast(0)
            HomeProblemScreen(
                problem = shownProblem,
                retrying = retrying,
                waitSeconds = waitSeconds,
                onTryAgain = onTryAgain,
                onGoToDownloads = onGoToDownloads,
                onOpenProfile = onOpenProfile
            )
        } else {
            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = {
                    refreshing = true
                    Repo.clearPageCache()
                    Sync.pullInBackground()
                    reload++
                },
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    item(key = "title") { HomeHeader(onSearch) }
                    item(key = "hero") {
                        when (val t = trending) {
                            Load.Loading -> HeroSkeleton()
                            is Load.Failed -> {}
                            is Load.Ready -> {
                                val heroes = pickHeroes(t.data)
                                if (heroes.isNotEmpty()) {
                                    HeroCarousel(
                                        list = heroes,
                                        onOpen = onOpen,
                                        onPlay = { a -> playShow(context, scope, a.id) }
                                    )
                                }
                            }
                        }
                    }
                    if (continueEntries.isNotEmpty()) {
                        item(key = "continue") {
                            ContinueRow(
                                entries = continueEntries,
                                onPlay = { e -> PlayerActivity.start(context, e.animeId, e.episode, e.dub) },
                                onRemove = removeFromContinue
                            )
                        }
                    }
                    item(key = "trending") {
                        RowSection("Trending now", trending, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "popular") {
                        RowSection("Popular right now", popular, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "airing") {
                        RowSection("Airing now", airing, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "top") {
                        RowSection("Top rated", topRated, { reload++ }, onOpen) { sheetFor = it }
                    }
                }
            }
        }
        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    sheetFor?.let { picked ->
        QuickSheet(
            anime = picked,
            scope = scope,
            onDismiss = { sheetFor = null },
            onOpen = onOpen
        )
    }
}

@Composable
private fun RowSection(
    title: String,
    state: Load<List<Anime>>,
    onRetry: () -> Unit,
    onOpen: (Int) -> Unit,
    onLongPress: (Anime) -> Unit
) {
    when (state) {
        Load.Loading -> SkeletonRow(title)
        is Load.Failed -> RowFailed(title, onRetry)
        is Load.Ready -> AnimeRow(title, state.data, onOpen, onLongPress)
    }
}

@Composable
private fun HomeHeader(onSearch: () -> Unit) {
    ScreenHeader(
        title = "MeguAnimes",
        titleColor = MaterialTheme.megu.accent,
        trailing = {
            IconButton(onClick = onSearch) {
                Icon(Icons.Filled.Search, contentDescription = "Search")
            }
        }
    )
}

// ------------------------------------------------------------------ hero

/** Up to five trending shows, preferring ones that have a wide banner picture. */
private fun pickHeroes(list: List<Anime>): List<Anime> {
    val withBanner = list.filter { it.banner != null }
    return (if (withBanner.size >= 3) withBanner else list).take(5)
}

@Composable
private fun HeroSkeleton() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(MeguDims.HeroHeight)
            .background(pulseColor())
    )
}

@Composable
private fun HeroCarousel(
    list: List<Anime>,
    onOpen: (Int) -> Unit,
    onPlay: (Anime) -> Unit
) {
    val count = list.size
    val pager = rememberPagerState(pageCount = { list.size })

    // Slide to the next show every few seconds; swiping restarts the timer.
    LaunchedEffect(pager.currentPage, count) {
        if (count > 1) {
            delay(6000)
            if (!pager.isScrollInProgress) {
                pager.animateScrollToPage((pager.currentPage + 1) % count)
            }
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(MeguDims.HeroHeight)
    ) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            HeroPage(list[page], onOpen, onPlay)
        }
        if (count > 1) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                repeat(count) { index ->
                    val on = index == pager.currentPage
                    Box(
                        Modifier
                            .size(width = if (on) 18.dp else 6.dp, height = 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (on) MaterialTheme.megu.accent else OnImage.track
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroPage(anime: Anime, onOpen: (Int) -> Unit, onPlay: (Anime) -> Unit) {
    val saved = remember(MyList.version, anime.id) { MyList.contains(anime.id) }
    val background = MaterialTheme.colorScheme.background
    val detailsLine = listOfNotNull(
        anime.score?.let { "★ ${scoreText(it)}" },
        anime.genres.take(3).joinToString(" • ").ifBlank { null }
    ).joinToString("   ")

    Box(
        Modifier
            .fillMaxSize()
            .clickable { onOpen(anime.id) }
    ) {
        AsyncImage(
            model = anime.banner ?: anime.cover,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, background)))
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, end = 16.dp, bottom = 28.dp)
        ) {
            Text(
                anime.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (detailsLine.isNotBlank()) {
                Text(
                    detailsLine,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onPlay(anime) }) {
                    Icon(
                        painterResource(R.drawable.ic_play),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                FilledTonalButton(onClick = { MyList.toggle(anime) }) {
                    Icon(
                        if (saved) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("My List")
                }
            }
        }
    }
}

// ----------------------------------------------------- continue watching

@Composable
private fun ContinueRow(
    entries: List<WatchEntry>,
    onPlay: (WatchEntry) -> Unit,
    onRemove: (WatchEntry) -> Unit
) {
    Column {
        SectionTitle("Continue watching")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries, key = { it.animeId }) { entry ->
                ContinueCard(entry, onPlay = { onPlay(entry) }, onRemove = { onRemove(entry) })
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** "E7 · Sub · 12 min left" (or "Up next" for an episode you haven't started). */
private fun continueSubtitle(e: WatchEntry): String {
    val language = if (e.dub) "Dub" else "Sub"
    val minutesLeft =
        if (e.durationMs > 0 && e.positionMs > 0) {
            ((e.durationMs - e.positionMs + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        } else {
            0
        }
    return if (minutesLeft > 0) {
        "E${e.episode} · $language · $minutesLeft min left"
    } else {
        "E${e.episode} · $language · Up next"
    }
}

@Composable
private fun ContinueCard(entry: WatchEntry, onPlay: () -> Unit, onRemove: () -> Unit) {
    // The wide still of this episode, if we can find one; otherwise the poster, cropped.
    var still by remember(entry.animeId, entry.episode) { mutableStateOf<String?>(null) }
    LaunchedEffect(entry.animeId, entry.episode) {
        still = Repo.episodeMeta(entry.animeId)[entry.episode]?.image
    }
    val fraction =
        if (entry.durationMs > 0) (entry.positionMs.toFloat() / entry.durationMs).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .width(MeguDims.ContinueWidth)
            .clickable(onClick = onPlay)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(MeguDims.RadiusThumb))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = still ?: entry.cover,
                contentDescription = entry.title,
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, OnImage.scrimStrong)))
            )
            Icon(
                painterResource(R.drawable.ic_play),
                contentDescription = "Play",
                tint = OnImage.content,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
                    .background(OnImage.scrim, CircleShape)
                    .padding(10.dp)
            )
            // Remove from "Continue watching".
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(44.dp)
                    .clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(26.dp)
                        .background(OnImage.scrimStrong, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Remove from Continue watching",
                        tint = OnImage.content,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            if (fraction > 0f) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth(fraction)
                        .height(3.dp)
                        .background(MaterialTheme.megu.accent)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            entry.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelLarge
        )
        Text(
            continueSubtitle(entry),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
