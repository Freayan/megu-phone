package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.MyList
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.Sync
import com.megu.phone.data.WatchEntry
import com.megu.phone.data.scoreText
import com.megu.phone.player.PlayerActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Runs one request and turns the outcome into Ready / Failed, so one bad row can't break the page. */
private suspend fun <T> loadRow(block: suspend () -> T): Load<T> {
    return try {
        Load.Ready(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Load.Failed(e.message ?: "Network error")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (Int) -> Unit, onSearch: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    // Every row loads on its own, so one failing request doesn't blank the whole page.
    var trending by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var popular by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var airing by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var topRated by remember { mutableStateOf<Load<List<Anime>>>(Load.Loading) }
    var reload by remember { mutableIntStateOf(0) }
    var refreshing by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var sheetFor by remember { mutableStateOf<Anime?>(null) }

    // Refresh "Continue watching" every time the screen comes back (e.g. from the player).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val continueEntries = remember(tick, Progress.version) { Progress.continueWatching() }

    LaunchedEffect(reload) {
        if (trending !is Load.Ready) trending = Load.Loading
        if (popular !is Load.Ready) popular = Load.Loading
        if (airing !is Load.Ready) airing = Load.Loading
        if (topRated !is Load.Ready) topRated = Load.Loading
        // A refresh that fails keeps what is already on screen.
        coroutineScope {
            launch {
                val r = loadRow { Repo.page("TRENDING_DESC") }
                if (r is Load.Ready || trending !is Load.Ready) trending = r
            }
            launch {
                val r = loadRow { Repo.page("POPULARITY_DESC") }
                if (r is Load.Ready || popular !is Load.Ready) popular = r
            }
            launch {
                val r = loadRow { Repo.page("POPULARITY_DESC", "RELEASING") }
                if (r is Load.Ready || airing !is Load.Ready) airing = r
            }
            launch {
                val r = loadRow { Repo.page("SCORE_DESC") }
                if (r is Load.Ready || topRated !is Load.Ready) topRated = r
            }
        }
        refreshing = false
    }

    val removeFromContinue: (WatchEntry) -> Unit = { entry ->
        Progress.removeEntry(entry.animeId)
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val result = snackbar.showSnackbar(
                message = "Removed ${entry.title}",
                actionLabel = "Undo",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) Progress.restoreEntry(entry)
        }
    }

    val allFailed = trending is Load.Failed && popular is Load.Failed &&
        airing is Load.Failed && topRated is Load.Failed

    Box(Modifier.fillMaxSize()) {
        if (allFailed) {
            val message = (trending as? Load.Failed)?.message ?: "Network error"
            ErrorBox(message) { reload++ }
        } else {
            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = {
                    refreshing = true
                    Repo.clearPageCache()
                    Sync.pullInBackground()
                    reload++
                },
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    item(key = "title") { HomeHeader(onSearch) }
                    item(key = "hero") {
                        when (val t = trending) {
                            Load.Loading -> HeroSkeleton()
                            is Load.Failed -> {}
                            is Load.Ready -> {
                                val heroes = pickHeroes(t.data)
                                if (heroes.isNotEmpty()) {
                                    HeroCarousel(
                                        list = heroes,
                                        onOpen = onOpen,
                                        onPlay = { a -> playShow(context, scope, a.id) }
                                    )
                                }
                            }
                        }
                    }
                    if (continueEntries.isNotEmpty()) {
                        item(key = "continue") {
                            ContinueRow(
                                entries = continueEntries,
                                onPlay = { e -> PlayerActivity.start(context, e.animeId, e.episode, e.dub) },
                                onRemove = removeFromContinue
                            )
                        }
                    }
                    item(key = "trending") {
                        RowSection("Trending now", trending, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "popular") {
                        RowSection("Popular right now", popular, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "airing") {
                        RowSection("Airing now", airing, { reload++ }, onOpen) { sheetFor = it }
                    }
                    item(key = "top") {
                        RowSection("Top rated", topRated, { reload++ }, onOpen) { sheetFor = it }
                    }
                }
            }
        }
        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    sheetFor?.let { picked ->
        QuickSheet(
            anime = picked,
            scope = scope,
            onDismiss = { sheetFor = null },
            onOpen = onOpen
        )
    }
}

@Composable
private fun RowSection(
    title: String,
    state: Load<List<Anime>>,
    onRetry: () -> Unit,
    onOpen: (Int) -> Unit,
    onLongPress: (Anime) -> Unit
) {
    when (state) {
        Load.Loading -> SkeletonRow(title)
        is Load.Failed -> RowFailed(title, onRetry)
        is Load.Ready -> AnimeRow(title, state.data, onOpen, onLongPress)
    }
}

@Composable
private fun HomeHeader(onSearch: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "MeguAnimes",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onSearch) {
            Icon(Icons.Filled.Search, contentDescription = "Search")
        }
    }
}

// ------------------------------------------------------------------ hero

/** Up to five trending shows, preferring ones that have a wide banner picture. */
private fun pickHeroes(list: List<Anime>): List<Anime> {
    val withBanner = list.filter { it.banner != null }
    return (if (withBanner.size >= 3) withBanner else list).take(5)
}

@Composable
private fun HeroSkeleton() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .background(pulseColor())
    )
}

@Composable
private fun HeroCarousel(
    list: List<Anime>,
    onOpen: (Int) -> Unit,
    onPlay: (Anime) -> Unit
) {
    val count = list.size
    val pager = rememberPagerState(pageCount = { list.size })

    // Slide to the next show every few seconds; swiping restarts the timer.
    LaunchedEffect(pager.currentPage, count) {
        if (count > 1) {
            delay(6000)
            if (!pager.isScrollInProgress) {
                pager.animateScrollToPage((pager.currentPage + 1) % count)
            }
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
    ) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            HeroPage(list[page], onOpen, onPlay)
        }
        if (count > 1) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                repeat(count) { index ->
                    val on = index == pager.currentPage
                    Box(
                        Modifier
                            .size(width = if (on) 18.dp else 6.dp, height = 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (on) MaterialTheme.colorScheme.primary else Color(0x66FFFFFF)
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroPage(anime: Anime, onOpen: (Int) -> Unit, onPlay: (Anime) -> Unit) {
    val saved = remember(MyList.version, anime.id) { MyList.contains(anime.id) }
    val background = MaterialTheme.colorScheme.background
    val detailsLine = listOfNotNull(
        anime.score?.let { "★ ${scoreText(it)}" },
        anime.genres.take(3).joinToString(" • ").ifBlank { null }
    ).joinToString("   ")

    Box(
        Modifier
            .fillMaxSize()
            .clickable { onOpen(anime.id) }
    ) {
        AsyncImage(
            model = anime.banner ?: anime.cover,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Transparent, background)))
        )
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, end = 16.dp, bottom = 28.dp)
        ) {
            Text(
                anime.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (detailsLine.isNotBlank()) {
                Text(
                    detailsLine,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onPlay(anime) }) {
                    Icon(
                        painterResource(R.drawable.ic_play),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                FilledTonalButton(onClick = { MyList.toggle(anime) }) {
                    Icon(
                        if (saved) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("My List")
                }
            }
        }
    }
}

// ----------------------------------------------------- continue watching

@Composable
private fun ContinueRow(
    entries: List<WatchEntry>,
    onPlay: (WatchEntry) -> Unit,
    onRemove: (WatchEntry) -> Unit
) {
    Column {
        SectionTitle("Continue watching")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries, key = { it.animeId }) { entry ->
                ContinueCard(entry, onPlay = { onPlay(entry) }, onRemove = { onRemove(entry) })
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

/** "E7 · Sub · 12 min left" (or "Up next" for an episode you haven't started). */
private fun continueSubtitle(e: WatchEntry): String {
    val language = if (e.dub) "Dub" else "Sub"
    val minutesLeft =
        if (e.durationMs > 0 && e.positionMs > 0) {
            ((e.durationMs - e.positionMs + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        } else {
            0
        }
    return if (minutesLeft > 0) {
        "E${e.episode} · $language · $minutesLeft min left"
    } else {
        "E${e.episode} · $language · Up next"
    }
}

@Composable
private fun ContinueCard(entry: WatchEntry, onPlay: () -> Unit, onRemove: () -> Unit) {
    // The wide still of this episode, if we can find one; otherwise the poster, cropped.
    var still by remember(entry.animeId, entry.episode) { mutableStateOf<String?>(null) }
    LaunchedEffect(entry.animeId, entry.episode) {
        still = Repo.episodeMeta(entry.animeId)[entry.episode]?.image
    }
    val fraction =
        if (entry.durationMs > 0) (entry.positionMs.toFloat() / entry.durationMs).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .width(232.dp)
            .clickable(onClick = onPlay)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            AsyncImage(
                model = still ?: entry.cover,
                contentDescription = entry.title,
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000))))
            )
            Icon(
                painterResource(R.drawable.ic_play),
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
                    .background(Color(0x66000000), CircleShape)
                    .padding(10.dp)
            )
            // Remove from "Continue watching".
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(44.dp)
                    .clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(26.dp)
                        .background(Color(0xCC15101C), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Remove from Continue watching",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            if (fraction > 0f) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth(fraction)
                        .height(4.dp)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            entry.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelLarge
        )
        Text(
            continueSubtitle(entry),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
