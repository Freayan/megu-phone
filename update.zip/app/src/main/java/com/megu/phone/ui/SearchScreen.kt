package com.megu.phone.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.Repo
import com.megu.phone.data.SearchHistory
import com.megu.phone.data.SearchSpec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.util.Calendar

// What the filter menus offer. First item of each pair is what AniList wants, second is what you see.
private val SORTS = listOf(
    "TRENDING_DESC" to "Trending",
    "POPULARITY_DESC" to "Popular",
    "SCORE_DESC" to "Top rated"
)

private val GENRES = listOf(
    "Action", "Adventure", "Comedy", "Drama", "Ecchi", "Fantasy", "Horror", "Mahou Shoujo",
    "Mecha", "Music", "Mystery", "Psychological", "Romance", "Sci-Fi", "Slice of Life",
    "Sports", "Supernatural", "Thriller"
).map { it to it }

private val SEASONS = listOf(
    "WINTER" to "Winter",
    "SPRING" to "Spring",
    "SUMMER" to "Summer",
    "FALL" to "Fall"
)

private val FORMATS = listOf(
    "TV" to "TV",
    "MOVIE" to "Movie",
    "OVA" to "OVA",
    "ONA" to "ONA",
    "SPECIAL" to "Special"
)

@Composable
fun SearchScreen(onOpen: (Int) -> Unit) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val fieldFocus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()

    // The typed text and the filters survive tab switches and screen rotation.
    var query by rememberSaveable { mutableStateOf("") }
    var genre by rememberSaveable { mutableStateOf<String?>(null) }
    var year by rememberSaveable { mutableStateOf<Int?>(null) }
    var season by rememberSaveable { mutableStateOf<String?>(null) }
    var format by rememberSaveable { mutableStateOf<String?>(null) }
    var sort by rememberSaveable { mutableStateOf<String?>(null) }

    // Bumped when the user presses Search on the keyboard, taps a recent search, changes a filter
    // or retries: those run at once, while typing waits a moment (debounce).
    var searchTick by remember { mutableIntStateOf(0) }
    var handledTick by remember { mutableIntStateOf(0) }

    var results by remember { mutableStateOf<List<Anime>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var trending by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var historyTick by remember { mutableIntStateOf(0) }
    var sheetFor by remember { mutableStateOf<Anime?>(null) }
    val recents = remember(historyTick) { SearchHistory.all() }

    val typed = query.trim()
    val spec = SearchSpec(
        text = if (typed.length >= 2) typed else "",
        genre = genre,
        year = year,
        season = season,
        format = format,
        sort = sort
    )
    val active = spec.text.isNotEmpty() || spec.hasFilters
    val thisYear = remember { Calendar.getInstance().get(Calendar.YEAR) }
    val years = remember(thisYear) { (thisYear + 1 downTo 1990).map { it.toString() to it.toString() } }

    fun clearFilters() {
        genre = null
        year = null
        season = null
        format = null
        sort = null
        searchTick++
    }

    // ---------------------------------------------------------------- voice
    val speech = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!spoken.isNullOrEmpty()) {
                query = spoken
                searchTick++
                SearchHistory.add(spoken)
                historyTick++
            }
        }
    }

    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say an anime title")
        }
        try {
            speech.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Voice search isn't available on this phone. Install or enable Google voice typing.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ------------------------------------------------------------- data
    LaunchedEffect(Unit) {
        trending = try {
            Repo.page("TRENDING_DESC")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    LaunchedEffect(spec, searchTick) {
        // Anything other than plain typing runs at once; typing waits a moment (debounce).
        val immediate = searchTick != handledTick
        handledTick = searchTick

        if (!active) {
            results = null
            error = null
            loading = false
            return@LaunchedEffect
        }
        val cached = Repo.cachedDiscover(spec)
        if (cached != null) {
            results = cached
            error = null
            loading = false
            return@LaunchedEffect
        }
        if (!immediate) {
            delay(400) // a new keystroke cancels this effect and starts over
        }
        loading = true
        error = null
        try {
            results = Repo.discover(spec)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            results = null
            error = e.message ?: "Network error"
        }
        loading = false
    }

    // -------------------------------------------------------------- screen
    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            placeholder = { Text("Search titles") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear")
                        }
                    }
                    IconButton(onClick = { startVoice() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_mic),
                            contentDescription = "Voice search"
                        )
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(
                onSearch = {
                    focus.clearFocus()
                    if (typed.isNotEmpty()) SearchHistory.add(typed)
                    historyTick++
                    searchTick++
                }
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(top = 12.dp, bottom = 4.dp)
                .focusRequester(fieldFocus)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            item(key = "f-sort") {
                FilterMenu("Sort", "Default", SORTS, sort) {
                    sort = it
                    searchTick++
                }
            }
            item(key = "f-genre") {
                FilterMenu("Genre", "Any genre", GENRES, genre) {
                    genre = it
                    searchTick++
                }
            }
            item(key = "f-year") {
                FilterMenu("Year", "Any year", years, year?.toString()) {
                    year = it?.toIntOrNull()
                    searchTick++
                }
            }
            item(key = "f-season") {
                FilterMenu("Season", "Any season", SEASONS, season) {
                    season = it
                    searchTick++
                }
            }
            item(key = "f-format") {
                FilterMenu("Format", "Any format", FORMATS, format) {
                    format = it
                    searchTick++
                }
            }
            if (spec.hasFilters) {
                item(key = "f-clear") {
                    TextButton(onClick = { clearFilters() }) { Text("Clear") }
                }
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val list = results
            val err = error
            when {
                !active -> IdleGrid(
                    recents = recents,
                    trending = trending,
                    onRecent = { text ->
                        focus.clearFocus()
                        query = text
                        searchTick++
                    },
                    onRemoveRecent = {
                        SearchHistory.remove(it)
                        historyTick++
                    },
                    onClearRecents = {
                        SearchHistory.clear()
                        historyTick++
                    },
                    onOpen = onOpen,
                    onLongPress = { sheetFor = it }
                )

                err != null && list == null -> ErrorBox(err) { searchTick++ }

                list == null -> LoadingBox()

                list.isEmpty() && !loading -> Column(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (spec.text.isNotEmpty()) {
                        Text(
                            "No results for \"${spec.text}\"",
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.size(8.dp))
                        Text(
                            if (spec.hasFilters) {
                                "Try removing a filter, or check the spelling."
                            } else {
                                "Check the spelling, or try the Japanese title."
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text(
                            "Nothing matches these filters",
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (spec.hasFilters) {
                        Spacer(Modifier.size(8.dp))
                        TextButton(onClick = { clearFilters() }) { Text("Clear filters") }
                    }
                }

                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(100.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(list, key = { it.id }) { anime ->
                        AnimeCard(
                            anime,
                            onClick = {
                                focus.clearFocus()
                                if (typed.isNotEmpty()) SearchHistory.add(typed)
                                onOpen(anime.id)
                            },
                            onLongClick = { sheetFor = anime }
                        )
                    }
                }
            }
            if (loading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                )
            }
        }
    }

    sheetFor?.let { picked ->
        QuickSheet(
            anime = picked,
            scope = scope,
            onDismiss = { sheetFor = null },
            onOpen = onOpen
        )
    }
}

/**
 * A chip that opens a small menu. [options] are (value, label) pairs; [current] is the picked
 * value or null. Picking "[anyLabel]" gives null back.
 */
@Composable
private fun FilterMenu(
    title: String,
    anyLabel: String,
    options: List<Pair<String, String>>,
    current: String?,
    onPick: (String?) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val shown = options.firstOrNull { it.first == current }?.second ?: title
    val accent = MaterialTheme.colorScheme.primary

    Box {
        FilterChip(
            selected = current != null,
            onClick = { open = true },
            label = { Text(shown) },
            trailingIcon = {
                Icon(
                    painterResource(R.drawable.ic_expand_more),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
            }
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = {
                    Text(
                        anyLabel,
                        color = if (current == null) accent else Color.Unspecified,
                        fontWeight = if (current == null) FontWeight.Bold else FontWeight.Normal
                    )
                },
                onClick = {
                    onPick(null)
                    open = false
                }
            )
            for ((value, label) in options) {
                val picked = value == current
                DropdownMenuItem(
                    text = {
                        Text(
                            label,
                            color = if (picked) accent else Color.Unspecified,
                            fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = {
                        onPick(value)
                        open = false
                    }
                )
            }
        }
    }
}

/** What Search shows before anything is typed: recent searches, then what is trending. */
@Composable
private fun IdleGrid(
    recents: List<String>,
    trending: List<Anime>,
    onRecent: (String) -> Unit,
    onRemoveRecent: (String) -> Unit,
    onClearRecents: () -> Unit,
    onOpen: (Int) -> Unit,
    onLongPress: (Anime) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(100.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (recents.isNotEmpty()) {
            item(key = "recent-head", span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Recent searches",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onClearRecents) { Text("Clear") }
                }
            }
            items(recents, key = { "recent:$it" }, span = { GridItemSpan(maxLineSpan) }) { text ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onRecent(text) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onRemoveRecent(text) }) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Remove",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
        if (trending.isNotEmpty()) {
            item(key = "trend-head", span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    "Trending now",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            items(trending, key = { it.id }) { anime ->
                AnimeCard(
                    anime,
                    onClick = { onOpen(anime.id) },
                    onLongClick = { onLongPress(anime) }
                )
            }
        }
    }
}
