package com.megu.phone.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.megu.phone.R
import com.megu.phone.data.ListStatus
import com.megu.phone.data.MyList
import com.megu.phone.data.SavedAnime
import kotlinx.coroutines.launch

private const val FILTER_ALL = "all"

private fun filterLabel(key: String): String =
    if (key == FILTER_ALL) "All" else ListStatus.label(key)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListScreen(onOpen: (Int) -> Unit) {
    // Reading MyList.version makes this redraw whenever the list changes.
    val saved = remember(MyList.version) { MyList.all() }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(FILTER_ALL) }
    var optionsFor by remember { mutableStateOf<SavedAnime?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val counts = remember(saved) { saved.groupingBy { it.status }.eachCount() }
    val needle = query.trim()
    val shown = remember(saved, needle, filter) {
        saved.filter { s ->
            (filter == FILTER_ALL || s.status == filter) &&
                (needle.isEmpty() || s.title.contains(needle, ignoreCase = true))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text(
                "My List",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )

            if (saved.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Nothing saved yet", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Open any show and tap Add to My List. It will show up here.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                ListSearchBar(
                    query = query,
                    onQuery = { query = it },
                    filter = filter,
                    onFilter = { filter = it },
                    counts = counts,
                    total = saved.size
                )
                val summary =
                    if (shown.size == saved.size) "${saved.size} shows" else "${shown.size} of ${saved.size} shows"
                Text(
                    "$summary · hold a poster for options",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
                )

                if (shown.isEmpty()) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Nothing matches", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            query = ""
                            filter = FILTER_ALL
                        }) { Text("Clear search and status") }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(100.dp),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown, key = { it.id }) { s ->
                            PosterCard(
                                title = s.title,
                                subtitle = s.meta,
                                cover = s.cover,
                                score = s.score,
                                onClick = { onOpen(s.id) },
                                badge = if (filter == FILTER_ALL && s.status != ListStatus.PLAN) {
                                    ListStatus.label(s.status)
                                } else {
                                    null
                                },
                                onLongClick = { optionsFor = s }
                            )
                        }
                    }
                }
            }
        }
        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    optionsFor?.let { item ->
        ModalBottomSheet(
            onDismissRequest = { optionsFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 16.dp)
            ) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Status",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                for (status in ListStatus.all) {
                    val current = status == item.status
                    SheetAction(
                        label = ListStatus.label(status),
                        color = if (current) MaterialTheme.colorScheme.primary else Color.Unspecified,
                        leading = {
                            if (current) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        onClick = {
                            MyList.setStatus(item.id, status)
                            optionsFor = null
                        }
                    )
                }
                Spacer(Modifier.height(6.dp))
                SheetAction(
                    label = "Remove from My List",
                    color = MaterialTheme.colorScheme.error,
                    onClick = {
                        val index = MyList.all().indexOfFirst { it.id == item.id }
                        MyList.remove(item.id)
                        optionsFor = null
                        scope.launch {
                            snackbar.currentSnackbarData?.dismiss()
                            val result = snackbar.showSnackbar(
                                message = "Removed ${item.title}",
                                actionLabel = "Undo",
                                duration = SnackbarDuration.Short
                            )
                            if (result == SnackbarResult.ActionPerformed) MyList.restore(item, index)
                        }
                    }
                )
            }
        }
    }
}

/**
 * One bar for both jobs: type to search your list, and use the small "All" menu on the
 * right to show only Watching, Plan to watch, Completed, On hold or Dropped.
 */
@Composable
private fun ListSearchBar(
    query: String,
    onQuery: (String) -> Unit,
    filter: String,
    onFilter: (String) -> Unit,
    counts: Map<String, Int>,
    total: Int
) {
    val focus = LocalFocusManager.current
    var menuOpen by remember { mutableStateOf(false) }
    val accent = MaterialTheme.colorScheme.primary

    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        placeholder = { Text("Search your list") },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear search")
                    }
                }
                Box {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { menuOpen = true }
                            .padding(start = 12.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            filterLabel(filter),
                            style = MaterialTheme.typography.labelLarge,
                            color = accent,
                            maxLines = 1
                        )
                        Icon(
                            painterResource(R.drawable.ic_expand_more),
                            contentDescription = "Choose a status",
                            tint = accent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        for (key in listOf(FILTER_ALL) + ListStatus.all) {
                            val count = if (key == FILTER_ALL) total else (counts[key] ?: 0)
                            val picked = key == filter
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        filterLabel(key),
                                        color = if (picked) accent else Color.Unspecified,
                                        fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                trailingIcon = {
                                    Text(
                                        "$count",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                onClick = {
                                    onFilter(key)
                                    menuOpen = false
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.width(4.dp))
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    )
}
