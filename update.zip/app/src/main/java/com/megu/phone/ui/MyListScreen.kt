package com.megu.phone.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.ListStatus
import com.megu.phone.data.MyList
import com.megu.phone.data.SavedAnime
import kotlinx.coroutines.launch

private const val FILTER_ALL = "all"

private fun filterLabel(key: String): String =
    if (key == FILTER_ALL) "All" else ListStatus.label(key)

private const val SORT_RECENT = "recent"
private const val SORT_TITLE = "title"
private const val SORT_RATING = "rating"
private val SORTS = listOf(
    SORT_RECENT to "Recently added",
    SORT_TITLE to "Title A–Z",
    SORT_RATING to "Highest rated"
)

/** Short labels for the badge on a poster, so it never crowds the rating. */
private fun badgeLabel(status: String): String =
    if (status == ListStatus.PLAN) "Plan" else ListStatus.label(status)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListScreen(onOpen: (Int) -> Unit) {
    // Reading MyList.version makes this redraw whenever the list changes.
    val saved = remember(MyList.version) { MyList.all() }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(FILTER_ALL) }
    var sort by rememberSaveable { mutableStateOf(SORT_RECENT) }
    var optionsFor by remember { mutableStateOf<SavedAnime?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val counts = remember(saved) { saved.groupingBy { it.status }.eachCount() }
    val needle = query.trim()
    val shown = remember(saved, needle, filter, sort) {
        val matching = saved.filter { s ->
            (filter == FILTER_ALL || s.status == filter) &&
                (needle.isEmpty() || s.title.contains(needle, ignoreCase = true))
        }
        when (sort) {
            SORT_TITLE -> matching.sortedBy { it.title.lowercase() }
            SORT_RATING -> matching.sortedByDescending { it.score ?: -1 }
            // The list is stored newest first, so this is "recently added".
            else -> matching
        }
    }

    // Items keep their place by id, so after a new sort, filter or search the grid would stay
    // wherever the same posters moved to. Jump back to the top whenever the order changes.
    val gridState = rememberLazyGridState()
    LaunchedEffect(sort, filter, needle) { gridState.scrollToItem(0) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            val summary =
                if (shown.size == saved.size) "${saved.size} shows" else "${shown.size} of ${saved.size} shows"
            ScreenHeader("My List", trailing = {
                if (saved.isNotEmpty()) {
                    Text(
                        summary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.megu.textSecondary,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            })

            if (saved.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Nothing saved yet", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Open any show and tap Add to My List. It will show up here.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                ListSearchBar(
                    query = query,
                    onQuery = { query = it },
                    sort = sort,
                    onSort = { sort = it }
                )
                StatusChips(
                    filter = filter,
                    onFilter = { filter = it },
                    counts = counts,
                    total = saved.size
                )

                if (shown.isEmpty()) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Nothing matches", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            query = ""
                            filter = FILTER_ALL
                        }) { Text("Clear search and status") }
                    }
                } else {
                    LazyVerticalGrid(
                        state = gridState,
                        // 3 columns on a normal phone; more on a tablet or in landscape, 2 on a very narrow screen.
                        columns = GridCells.Adaptive(100.dp),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(shown, key = { it.id }) { s ->
                            ListPosterCard(
                                title = s.title,
                                subtitle = s.meta,
                                cover = s.cover,
                                score = s.score,
                                // Completed is the common case, so it gets no badge. A badge is
                                // also redundant when the list is already filtered to one status.
                                badge = if (filter == FILTER_ALL && s.status != ListStatus.COMPLETED) {
                                    badgeLabel(s.status)
                                } else {
                                    null
                                },
                                onClick = { onOpen(s.id) },
                                onOptions = { optionsFor = s }
                            )
                        }
                    }
                }
            }
        }
        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    optionsFor?.let { item ->
        ModalBottomSheet(
            onDismissRequest = { optionsFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.megu.elevated
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 16.dp)
            ) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Status",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                for (status in ListStatus.all) {
                    val current = status == item.status
                    SheetAction(
                        label = ListStatus.label(status),
                        color = if (current) MaterialTheme.megu.accentText else Color.Unspecified,
                        leading = {
                            if (current) {
                                Icon(
                                    Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        onClick = {
                            MyList.setStatus(item.id, status)
                            optionsFor = null
                        }
                    )
                }
                Spacer(Modifier.height(6.dp))
                SheetAction(
                    label = "Remove from My List",
                    color = MaterialTheme.colorScheme.error,
                    onClick = {
                        val index = MyList.all().indexOfFirst { it.id == item.id }
                        MyList.remove(item.id)
                        optionsFor = null
                        scope.launch {
                            snackbar.currentSnackbarData?.dismiss()
                            val result = snackbar.showSnackbar(
                                message = "Removed ${item.title}",
                                actionLabel = "Undo",
                                duration = SnackbarDuration.Short
                            )
                            if (result == SnackbarResult.ActionPerformed) MyList.restore(item, index)
                        }
                    }
                )
            }
        }
    }
}

/** The search field, with a sort menu on the right. */
@Composable
private fun ListSearchBar(
    query: String,
    onQuery: (String) -> Unit,
    sort: String,
    onSort: (String) -> Unit
) {
    val focus = LocalFocusManager.current
    var menuOpen by remember { mutableStateOf(false) }
    val accent = MaterialTheme.megu.accentText

    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        singleLine = true,
        shape = RoundedCornerShape(MeguDims.RadiusPill),
        colors = meguFieldColors(),
        placeholder = { Text("Search your list") },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear search")
                    }
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(
                            painterResource(R.drawable.ic_sort),
                            contentDescription = "Sort",
                            tint = accent
                        )
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        for ((key, label) in SORTS) {
                            val picked = key == sort
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        label,
                                        color = if (picked) accent else Color.Unspecified,
                                        fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSort(key)
                                    menuOpen = false
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.width(4.dp))
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    )
}

/** One chip per status with its count; a status with nothing in it is hidden unless picked. */
@Composable
private fun StatusChips(
    filter: String,
    onFilter: (String) -> Unit,
    counts: Map<String, Int>,
    total: Int
) {
    val keys = listOf(FILTER_ALL) + ListStatus.all.filter { (counts[it] ?: 0) > 0 || it == filter }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 10.dp)
    ) {
        items(keys, key = { it }) { key ->
            val count = if (key == FILTER_ALL) total else (counts[key] ?: 0)
            MeguChip(
                selected = key == filter,
                onClick = { onFilter(key) },
                label = { Text("${filterLabel(key)} $count", maxLines = 1) }
            )
        }
    }
}

/**
 * A poster in the My List grid: the rating top-left, a status badge top-right (not for
 * Completed), an options button bottom-right, then a two-line title and the details.
 */
@Composable
private fun ListPosterCard(
    title: String,
    subtitle: String,
    cover: String?,
    score: Int?,
    badge: String?,
    onClick: () -> Unit,
    onOptions: () -> Unit
) {
    val palette = MaterialTheme.megu
    Column(Modifier.tapOrHold(onClick, onOptions)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(MeguDims.RadiusThumb))
                .background(palette.card)
        ) {
            AsyncImage(
                model = cover,
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (score != null) {
                ScoreBadge(score, Modifier.align(Alignment.TopStart).padding(6.dp))
            }
            if (badge != null) {
                Text(
                    badge,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = palette.accentText,
                    maxLines = 1,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .background(palette.background.copy(alpha = 0.82f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            IconButton(
                onClick = onOptions,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(44.dp)
            ) {
                Box(
                    Modifier
                        .size(26.dp)
                        .background(palette.background.copy(alpha = 0.72f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.MoreVert,
                        contentDescription = "Options for $title",
                        tint = palette.textPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(
            title,
            minLines = 2,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            color = palette.textPrimary,
            style = MaterialTheme.typography.titleSmall.copy(
                fontSize = 13.sp,
                lineHeight = 17.sp,
                fontWeight = FontWeight.SemiBold
            )
        )
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle.replace(" • ", " · "),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = palette.textSecondary,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 15.sp)
            )
        }
    }
}
