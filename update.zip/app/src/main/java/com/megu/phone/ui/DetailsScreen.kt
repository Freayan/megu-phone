package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import coil.compose.AsyncImage
import com.megu.phone.R
import com.megu.phone.data.Anime
import com.megu.phone.data.AppSettings
import com.megu.phone.data.EpisodeMeta
import com.megu.phone.data.LangInfo
import com.megu.phone.data.ListStatus
import com.megu.phone.data.MyList
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.episodeList
import com.megu.phone.data.meta
import com.megu.phone.data.prettyStatus
import com.megu.phone.data.scoreText
import com.megu.phone.player.PlayerActivity
import kotlinx.coroutines.CancellationException

/** Long shows are split into pages of this many episodes. */
private const val RANGE_SIZE = 25

/** Shows with more episodes than this get the "Jump" and "Newest first" tools. */
private const val TOOLS_FROM = 12

@Composable
fun DetailsScreen(id: Int, onBack: () -> Unit, onOpen: (Int) -> Unit) {
    val context = LocalContext.current
    var state by remember(id) { mutableStateOf<Load<Anime>>(Load.Loading) }
    var lang by remember(id) { mutableStateOf<LangInfo?>(null) }
    var epMeta by remember(id) { mutableStateOf<Map<Int, EpisodeMeta>>(emptyMap()) }
    var reload by remember(id) { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }

    // Re-read watch progress whenever we come back from the player.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    LaunchedEffect(id, reload) {
        state = Load.Loading
        state = try {
            Load.Ready(Repo.details(id))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Load.Failed(e.message ?: "Network error")
        }
    }
    LaunchedEffect(id) { lang = Repo.langInfo(id) }
    LaunchedEffect(id) { epMeta = Repo.episodeMeta(id) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            val current = state
            Text(
                if (current is Load.Ready) current.data.title else "",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 16.dp)
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (val s = state) {
                Load.Loading -> LoadingBox()
                is Load.Failed -> ErrorBox(s.message) { reload++ }
                is Load.Ready -> DetailsContent(
                    anime = s.data,
                    lang = lang,
                    epMeta = epMeta,
                    tick = tick,
                    onOpen = onOpen,
                    onPlay = { ep, dub -> PlayerActivity.start(context, s.data.id, ep, dub) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailsContent(
    anime: Anime,
    lang: LangInfo?,
    epMeta: Map<Int, EpisodeMeta>,
    tick: Int,
    onOpen: (Int) -> Unit,
    onPlay: (Int, Boolean) -> Unit
) {
    // Starts from Profile > Settings; only counts when this show really has a dub.
    var useDub by remember(anime.id) { mutableStateOf(AppSettings.defaultDub) }
    var expanded by remember(anime.id) { mutableStateOf(false) }
    var newestFirst by remember(anime.id) { mutableStateOf(false) }
    val dubOn = useDub && lang?.hasDub == true

    // The page of 25 episodes being shown; -1 means "the page you are on".
    var chosenRange by remember(anime.id, newestFirst, dubOn) { mutableIntStateOf(-1) }
    var showJump by remember(anime.id) { mutableStateOf(false) }
    var jumpText by remember(anime.id) { mutableStateOf("") }
    var scrollTarget by remember(anime.id) { mutableStateOf<Int?>(null) }
    var sheetEpisode by remember(anime.id) { mutableStateOf<Int?>(null) }
    val listState = rememberLazyListState()

    val episodeNumbers = remember(anime, lang, dubOn) { episodeList(anime, lang, dubOn) }
    val ordered = remember(episodeNumbers, newestFirst) {
        if (newestFirst) episodeNumbers.reversed() else episodeNumbers
    }
    val chunks = remember(ordered) { ordered.chunked(RANGE_SIZE) }

    val resume = remember(tick, anime.id) {
        Progress.continueWatching().firstOrNull { it.animeId == anime.id }
    }

    val defaultRange = if (resume != null) {
        chunks.indexOfFirst { it.contains(resume.episode) }.coerceAtLeast(0)
    } else {
        0
    }
    val rangeIndex = (if (chosenRange >= 0) chosenRange else defaultRange)
        .coerceIn(0, (chunks.size - 1).coerceAtLeast(0))
    val visible = chunks.getOrNull(rangeIndex) ?: emptyList()

    // Watch progress for the rows (refreshed on every return from the player, and when marked).
    val marksVersion = Progress.version
    val progressByEpisode = remember(tick, marksVersion, anime.id, dubOn, visible) {
        visible.associateWith { Progress.fraction(anime.id, it, dubOn) }
    }
    val watchedEpisodes = remember(tick, marksVersion, anime.id, visible) {
        visible.filter { Progress.isWatched(anime.id, it) }.toSet()
    }

    // How many items sit above the first episode in the list below (for "Jump to episode").
    val headerCount = 4 +
        (if (anime.genres.isNotEmpty()) 1 else 0) +
        (if (anime.description.isNotBlank()) 1 else 0) +
        (if (chunks.size > 1) 1 else 0) +
        (if (episodeNumbers.size > TOOLS_FROM) 1 else 0)

    LaunchedEffect(scrollTarget) {
        val target = scrollTarget
        if (target != null) {
            val at = visible.indexOf(target)
            if (at >= 0) listState.animateScrollToItem(headerCount + at)
            scrollTarget = null
        }
    }

    val firstEpisode = episodeNumbers.firstOrNull()
    val playLabel = when {
        resume != null -> "Continue episode ${resume.episode}"
        firstEpisode != null -> "Play episode $firstEpisode"
        else -> null
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(bottom = 96.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(key = "banner") {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                ) {
                    AsyncImage(
                        model = anime.banner ?: anime.cover,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                                )
                            )
                    )
                }
            }

            item(key = "head") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    AsyncImage(
                        model = anime.cover,
                        contentDescription = anime.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(112.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            anime.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (anime.romaji != anime.title) {
                            Text(
                                anime.romaji,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            anime.meta(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val statusLine = listOfNotNull(
                            anime.score?.let { "★ ${scoreText(it)}" },
                            anime.prettyStatus(),
                            anime.duration?.let { "$it min" }
                        ).joinToString(" • ")
                        if (statusLine.isNotBlank()) {
                            Text(
                                statusLine,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item(key = "mylist") {
                // Reading MyList.version redraws this whenever the list changes.
                val saved = remember(MyList.version, anime.id) { MyList.statusOf(anime.id) }
                var menuOpen by remember { mutableStateOf(false) }
                if (saved == null) {
                    OutlinedButton(
                        onClick = { MyList.add(anime) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp)
                    ) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Add to My List")
                    }
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { menuOpen = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                Icons.Filled.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("In My List · ${ListStatus.label(saved)}")
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                painterResource(R.drawable.ic_expand_more),
                                contentDescription = "Change status",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            for (status in ListStatus.all) {
                                val picked = status == saved
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            ListStatus.label(status),
                                            color = if (picked) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                Color.Unspecified
                                            },
                                            fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        MyList.setStatus(anime.id, status)
                                        menuOpen = false
                                    }
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "Remove from My List",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                },
                                onClick = {
                                    MyList.remove(anime.id)
                                    menuOpen = false
                                }
                            )
                        }
                    }
                }
            }

            if (anime.genres.isNotEmpty()) {
                item(key = "genres") {
                    Text(
                        anime.genres.joinToString(" • "),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            if (anime.description.isNotBlank()) {
                item(key = "synopsis") {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { expanded = !expanded }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Text(
                            anime.description,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = if (expanded) Int.MAX_VALUE else 5,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (anime.description.length > 220) {
                            Text(
                                if (expanded) "Show less" else "Show more",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            item(key = "episodes-header") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "Episodes (${episodeNumbers.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (lang?.hasDub == true) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = !dubOn,
                                onClick = { useDub = false },
                                label = { Text("Sub") }
                            )
                            FilterChip(
                                selected = dubOn,
                                onClick = { useDub = true },
                                label = { Text("Dub") }
                            )
                        }
                    }
                }
            }

            if (chunks.size > 1) {
                item(key = "ranges") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(chunks.size, key = { it }) { i ->
                            val chunk = chunks[i]
                            FilterChip(
                                selected = i == rangeIndex,
                                onClick = { chosenRange = i },
                                label = { Text("${chunk.min()}–${chunk.max()}") }
                            )
                        }
                    }
                }
            }

            if (episodeNumbers.size > TOOLS_FROM) {
                item(key = "tools") {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = newestFirst,
                            onClick = { newestFirst = !newestFirst },
                            label = { Text("Newest first") }
                        )
                        TextButton(onClick = {
                            jumpText = ""
                            showJump = true
                        }) { Text("Jump to episode") }
                    }
                }
            }

            if (episodeNumbers.isEmpty()) {
                item(key = "no-episodes") {
                    Text(
                        "No episode list yet.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            items(visible, key = { it }) { n ->
                val info = epMeta[n]
                EpisodeRow(
                    number = n,
                    title = info?.title,
                    subtitle = listOfNotNull(
                        if (dubOn) "Dub" else "Sub",
                        info?.runtime?.let { "$it min" }
                    ).joinToString(" • "),
                    image = info?.image,
                    progress = progressByEpisode[n] ?: 0f,
                    watched = n in watchedEpisodes,
                    current = resume != null && resume.episode == n,
                    onClick = { onPlay(n, dubOn) },
                    onLongClick = { sheetEpisode = n }
                )
            }

            if (anime.related.isNotEmpty()) {
                item(key = "related") {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        SectionTitle("Seasons and related")
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(anime.related, key = { it.id }) { r ->
                                PosterCard(
                                    title = r.title,
                                    subtitle = r.relation,
                                    cover = r.cover,
                                    score = null,
                                    onClick = { onOpen(r.id) },
                                    modifier = Modifier.width(118.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // The Play button stays at the bottom while you scroll.
        if (playLabel != null) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                        )
                    )
                    .padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 12.dp)
            ) {
                Button(
                    onClick = {
                        if (resume != null) {
                            onPlay(resume.episode, resume.dub)
                        } else if (firstEpisode != null) {
                            onPlay(firstEpisode, dubOn)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        painterResource(R.drawable.ic_play),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(playLabel)
                }
            }
        }
    }

    // ------------------------------------------------------ jump to an episode
    if (showJump) {
        val typed = jumpText.trim().toIntOrNull()
        val valid = typed != null && episodeNumbers.contains(typed)
        val low = episodeNumbers.minOrNull() ?: 0
        val high = episodeNumbers.maxOrNull() ?: 0

        fun go() {
            val target = jumpText.trim().toIntOrNull()
            if (target != null && episodeNumbers.contains(target)) {
                val page = chunks.indexOfFirst { it.contains(target) }
                if (page >= 0) {
                    chosenRange = page
                    scrollTarget = target
                    showJump = false
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showJump = false },
            title = { Text("Jump to episode") },
            text = {
                OutlinedTextField(
                    value = jumpText,
                    onValueChange = { jumpText = it.filter { c -> c.isDigit() }.take(5) },
                    singleLine = true,
                    label = { Text("Episode number") },
                    isError = jumpText.isNotEmpty() && !valid,
                    supportingText = {
                        if (jumpText.isNotEmpty() && !valid) Text("Pick a number from $low to $high")
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(onGo = { go() })
                )
            },
            confirmButton = {
                TextButton(onClick = { go() }, enabled = valid) { Text("Go") }
            },
            dismissButton = {
                TextButton(onClick = { showJump = false }) { Text("Cancel") }
            }
        )
    }

    // ------------------------------------------------- press and hold an episode
    sheetEpisode?.let { n ->
        val info = epMeta[n]
        val watched = Progress.isWatched(anime.id, n)
        ModalBottomSheet(
            onDismissRequest = { sheetEpisode = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 16.dp)
            ) {
                Text(
                    "Episode $n",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (!info?.title.isNullOrBlank()) {
                    Text(
                        info?.title ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(8.dp))
                SheetAction(
                    label = "Play episode $n",
                    leading = {
                        Icon(painterResource(R.drawable.ic_play), contentDescription = null)
                    },
                    onClick = {
                        sheetEpisode = null
                        onPlay(n, dubOn)
                    }
                )
                SheetAction(
                    label = if (watched) "Mark as not watched" else "Mark as watched",
                    leading = {
                        Icon(Icons.Filled.Check, contentDescription = null)
                    },
                    onClick = {
                        Progress.setWatched(anime.id, n, !watched)
                        sheetEpisode = null
                    }
                )
                SheetAction(
                    label = "Mark everything up to episode $n as watched",
                    onClick = {
                        Progress.markWatchedUpTo(anime.id, n, episodeNumbers)
                        sheetEpisode = null
                    }
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Watched marks are saved on this phone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
