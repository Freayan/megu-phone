package com.megu.phone.player

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.annotation.OptIn
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import com.megu.phone.data.Progress
import com.megu.phone.ui.MeguTheme

/** Full-screen video player. Opened from the details page or "Continue watching". */
@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity() {

    private lateinit var controller: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Progress.init(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val id = intent.getIntExtra(EXTRA_ID, 0)
        if (id == 0) {
            finish()
            return
        }

        controller = PlayerController(this, lifecycleScope)
        controller.start(id, intent.getIntExtra(EXTRA_EP, 1), intent.getBooleanExtra(EXTRA_DUB, false))

        setContent {
            MeguTheme {
                PlayerScreen(controller)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val id = intent.getIntExtra(EXTRA_ID, 0)
        if (id != 0 && ::controller.isInitialized) {
            controller.start(id, intent.getIntExtra(EXTRA_EP, 1), intent.getBooleanExtra(EXTRA_DUB, false))
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::controller.isInitialized) controller.enterPip()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (::controller.isInitialized) controller.inPip = isInPictureInPictureMode
    }

    override fun onPause() {
        super.onPause()
        if (::controller.isInitialized) controller.saveProgress()
    }

    override fun onStop() {
        super.onStop()
        if (::controller.isInitialized) controller.onActivityStop()
    }

    override fun onDestroy() {
        if (::controller.isInitialized) controller.release()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_ID = "anime_id"
        private const val EXTRA_EP = "episode"
        private const val EXTRA_DUB = "dub"

        fun start(context: Context, animeId: Int, episode: Int, dub: Boolean) {
            context.startActivity(
                Intent(context, PlayerActivity::class.java)
                    .putExtra(EXTRA_ID, animeId)
                    .putExtra(EXTRA_EP, episode)
                    .putExtra(EXTRA_DUB, dub)
            )
        }
    }
}
