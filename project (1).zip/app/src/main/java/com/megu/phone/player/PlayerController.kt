package com.megu.phone.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.OrientationEventListener
import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.megu.phone.data.Anime
import com.megu.phone.data.EpisodeMeta
import com.megu.phone.data.LangInfo
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.StreamServer
import com.megu.phone.data.episodeList
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.util.Locale

enum class MenuPage { Main, Quality, Speed, Subtitles, Audio, Server }

/** One row in the quality / subtitle / audio pickers. */
data class TrackChoice(
    val label: String,
    val selected: Boolean,
    val group: Tracks.Group?,
    val index: Int
)

data class SkipInfo(val label: String, val toMs: Long)

/**
 * Everything the player screen needs: the ExoPlayer, what is playing, and all the
 * actions the controls trigger. State fields are Compose state, so the UI updates itself.
 */
@OptIn(UnstableApi::class)
class PlayerController(
    val activity: PlayerActivity,
    private val scope: CoroutineScope
) {
    val exo: ExoPlayer = ExoPlayer.Builder(activity)
        .setMediaSourceFactory(
            DefaultMediaSourceFactory(
                DefaultDataSource.Factory(
                    activity,
                    OkHttpDataSource.Factory(Repo.client).setUserAgent(Repo.UA)
                )
            )
        )
        .setSeekBackIncrementMs(10_000)
        .setSeekForwardIncrementMs(10_000)
        .setHandleAudioBecomingNoisy(true)
        .build()

    var released = false
        private set

    // ---- what is playing
    var animeId = 0
    var anime by mutableStateOf<Anime?>(null)
    var lang by mutableStateOf<LangInfo?>(null)
    var epMeta by mutableStateOf<Map<Int, EpisodeMeta>>(emptyMap())
    var episodes by mutableStateOf<List<Int>>(emptyList())
    var episode by mutableIntStateOf(1)
    var dub by mutableStateOf(false)

    // ---- stream
    var servers by mutableStateOf<List<StreamServer>>(emptyList())
    var serverIndex by mutableIntStateOf(0)
    var loading by mutableStateOf(true)
    var error by mutableStateOf<String?>(null)

    // ---- playback state
    var playing by mutableStateOf(false)
    var buffering by mutableStateOf(false)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)
    var speed by mutableFloatStateOf(1f)
    var videoAspect by mutableFloatStateOf(16f / 9f)
    var cues by mutableStateOf<List<Cue>>(emptyList())

    // ---- pickers
    var videoOptions by mutableStateOf<List<TrackChoice>>(emptyList())
    var textOptions by mutableStateOf<List<TrackChoice>>(emptyList())
    var audioOptions by mutableStateOf<List<TrackChoice>>(emptyList())
    var menu by mutableStateOf<MenuPage?>(null)

    var inPip by mutableStateOf(false)

    val pipSupported: Boolean =
        Build.VERSION.SDK_INT >= 26 &&
            activity.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private var loadJob: Job? = null
    private var retries = 0

    // ------------------------------------------------------------- listener

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playing = isPlaying
            if (!isPlaying) saveProgress()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            buffering = playbackState == Player.STATE_BUFFERING
            if (playbackState == Player.STATE_READY) {
                retries = 0
                val d = exo.duration
                if (d > 0) durationMs = d
            }
            if (playbackState == Player.STATE_ENDED) handleEnded()
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError(error)
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            speed = playbackParameters.speed
        }

        override fun onTracksChanged(tracks: Tracks) {
            rebuildTrackOptions()
        }

        override fun onTrackSelectionParametersChanged(parameters: TrackSelectionParameters) {
            rebuildTrackOptions()
        }

        override fun onCues(cueGroup: CueGroup) {
            cues = cueGroup.cues
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                videoAspect = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
            }
        }
    }

    // ------------------------------------------------------------ rotation

    private enum class Lock { None, Portrait, Landscape }

    private var lock = Lock.None

    private val orientationListener = object : OrientationEventListener(activity) {
        override fun onOrientationChanged(orientation: Int) {
            if (orientation == ORIENTATION_UNKNOWN || lock == Lock.None) return
            val autoRotate = Settings.System.getInt(
                activity.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0
            ) == 1
            if (!autoRotate) return
            val portrait = orientation <= 30 || orientation >= 330
            val landscape = orientation in 60..120 || orientation in 240..300
            if ((lock == Lock.Portrait && portrait) || (lock == Lock.Landscape && landscape)) {
                // The phone is now held the way we forced it: hand rotation back to the sensor.
                lock = Lock.None
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
            }
        }
    }

    init {
        exo.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true
        )
        exo.addListener(listener)
        if (orientationListener.canDetectOrientation()) orientationListener.enable()

        // Position / progress ticker.
        scope.launch {
            var ticks = 0
            while (isActive) {
                if (!released && exo.playbackState != Player.STATE_IDLE) {
                    positionMs = exo.currentPosition.coerceAtLeast(0L)
                    val d = exo.duration
                    if (d > 0) durationMs = d
                    ticks++
                    if (exo.isPlaying && ticks % 20 == 0) saveProgress()
                }
                delay(250)
            }
        }
    }

    // ---------------------------------------------------------- loading

    fun start(id: Int, ep: Int, dubMode: Boolean) {
        if (id != animeId) {
            animeId = id
            anime = null
            lang = null
            epMeta = emptyMap()
            episodes = emptyList()
            scope.launch {
                anime = try {
                    Repo.details(id)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                refreshEpisodes()
            }
            scope.launch {
                lang = Repo.langInfo(id)
                refreshEpisodes()
            }
            scope.launch { epMeta = Repo.episodeMeta(id) }
        }
        load(ep, dubMode)
    }

    private fun refreshEpisodes() {
        val list = episodeList(anime, lang, dub)
        episodes = if (list.isEmpty()) listOf(episode) else list
    }

    /** Loads one episode. Links expire quickly, so a fresh one is always fetched. */
    fun load(ep: Int, dubMode: Boolean, resumeAt: Long? = null, isRetry: Boolean = false) {
        if (!isRetry) {
            saveProgress()
            retries = 0
        }
        loadJob?.cancel()
        val keepServerId =
            if (isRetry || resumeAt != null) servers.getOrNull(serverIndex)?.id else null

        episode = ep
        dub = dubMode
        refreshEpisodes()
        loading = true
        error = null
        positionMs = 0L
        durationMs = 0L
        servers = emptyList()
        exo.stop()
        exo.clearMediaItems()

        loadJob = scope.launch {
            val found = Repo.resolveStream(animeId, ep, dubMode)
            if (found.isEmpty()) {
                loading = false
                error = "No stream found for episode $ep (" + (if (dubMode) "dub" else "sub") +
                    "). Try the other language, or try again later."
                return@launch
            }
            servers = found
            val wanted = found.indexOfFirst { it.id == keepServerId }
            val start = resumeAt ?: Progress.positionFor(animeId, ep, dubMode)
            playServer(if (wanted >= 0) wanted else 0, start)
        }
    }

    fun retry() {
        load(episode, dub, resumeAt = positionMs.takeIf { it > 5_000 })
    }

    private fun playServer(index: Int, startMs: Long) {
        val s = servers.getOrNull(index) ?: return
        serverIndex = index

        // Reset track choices for the new stream: subtitles on for sub, off for dub.
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .clearOverrides()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, dub)
            .setPreferredTextLanguage("en")
            .build()

        val subs = s.subtitles.map { t ->
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(t.url))
                .setMimeType(subtitleMime(t.url))
                .setLanguage(languageCode(t.label))
                .setLabel(t.label)
                .setSelectionFlags(if (t.isDefault) C.SELECTION_FLAG_DEFAULT else 0)
                .build()
        }
        val item = MediaItem.Builder()
            .setUri(s.url)
            .setMimeType(streamMime(s.url))
            .setSubtitleConfigurations(subs)
            .build()

        exo.setMediaItem(item, if (startMs > 5_000) startMs else 0L)
        exo.prepare()
        exo.playWhenReady = true
        loading = false
    }

    fun switchServer(index: Int) {
        if (index == serverIndex) return
        playServer(index, exo.currentPosition)
    }

    fun switchLanguage(toDub: Boolean) {
        if (toDub == dub) return
        load(episode, toDub, resumeAt = exo.currentPosition.takeIf { it > 5_000 })
    }

    fun dubAvailable(): Boolean {
        val l = lang ?: return false
        if (!l.hasDub) return false
        return if (l.dubEps.isNotEmpty()) l.dubEps.contains(episode) else l.dub >= episode
    }

    fun nextEpisode(): Int? {
        val i = episodes.indexOf(episode)
        return if (i >= 0 && i + 1 < episodes.size) episodes[i + 1] else null
    }

    fun prevEpisode(): Int? {
        val i = episodes.indexOf(episode)
        return if (i > 0) episodes[i - 1] else null
    }

    fun playNext() {
        val n = nextEpisode() ?: return
        load(n, dub)
    }

    fun playPrevious() {
        val p = prevEpisode() ?: return
        load(p, dub)
    }

    // ------------------------------------------------------- errors / end

    private fun handleEnded() {
        saveProgress()
        val next = nextEpisode()
        if (next != null) load(next, dub)
    }

    private fun handleError(e: PlaybackException) {
        if (released) return
        if (retries < 2) {
            retries++
            load(episode, dub, resumeAt = exo.currentPosition.takeIf { it > 5_000 }, isRetry = true)
        } else {
            loading = false
            error = "Playback failed (${e.errorCodeName}). Check your connection and try again."
        }
    }

    // ------------------------------------------------------ transport

    fun togglePlay() {
        if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
        if (exo.playWhenReady && exo.playbackState != Player.STATE_ENDED) exo.pause() else exo.play()
    }

    fun seekTo(ms: Long) {
        val target = ms.coerceAtLeast(0L)
        exo.seekTo(target)
        positionMs = target
    }

    fun seekBy(deltaMs: Long) {
        val d = if (durationMs > 0) durationMs else Long.MAX_VALUE
        seekTo((exo.currentPosition + deltaMs).coerceIn(0L, d))
    }

    fun changeSpeed(value: Float) {
        exo.setPlaybackSpeed(value)
    }

    fun skipInfo(): SkipInfo? {
        val s = servers.getOrNull(serverIndex) ?: return null
        val sec = positionMs / 1000.0
        s.intro?.let {
            if (sec >= it.start && sec < it.end - 1) return SkipInfo("Skip intro", (it.end * 1000).toLong())
        }
        s.outro?.let {
            if (sec >= it.start && sec < it.end - 1) return SkipInfo("Skip ending", (it.end * 1000).toLong())
        }
        return null
    }

    // ------------------------------------------------------ track pickers

    private fun rebuildTrackOptions() {
        if (released) return
        val tracks = exo.currentTracks
        val params = exo.trackSelectionParameters

        // Video quality: one entry per height, keeping the best bitrate for that height.
        val hasVideoOverride = params.overrides.values.any { it.type == C.TRACK_TYPE_VIDEO }
        val best = HashMap<Int, Triple<Tracks.Group, Int, Int>>()
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                if (f.height <= 0) continue
                val cur = best[f.height]
                if (cur == null || f.bitrate > cur.third) best[f.height] = Triple(g, i, f.bitrate)
            }
        }
        val video = ArrayList<TrackChoice>()
        video.add(TrackChoice("Auto", !hasVideoOverride, null, 0))
        for (h in best.keys.sortedDescending()) {
            val entry = best.getValue(h)
            video.add(TrackChoice("${h}p", hasVideoOverride && entry.first.isTrackSelected(entry.second), entry.first, entry.second))
        }
        videoOptions = video

        // Subtitles
        val textDisabled = params.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        val text = ArrayList<TrackChoice>()
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_TEXT || g.length == 0) continue
            val f = g.getTrackFormat(0)
            text.add(
                TrackChoice(
                    f.label ?: f.language ?: "Subtitles ${text.size + 1}",
                    !textDisabled && g.isSelected,
                    g,
                    0
                )
            )
        }
        val anySelected = text.any { it.selected }
        text.add(0, TrackChoice("Off", textDisabled || !anySelected, null, 0))
        textOptions = text

        // Audio tracks inside the stream
        val audio = ArrayList<TrackChoice>()
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                val f = g.getTrackFormat(i)
                val fromLang = f.language
                    ?.let { Locale.forLanguageTag(it).displayLanguage }
                    ?.takeIf { it.isNotBlank() }
                audio.add(
                    TrackChoice(
                        f.label ?: fromLang ?: "Track ${audio.size + 1}",
                        g.isTrackSelected(i),
                        g,
                        i
                    )
                )
            }
        }
        audioOptions = audio
    }

    fun selectVideo(choice: TrackChoice) {
        val b = exo.trackSelectionParameters.buildUpon()
        val g = choice.group
        if (g == null) {
            b.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
        } else {
            b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, choice.index))
        }
        exo.trackSelectionParameters = b.build()
    }

    fun selectText(choice: TrackChoice) {
        val b = exo.trackSelectionParameters.buildUpon()
        val g = choice.group
        if (g == null) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            b.setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
        }
        exo.trackSelectionParameters = b.build()
    }

    fun selectAudio(choice: TrackChoice) {
        val g = choice.group ?: return
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, choice.index))
            .build()
    }

    fun qualityLabel(): String = videoOptions.firstOrNull { it.selected }?.label ?: "Auto"
    fun subtitleLabel(): String = textOptions.firstOrNull { it.selected }?.label ?: "Off"
    fun audioLabel(): String {
        val inStream = audioOptions.firstOrNull { it.selected }?.label
        val base = if (dub) "English (Dub)" else "Japanese (Sub)"
        return if (audioOptions.size > 1 && inStream != null) "$base · $inStream" else base
    }

    // ----------------------------------------------- fullscreen / PiP

    fun enterFullscreen() {
        lock = Lock.Landscape
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    fun exitFullscreen() {
        lock = Lock.Portrait
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    fun setImmersive(on: Boolean) {
        val w = activity.window
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        if (on) {
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            ctl.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    fun enterPip(force: Boolean = false) {
        if (!pipSupported || released) return
        if (!force && !exo.isPlaying) return
        try {
            val vs = exo.videoSize
            var w = 16
            var h = 9
            if (vs.width > 0 && vs.height > 0) {
                w = vs.width
                h = vs.height
            }
            val ratio = w.toFloat() / h
            if (ratio < 0.5f || ratio > 2.3f) {
                w = 16
                h = 9
            }
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(w, h))
                .build()
            activity.enterPictureInPictureMode(params)
        } catch (e: Exception) {
            // PiP not available right now; ignore.
        }
    }

    // ------------------------------------------------------ lifecycle

    fun saveProgress() {
        if (released) return
        val a = anime ?: return
        val state = exo.playbackState
        if (state == Player.STATE_IDLE) return
        val exoDur = exo.duration
        val dur = if (exoDur > 0) exoDur else durationMs
        if (dur <= 0) return
        val pos = if (state == Player.STATE_ENDED) dur else exo.currentPosition
        Progress.record(animeId, a.title, a.cover, episode, dub, pos, dur, nextEpisode())
    }

    fun onActivityStop() {
        saveProgress()
        if (!activity.isInPictureInPictureMode) exo.pause()
    }

    fun release() {
        if (released) return
        saveProgress()
        released = true
        orientationListener.disable()
        exo.removeListener(listener)
        exo.release()
    }

    // ------------------------------------------------------- helpers

    private fun decoded(url: String): String =
        try {
            URLDecoder.decode(url, "UTF-8").lowercase()
        } catch (e: Exception) {
            url.lowercase()
        }

    private fun streamMime(url: String): String? {
        val d = decoded(url)
        return when {
            d.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            d.contains(".mp4") && !d.contains(".m3u8") -> null
            else -> MimeTypes.APPLICATION_M3U8
        }
    }

    private fun subtitleMime(url: String): String {
        val d = decoded(url)
        return when {
            d.contains(".srt") -> MimeTypes.APPLICATION_SUBRIP
            d.contains(".ass") || d.contains(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.TEXT_VTT
        }
    }

    private fun languageCode(label: String): String? {
        val l = label.lowercase()
        return when {
            l.startsWith("english") -> "en"
            l.startsWith("arabic") -> "ar"
            l.startsWith("french") -> "fr"
            l.startsWith("german") -> "de"
            l.startsWith("italian") -> "it"
            l.startsWith("portuguese") -> "pt"
            l.startsWith("russian") -> "ru"
            l.startsWith("spanish") -> "es"
            l.startsWith("indonesian") || l.startsWith("bahasa") -> "id"
            else -> null
        }
    }
}
