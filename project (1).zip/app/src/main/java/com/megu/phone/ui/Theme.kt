package com.megu.phone.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MeguColors = darkColorScheme(
    primary = Color(0xFFFF9BB0),
    onPrimary = Color(0xFF4A0F23),
    primaryContainer = Color(0xFF6B2A41),
    onPrimaryContainer = Color(0xFFFFD9E1),
    secondary = Color(0xFF9ED0FF),
    onSecondary = Color(0xFF00324F),
    background = Color(0xFF15101C),
    onBackground = Color(0xFFF1E9F7),
    surface = Color(0xFF1E1729),
    onSurface = Color(0xFFF1E9F7),
    surfaceVariant = Color(0xFF2B2139),
    onSurfaceVariant = Color(0xFFBDB0CC),
    surfaceContainer = Color(0xFF1E1729),
    surfaceContainerHigh = Color(0xFF2B2139),
    outline = Color(0xFF7A6E8A),
    error = Color(0xFFFF8A80)
)

@Composable
fun MeguTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MeguColors, content = content)
}
