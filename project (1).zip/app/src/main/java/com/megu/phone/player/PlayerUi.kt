package com.megu.phone.player

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.view.Gravity
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsTopHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import com.megu.phone.R
import com.megu.phone.data.Progress
import com.megu.phone.ui.EpisodeRow
import kotlinx.coroutines.delay

// ===================================================================== video

/** Video surface + subtitle layer, drawn without the stock PlayerView controls. */
@OptIn(UnstableApi::class)
class VideoHostView(context: Context) : FrameLayout(context) {
    val aspect = AspectRatioFrameLayout(context)
    val surface = SurfaceView(context)
    val subtitles = SubtitleView(context)

    init {
        setBackgroundColor(AndroidColor.BLACK)
        aspect.setAspectRatio(16f / 9f)
        aspect.addView(
            surface,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        addView(
            aspect,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )
        subtitles.setStyle(
            CaptionStyleCompat(
                AndroidColor.WHITE,
                AndroidColor.TRANSPARENT,
                AndroidColor.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                AndroidColor.BLACK,
                null
            )
        )
        subtitles.setApplyEmbeddedStyles(false)
        subtitles.setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * 1.1f)
        addView(
            subtitles,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoSurface(c: PlayerController) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            VideoHostView(ctx).also { c.exo.setVideoSurfaceView(it.surface) }
        },
        update = { v ->
            v.aspect.setAspectRatio(c.videoAspect)
            v.subtitles.setCues(c.cues)
        },
        onRelease = { v ->
            if (!c.released) c.exo.clearVideoSurfaceView(v.surface)
        }
    )
}

// ==================================================================== screen

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(c: PlayerController) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    LaunchedEffect(landscape) { c.setImmersive(landscape) }
    BackHandler(enabled = landscape) { c.exitFullscreen() }
    BackHandler(enabled = c.menu != null) { c.menu = null }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (landscape) Color.Black else MaterialTheme.colorScheme.background)
    ) {
        Column(Modifier.fillMaxSize()) {
            if (!landscape && !c.inPip) {
                Spacer(
                    Modifier
                        .fillMaxWidth()
                        .windowInsetsTopHeight(WindowInsets.statusBars)
                        .background(Color.Black)
                )
            }
            val videoModifier =
                if (landscape || c.inPip) Modifier.fillMaxSize()
                else Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            Box(videoModifier.background(Color.Black)) {
                VideoSurface(c)
                if (!c.inPip) PlayerOverlay(c, landscape)
            }
            if (!landscape && !c.inPip) {
                EpisodePanel(c, Modifier.weight(1f))
            }
        }

        if (c.menu != null && !c.inPip) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { c.menu = null }
            )
            SettingsMenu(
                c = c,
                modifier = if (landscape) {
                    Modifier
                        .align(Alignment.CenterEnd)
                        .padding(16.dp)
                        .width(300.dp)
                        .heightIn(max = 300.dp)
                } else {
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(12.dp)
                        .heightIn(max = 380.dp)
                }
            )
        }
    }
}

// =================================================================== overlay

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0L)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
private fun PlayerOverlay(c: PlayerController, landscape: Boolean) {
    var visible by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var dragging by remember { mutableStateOf<Float?>(null) }
    var flashSide by remember { mutableIntStateOf(0) }
    var flashTick by remember { mutableIntStateOf(0) }

    // Hide the controls 3.5 s after the last touch while playing.
    LaunchedEffect(visible, c.playing, c.menu, dragging != null, tick) {
        if (visible && c.playing && c.menu == null && dragging == null) {
            delay(3500)
            visible = false
        }
    }
    LaunchedEffect(flashTick) {
        if (flashSide != 0) {
            delay(650)
            flashSide = 0
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Touch layer: tap = show/hide controls, double-tap left/right = seek 10 s.
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            visible = !visible
                            tick++
                        },
                        onDoubleTap = { offset ->
                            val left = offset.x < size.width / 2f
                            c.seekBy(if (left) -10_000L else 10_000L)
                            flashSide = if (left) -1 else 1
                            flashTick++
                        }
                    )
                }
        )

        AnimatedVisibility(
            visible = visible && c.error == null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x73000000))
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .then(if (landscape) Modifier.displayCutoutPadding() else Modifier)
                ) {
                    TopBar(c, onTouch = { tick++ })
                    CenterControls(c, onTouch = { tick++ })
                    BottomBar(
                        c = c,
                        landscape = landscape,
                        dragging = dragging,
                        onDrag = { dragging = it; tick++ },
                        onDragEnd = {
                            dragging?.let { c.seekTo(it.toLong()) }
                            dragging = null
                        },
                        onTouch = { tick++ }
                    )
                }
            }
        }

        // Spinner while the controls are hidden.
        if ((c.loading || c.buffering) && !(visible && c.error == null) && c.error == null) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
        }

        // "Skip intro" / "Skip ending"
        val skip = c.skipInfo()
        if (skip != null && c.error == null) {
            Button(
                onClick = { c.seekTo(skip.toMs) },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = if (visible) 60.dp else 16.dp)
            ) {
                Text(skip.label)
            }
        }

        // Double-tap flash
        if (flashSide != 0) {
            Box(
                Modifier
                    .align(if (flashSide < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 40.dp)
                    .background(Color(0x66000000), CircleShape)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    if (flashSide < 0) "−10 s" else "+10 s",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Error
        val err = c.error
        if (err != null) {
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(err, color = Color.White, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { c.retry() }) { Text("Try again") }
                    OutlinedButton(onClick = { c.activity.finish() }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.TopBar(c: PlayerController, onTouch: () -> Unit) {
    val epTitle = c.epMeta[c.episode]?.title
    val line = "Episode ${c.episode}" +
        (if (epTitle != null) " · $epTitle" else "") +
        (if (c.dub) " · Dub" else "")
    Row(
        Modifier
            .align(Alignment.TopStart)
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { c.activity.onBackPressedDispatcher.onBackPressed() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Column(Modifier.weight(1f)) {
            Text(
                c.anime?.title ?: "",
                color = Color.White,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                line,
                color = Color(0xCCFFFFFF),
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (c.pipSupported) {
            IconButton(onClick = { c.enterPip(force = true) }) {
                Icon(painterResource(R.drawable.ic_pip), contentDescription = "Picture in picture", tint = Color.White)
            }
        }
        IconButton(onClick = {
            c.menu = MenuPage.Main
            onTouch()
        }) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color.White)
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.CenterControls(c: PlayerController, onTouch: () -> Unit) {
    val hasPrev = c.prevEpisode() != null
    val hasNext = c.nextEpisode() != null
    Row(
        Modifier.align(Alignment.Center),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { c.playPrevious(); onTouch() },
            enabled = hasPrev,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painterResource(R.drawable.ic_skip_prev),
                contentDescription = "Previous episode",
                tint = if (hasPrev) Color.White else Color(0x55FFFFFF),
                modifier = Modifier.size(32.dp)
            )
        }
        Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            if (c.loading || c.buffering) {
                CircularProgressIndicator(color = Color.White)
            } else {
                IconButton(
                    onClick = { c.togglePlay(); onTouch() },
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0x66000000), CircleShape)
                ) {
                    Icon(
                        painterResource(if (c.playing) R.drawable.ic_pause else R.drawable.ic_play),
                        contentDescription = if (c.playing) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }
        }
        IconButton(
            onClick = { c.playNext(); onTouch() },
            enabled = hasNext,
            modifier = Modifier.size(48.dp)
        ) {
            Icon(
                painterResource(R.drawable.ic_skip_next),
                contentDescription = "Next episode",
                tint = if (hasNext) Color.White else Color(0x55FFFFFF),
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.BottomBar(
    c: PlayerController,
    landscape: Boolean,
    dragging: Float?,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onTouch: () -> Unit
) {
    val duration = maxOf(c.durationMs, 1L).toFloat()
    val shown = (dragging ?: c.positionMs.toFloat()).coerceIn(0f, duration)
    Row(
        Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(formatTime(shown.toLong()), color = Color.White, style = MaterialTheme.typography.labelMedium)
        Slider(
            value = shown,
            onValueChange = onDrag,
            onValueChangeFinished = onDragEnd,
            valueRange = 0f..duration,
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = Color(0x55FFFFFF)
            ),
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        Text(formatTime(c.durationMs), color = Color.White, style = MaterialTheme.typography.labelMedium)
        IconButton(onClick = {
            if (landscape) c.exitFullscreen() else c.enterFullscreen()
            onTouch()
        }) {
            Icon(
                painterResource(if (landscape) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen),
                contentDescription = "Fullscreen",
                tint = Color.White
            )
        }
    }
}

// ===================================================================== menu

@Composable
private fun SettingsMenu(c: PlayerController, modifier: Modifier) {
    val page = c.menu ?: return
    Surface(
        modifier = modifier,
        color = Color(0xF21E1729),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier
                .padding(vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (page != MenuPage.Main) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { c.menu = MenuPage.Main }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        when (page) {
                            MenuPage.Quality -> "Quality"
                            MenuPage.Speed -> "Speed"
                            MenuPage.Subtitles -> "Subtitles"
                            MenuPage.Audio -> "Audio"
                            MenuPage.Server -> "Server"
                            MenuPage.Main -> ""
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            when (page) {
                MenuPage.Main -> {
                    MenuRow("Quality", c.qualityLabel()) { c.menu = MenuPage.Quality }
                    MenuRow("Speed", speedLabel(c.speed)) { c.menu = MenuPage.Speed }
                    MenuRow("Subtitles", c.subtitleLabel()) { c.menu = MenuPage.Subtitles }
                    MenuRow("Audio", c.audioLabel()) { c.menu = MenuPage.Audio }
                    if (c.servers.size > 1) {
                        val s = c.servers.getOrNull(c.serverIndex)
                        MenuRow("Server", s?.label ?: "") { c.menu = MenuPage.Server }
                    }
                }
                MenuPage.Quality -> {
                    if (c.videoOptions.size <= 1) {
                        InfoText("This stream only offers automatic quality.")
                    }
                    c.videoOptions.forEach { o ->
                        OptionRow(o.label, o.selected) {
                            c.selectVideo(o)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Speed -> {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v ->
                        OptionRow(speedLabel(v), c.speed == v) {
                            c.changeSpeed(v)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Subtitles -> {
                    val server = c.servers.getOrNull(c.serverIndex)
                    if (c.textOptions.size <= 1) {
                        InfoText(
                            if (server != null && server.hardsub)
                                "This server has subtitles built into the video."
                            else
                                "No subtitle tracks for this stream."
                        )
                    }
                    c.textOptions.forEach { o ->
                        OptionRow(o.label, o.selected) {
                            c.selectText(o)
                            c.menu = null
                        }
                    }
                }
                MenuPage.Audio -> {
                    val canDub = c.dubAvailable()
                    OptionRow("Japanese (Sub)", !c.dub) {
                        c.switchLanguage(false)
                        c.menu = null
                    }
                    if (canDub || c.dub) {
                        OptionRow("English (Dub)", c.dub) {
                            c.switchLanguage(true)
                            c.menu = null
                        }
                    } else {
                        InfoText("No English dub for this episode.")
                    }
                    if (c.audioOptions.size > 1) {
                        InfoText("Audio tracks in this stream")
                        c.audioOptions.forEach { o ->
                            OptionRow(o.label, o.selected) {
                                c.selectAudio(o)
                                c.menu = null
                            }
                        }
                    }
                }
                MenuPage.Server -> {
                    c.servers.forEachIndexed { i, s ->
                        OptionRow(
                            s.label + (if (s.hardsub) " (hardsub)" else ""),
                            i == c.serverIndex
                        ) {
                            c.switchServer(i)
                            c.menu = null
                        }
                    }
                }
            }
        }
    }
}

private fun speedLabel(v: Float): String =
    if (v == 1f) "Normal" else v.toString().removeSuffix(".0") + "x"

@Composable
private fun MenuRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, modifier = Modifier.weight(1f))
        Text(value, color = Color(0xB3FFFFFF), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(24.dp)) {
            if (selected) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            color = if (selected) MaterialTheme.colorScheme.primary else Color.White
        )
    }
}

@Composable
private fun InfoText(text: String) {
    Text(
        text,
        color = Color(0xB3FFFFFF),
        style = MaterialTheme.typography.bodySmall,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

// ============================================================ episode panel

@Composable
private fun EpisodePanel(c: PlayerController, modifier: Modifier) {
    val listState = rememberLazyListState()
    val index = c.episodes.indexOf(c.episode)
    LaunchedEffect(c.episode, c.episodes.size) {
        if (index >= 0) listState.animateScrollToItem(index + 1)
    }
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    val progressByEpisode = remember(c.animeId, c.episode, c.dub, c.episodes) {
        c.episodes.associateWith { Progress.fraction(c.animeId, it, c.dub) }
    }
    val watched = remember(c.animeId, c.episode, c.episodes) {
        c.episodes.filter { Progress.isWatched(c.animeId, it) }.toSet()
    }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        state = listState,
        contentPadding = PaddingValues(bottom = navBottom + 16.dp)
    ) {
        item(key = "info") {
            val meta = c.epMeta[c.episode]
            Column(Modifier.padding(16.dp)) {
                Text(
                    c.anime?.title ?: "",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "Episode ${c.episode}" + (if (meta?.title != null) " · ${meta.title}" else ""),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val overview = meta?.overview
                if (overview != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        overview,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (c.lang?.hasDub == true) {
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !c.dub,
                            onClick = { c.switchLanguage(false) },
                            label = { Text("Sub") }
                        )
                        FilterChip(
                            selected = c.dub,
                            onClick = { c.switchLanguage(true) },
                            enabled = c.dubAvailable() || c.dub,
                            label = { Text("Dub") }
                        )
                    }
                }
            }
        }
        items(c.episodes, key = { it }) { n ->
            val meta = c.epMeta[n]
            EpisodeRow(
                number = n,
                title = meta?.title,
                subtitle = listOfNotNull(
                    if (c.dub) "Dub" else "Sub",
                    meta?.runtime?.let { "$it min" }
                ).joinToString(" • "),
                image = meta?.image,
                progress = progressByEpisode[n] ?: 0f,
                watched = n in watched,
                current = n == c.episode,
                onClick = { if (n != c.episode) c.load(n, c.dub) }
            )
        }
    }
}
