package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.megu.phone.data.Anime
import com.megu.phone.data.LangInfo
import com.megu.phone.data.Repo
import com.megu.phone.data.meta
import com.megu.phone.data.prettyStatus
import com.megu.phone.data.scoreText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun DetailsScreen(id: Int, onBack: () -> Unit, onOpen: (Int) -> Unit) {
    var state by remember(id) { mutableStateOf<Load<Anime>>(Load.Loading) }
    var lang by remember(id) { mutableStateOf<LangInfo?>(null) }
    var reload by remember(id) { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(id, reload) {
        state = Load.Loading
        state = try {
            Load.Ready(Repo.details(id))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Load.Failed(e.message ?: "Network error")
        }
    }
    LaunchedEffect(id) {
        lang = Repo.langInfo(id)
    }

    Box(Modifier.fillMaxSize()) {
        when (val s = state) {
            Load.Loading -> LoadingBox()
            is Load.Failed -> ErrorBox(s.message) { reload++ }
            is Load.Ready -> DetailsContent(s.data, lang, snackbar, onOpen)
        }
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .padding(8.dp)
                .background(Color(0x99000000), CircleShape)
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun DetailsContent(
    anime: Anime,
    lang: LangInfo?,
    snackbar: SnackbarHostState,
    onOpen: (Int) -> Unit
) {
    val scope = rememberCoroutineScope()
    var useDub by remember(anime.id) { mutableStateOf(false) }
    var expanded by remember(anime.id) { mutableStateOf(false) }

    val episodeNumbers: List<Int> = remember(anime, lang, useDub) {
        val l = lang
        if (useDub && l != null) {
            if (l.dubEps.isNotEmpty()) l.dubEps else (1..l.dub).toList()
        } else {
            val fromSite = l?.sub ?: 0
            val fromAniList = anime.episodes ?: 0
            val next = anime.nextEpisode ?: 0
            val count = when {
                fromSite > 0 -> fromSite
                fromAniList > 0 -> fromAniList
                next > 1 -> next - 1
                else -> 0
            }
            (1..count).toList()
        }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "banner") {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                AsyncImage(
                    model = anime.banner ?: anime.cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                            )
                        )
                )
            }
        }

        item(key = "head") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.Top
            ) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = anime.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(112.dp)
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        anime.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (anime.romaji != anime.title) {
                        Text(
                            anime.romaji,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        anime.meta(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val statusLine = listOfNotNull(
                        anime.score?.let { "★ ${scoreText(it)}" },
                        anime.prettyStatus(),
                        anime.duration?.let { "$it min" }
                    ).joinToString(" • ")
                    if (statusLine.isNotBlank()) {
                        Text(
                            statusLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (anime.genres.isNotEmpty()) {
            item(key = "genres") {
                Text(
                    anime.genres.joinToString(" • "),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp)
                )
            }
        }

        if (anime.description.isNotBlank()) {
            item(key = "synopsis") {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        anime.description,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (expanded) Int.MAX_VALUE else 5,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (anime.description.length > 220) {
                        Text(
                            if (expanded) "Show less" else "Show more",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        item(key = "episodes-header") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Episodes (${episodeNumbers.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (lang?.hasDub == true) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !useDub,
                            onClick = { useDub = false },
                            label = { Text("Sub") }
                        )
                        FilterChip(
                            selected = useDub,
                            onClick = { useDub = true },
                            label = { Text("Dub") }
                        )
                    }
                }
            }
        }

        if (episodeNumbers.isEmpty()) {
            item(key = "no-episodes") {
                Text(
                    "No episode list yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        items(episodeNumbers, key = { it }) { n ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        scope.launch {
                            snackbar.currentSnackbarData?.dismiss()
                            snackbar.showSnackbar("Episode $n: the player arrives in Stage 2")
                        }
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$n", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Episode $n", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        if (useDub) "Dub" else "Sub",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "Play episode $n",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        if (anime.related.isNotEmpty()) {
            item(key = "related") {
                Column {
                    Spacer(Modifier.height(12.dp))
                    SectionTitle("Seasons and related")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(anime.related, key = { it.id }) { r ->
                            PosterCard(
                                title = r.title,
                                subtitle = r.relation,
                                cover = r.cover,
                                score = null,
                                onClick = { onOpen(r.id) },
                                modifier = Modifier.width(118.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
