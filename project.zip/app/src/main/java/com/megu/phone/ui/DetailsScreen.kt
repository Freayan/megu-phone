package com.megu.phone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import coil.compose.AsyncImage
import com.megu.phone.data.Anime
import com.megu.phone.data.EpisodeMeta
import com.megu.phone.data.LangInfo
import com.megu.phone.data.Progress
import com.megu.phone.data.Repo
import com.megu.phone.data.episodeList
import com.megu.phone.data.meta
import com.megu.phone.data.prettyStatus
import com.megu.phone.data.scoreText
import com.megu.phone.player.PlayerActivity
import kotlinx.coroutines.CancellationException

@Composable
fun DetailsScreen(id: Int, onBack: () -> Unit, onOpen: (Int) -> Unit) {
    val context = LocalContext.current
    var state by remember(id) { mutableStateOf<Load<Anime>>(Load.Loading) }
    var lang by remember(id) { mutableStateOf<LangInfo?>(null) }
    var epMeta by remember(id) { mutableStateOf<Map<Int, EpisodeMeta>>(emptyMap()) }
    var reload by remember(id) { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }

    // Re-read watch progress whenever we come back from the player.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    LaunchedEffect(id, reload) {
        state = Load.Loading
        state = try {
            Load.Ready(Repo.details(id))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Load.Failed(e.message ?: "Network error")
        }
    }
    LaunchedEffect(id) { lang = Repo.langInfo(id) }
    LaunchedEffect(id) { epMeta = Repo.episodeMeta(id) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            val current = state
            Text(
                if (current is Load.Ready) current.data.title else "",
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 16.dp)
            )
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (val s = state) {
                Load.Loading -> LoadingBox()
                is Load.Failed -> ErrorBox(s.message) { reload++ }
                is Load.Ready -> DetailsContent(
                    anime = s.data,
                    lang = lang,
                    epMeta = epMeta,
                    tick = tick,
                    onOpen = onOpen,
                    onPlay = { ep, dub -> PlayerActivity.start(context, s.data.id, ep, dub) }
                )
            }
        }
    }
}

@Composable
private fun DetailsContent(
    anime: Anime,
    lang: LangInfo?,
    epMeta: Map<Int, EpisodeMeta>,
    tick: Int,
    onOpen: (Int) -> Unit,
    onPlay: (Int, Boolean) -> Unit
) {
    var useDub by remember(anime.id) { mutableStateOf(false) }
    var expanded by remember(anime.id) { mutableStateOf(false) }

    val episodeNumbers = remember(anime, lang, useDub) { episodeList(anime, lang, useDub) }

    // Watch progress for the rows (refreshed on every return from the player).
    val progressByEpisode = remember(tick, anime.id, useDub, episodeNumbers) {
        episodeNumbers.associateWith { Progress.fraction(anime.id, it, useDub) }
    }
    val watchedEpisodes = remember(tick, anime.id, episodeNumbers) {
        episodeNumbers.filter { Progress.isWatched(anime.id, it) }.toSet()
    }
    val resume = remember(tick, anime.id) {
        Progress.continueWatching().firstOrNull { it.animeId == anime.id }
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "banner") {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
            ) {
                AsyncImage(
                    model = anime.banner ?: anime.cover,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, MaterialTheme.colorScheme.background)
                            )
                        )
                )
            }
        }

        item(key = "head") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.Top
            ) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = anime.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(112.dp)
                        .aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        anime.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (anime.romaji != anime.title) {
                        Text(
                            anime.romaji,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        anime.meta(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val statusLine = listOfNotNull(
                        anime.score?.let { "★ ${scoreText(it)}" },
                        anime.prettyStatus(),
                        anime.duration?.let { "$it min" }
                    ).joinToString(" • ")
                    if (statusLine.isNotBlank()) {
                        Text(
                            statusLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item(key = "play") {
            val firstEpisode = episodeNumbers.firstOrNull()
            if (resume != null) {
                Button(
                    onClick = { onPlay(resume.episode, resume.dub) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text("Continue episode ${resume.episode}")
                }
            } else if (firstEpisode != null) {
                Button(
                    onClick = { onPlay(firstEpisode, useDub) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text("Play episode $firstEpisode")
                }
            }
        }

        if (anime.genres.isNotEmpty()) {
            item(key = "genres") {
                Text(
                    anime.genres.joinToString(" • "),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        if (anime.description.isNotBlank()) {
            item(key = "synopsis") {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        anime.description,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (expanded) Int.MAX_VALUE else 5,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (anime.description.length > 220) {
                        Text(
                            if (expanded) "Show less" else "Show more",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        item(key = "episodes-header") {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "Episodes (${episodeNumbers.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (lang?.hasDub == true) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !useDub,
                            onClick = { useDub = false },
                            label = { Text("Sub") }
                        )
                        FilterChip(
                            selected = useDub,
                            onClick = { useDub = true },
                            label = { Text("Dub") }
                        )
                    }
                }
            }
        }

        if (episodeNumbers.isEmpty()) {
            item(key = "no-episodes") {
                Text(
                    "No episode list yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        items(episodeNumbers, key = { it }) { n ->
            val meta = epMeta[n]
            EpisodeRow(
                number = n,
                title = meta?.title,
                subtitle = listOfNotNull(
                    if (useDub) "Dub" else "Sub",
                    meta?.runtime?.let { "$it min" }
                ).joinToString(" • "),
                image = meta?.image,
                progress = progressByEpisode[n] ?: 0f,
                watched = n in watchedEpisodes,
                current = false,
                onClick = { onPlay(n, useDub) }
            )
        }

        if (anime.related.isNotEmpty()) {
            item(key = "related") {
                Column {
                    Spacer(Modifier.height(12.dp))
                    SectionTitle("Seasons and related")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(anime.related, key = { it.id }) { r ->
                            PosterCard(
                                title = r.title,
                                subtitle = r.relation,
                                cover = r.cover,
                                score = null,
                                onClick = { onOpen(r.id) },
                                modifier = Modifier.width(118.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
