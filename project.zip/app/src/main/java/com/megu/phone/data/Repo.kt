package com.megu.phone.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * All network access lives here.
 *  - Browse + details metadata: AniList public GraphQL API (the same one the TV app uses)
 *  - Sub/dub episode counts: https://meguanime.com/api/langinfo?al=<anilist id>
 */
object Repo {
    private const val ANILIST = "https://graphql.anilist.co"
    private const val SITE = "https://meguanime.com"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36 MeguAnimes/0.1"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val pageCache = ConcurrentHashMap<String, List<Anime>>()
    private val detailsCache = ConcurrentHashMap<Int, Anime>()
    private val langCache = ConcurrentHashMap<Int, LangInfo>()

    private const val LIST_FIELDS =
        "id idMal title { romaji english native } coverImage { large extraLarge } bannerImage " +
            "episodes duration averageScore format seasonYear genres status " +
            "nextAiringEpisode { episode } isAdult"

    private const val DETAIL_FIELDS =
        "id idMal title { romaji english native } coverImage { large extraLarge } bannerImage " +
            "episodes duration averageScore format seasonYear genres status " +
            "description(asHtml: false) nextAiringEpisode { episode } isAdult " +
            "relations { edges { relationType node { id type format " +
            "title { romaji english native } coverImage { large } } } }"

    // ---------------------------------------------------------------- browse

    /** One row of anime, e.g. page("TRENDING_DESC") or page("POPULARITY_DESC", "RELEASING"). */
    suspend fun page(sort: String, status: String? = null, perPage: Int = 24): List<Anime> {
        val key = "$sort:$status:$perPage"
        pageCache[key]?.let { return it }

        val statusArg = if (status != null) ", status: $status" else ""
        val query = "query { Page(page: 1, perPage: $perPage) { " +
            "media(type: ANIME, sort: [$sort]$statusArg, isAdult: false) { $LIST_FIELDS } } }"
        val data = graphql(query)
        val arr = data.getJSONObject("Page").getJSONArray("media")
        val list = (0 until arr.length()).map { parseAnime(arr.getJSONObject(it)) }
        pageCache[key] = list
        return list
    }

    // --------------------------------------------------------------- details

    suspend fun details(id: Int): Anime {
        detailsCache[id]?.let { return it }

        val query = "query { Media(id: $id, type: ANIME) { $DETAIL_FIELDS } }"
        val media = graphql(query).getJSONObject("Media")
        val anime = parseAnime(media)
        detailsCache[id] = anime
        return anime
    }

    suspend fun langInfo(id: Int): LangInfo? {
        langCache[id]?.let { return it }
        return try {
            val o = JSONObject(httpGet("$SITE/api/langinfo?al=$id"))
            val arr = o.optJSONArray("dubEps")
            val eps = ArrayList<Int>()
            if (arr != null) {
                for (i in 0 until arr.length()) eps.add(arr.getInt(i))
            }
            val info = LangInfo(
                sub = o.optInt("sub", 0),
                dub = o.optInt("dub", 0),
                dubEps = eps,
                hasDub = o.optBoolean("hasDub", false)
            )
            langCache[id] = info
            info
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    // --------------------------------------------------------------- parsing

    private fun JSONObject.str(key: String): String? =
        if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotBlank() } else null

    private fun JSONObject.intOrNull(key: String): Int? =
        if (has(key) && !isNull(key)) optInt(key) else null

    private fun parseAnime(o: JSONObject): Anime {
        val t = o.optJSONObject("title")
        val romaji = t?.str("romaji")
        val title = t?.str("english") ?: romaji ?: t?.str("native") ?: "Untitled"
        val cov = o.optJSONObject("coverImage")
        val genresArr = o.optJSONArray("genres")
        val genres = ArrayList<String>()
        if (genresArr != null) {
            for (i in 0 until genresArr.length()) genres.add(genresArr.getString(i))
        }

        val related = ArrayList<Related>()
        val edges = o.optJSONObject("relations")?.optJSONArray("edges")
        if (edges != null) {
            for (i in 0 until edges.length()) {
                val edge = edges.getJSONObject(i)
                val node = edge.optJSONObject("node") ?: continue
                if (node.str("type") != "ANIME") continue
                val nt = node.optJSONObject("title")
                related.add(
                    Related(
                        id = node.getInt("id"),
                        title = nt?.str("english") ?: nt?.str("romaji") ?: nt?.str("native") ?: "Untitled",
                        cover = node.optJSONObject("coverImage")?.str("large"),
                        relation = (edge.str("relationType") ?: "RELATED")
                            .lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() },
                        format = node.str("format")
                    )
                )
            }
        }

        return Anime(
            id = o.getInt("id"),
            idMal = o.intOrNull("idMal"),
            title = title,
            romaji = romaji ?: title,
            cover = cov?.str("extraLarge") ?: cov?.str("large"),
            banner = o.str("bannerImage"),
            episodes = o.intOrNull("episodes"),
            duration = o.intOrNull("duration"),
            score = o.intOrNull("averageScore"),
            format = o.str("format"),
            year = o.intOrNull("seasonYear"),
            genres = genres,
            description = cleanDescription(o.str("description") ?: ""),
            status = o.str("status"),
            nextEpisode = o.optJSONObject("nextAiringEpisode")?.intOrNull("episode"),
            isAdult = o.optBoolean("isAdult", false),
            related = related.distinctBy { it.id }
        )
    }

    private fun cleanDescription(s: String): String =
        s.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#039;", "'")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()

    // ------------------------------------------------------------------ http

    suspend fun httpGet(url: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept", "application/json, text/plain, */*")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} from ${req.url.host}")
            resp.body?.string() ?: throw IOException("Empty response from ${req.url.host}")
        }
    }

    private suspend fun graphql(query: String): JSONObject = withContext(Dispatchers.IO) {
        val body = JSONObject().put("query", query).toString()
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url(ANILIST)
            .post(body)
            .header("Accept", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("AniList error (HTTP ${resp.code})")
            val root = JSONObject(text)
            if (!root.has("data") || root.isNull("data")) throw IOException("AniList returned no data")
            root.getJSONObject("data")
        }
    }
}
