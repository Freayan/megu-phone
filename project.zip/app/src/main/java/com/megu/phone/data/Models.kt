package com.megu.phone.data

data class Anime(
    val id: Int,
    val idMal: Int?,
    val title: String,
    val romaji: String,
    val cover: String?,
    val banner: String?,
    val episodes: Int?,
    val duration: Int?,
    val score: Int?,
    val format: String?,
    val year: Int?,
    val genres: List<String>,
    val description: String,
    val status: String?,
    val nextEpisode: Int?,
    val isAdult: Boolean,
    val related: List<Related> = emptyList()
)

data class Related(
    val id: Int,
    val title: String,
    val cover: String?,
    val relation: String,
    val format: String?
)

/** Answer of https://meguanime.com/api/langinfo?al=<id> */
data class LangInfo(
    val sub: Int,
    val dub: Int,
    val dubEps: List<Int>,
    val hasDub: Boolean
)

fun Anime.meta(): String =
    listOfNotNull(
        format?.replace('_', ' '),
        year?.toString(),
        episodes?.let { "$it eps" }
    ).joinToString(" • ")

fun Anime.prettyStatus(): String? =
    status?.lowercase()?.replace('_', ' ')?.replaceFirstChar { it.uppercase() }

fun scoreText(score: Int): String = "${score / 10}.${score % 10}"
